/*

problem statement:write a recursive program to print below pattern 

5	*	4	*	3	*	2	*	1	*

*/

#include<stdio.h>

void DisplayI()
{
 int i=5;
 
 for(i=5;i>=1;i--)
 {
  printf("%d\t*\t",i);
 }
}

void DisplayR()
{
 static int i=5;
 
 if(i>=1)
 {
  printf("%d\t*\t",i);
  i--;
  DisplayR();
 }
}


int main()
{

 DisplayR();
 
 return 0;
}
