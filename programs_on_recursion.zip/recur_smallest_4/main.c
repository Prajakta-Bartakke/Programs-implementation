#include<stdio.h>

int SmallDigit(int iNo)
{
 static int iMin=10;
 
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 if(iNo!=0)
 {
  if((iNo%10)<iMin  ||  ((iNo%10)==0))
  {
   iMin=(iNo%10);
  }
  iNo=iNo/10;
  
  SmallDigit(iNo);
  
 }
 return iMin;
}

int main()
{
 int iNo=0;
 int iSmall=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 iSmall=SmallDigit(iNo);
 
 printf("smallest digit in %d is %d \n",iNo,iSmall);
 
 return 0;
}
