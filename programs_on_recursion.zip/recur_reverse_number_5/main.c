#include<stdio.h>

int Reverse(int iNo)
{
 static int iRev=0;
 
 if(iNo!=0)
 {
  iRev=(iRev*10)+(iNo%10);
  
  iNo=iNo/10;
  
  Reverse(iNo);
 }
 
 return iRev;
}

int main()
{
 int iNo=0;
 int iRev=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 iRev=Reverse(iNo);
 
 printf("reverse number of %d is %d\n",iNo,iRev);
 
 return 0;
}
 
