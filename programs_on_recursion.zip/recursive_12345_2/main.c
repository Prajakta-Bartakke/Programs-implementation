/*

problem statement: write a recursive program which will display below pattern

output:	1	2	3	4	5

*/

#include<stdio.h>

void DisplayI()
{
 int i=1;
 
 for(i=1;i<=5;i++)
 {
  printf("%d\t",i);
 }
 
 printf("\n");
}

void DisplayR()
{
 static int i=1;
 
 if(i<=5)
 {
  printf("%d\t",i);
  
  i++;
  
  DisplayR();
 }

}

int main()
{
 
 DisplayR();
 
 printf("\n");
 
 return 0;
}
