
#include<stdio.h>

int CountSpaces(char *arr)
{
 if(arr==NULL)
 {
  return -1;
 }
 static int iCnt=0;
 
 if((*arr)!='\0')
 {
  if((*arr)==' ')
  {
   iCnt++;
  }
  arr++;
  
  CountSpaces(arr);
 }
 
 return iCnt;
}
 
int main()
{
 char arr[30]={'\0'};
 int iRet=0;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 iRet=CountSpaces(arr);
 
 printf("total number of white spaces are : %d\n",iRet);
 
 return 0;
}
 
