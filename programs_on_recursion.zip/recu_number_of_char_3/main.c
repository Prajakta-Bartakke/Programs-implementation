
#include<stdio.h>

int CountChar(char *arr)
{
 if(arr==NULL)
 {
  return -1;
 }
 
 static int iCnt=0;
 
 if((*arr)!='\0')
 {
  iCnt++;
  
  arr++;
  
  CountChar(arr);
 }
 
 return iCnt;
}

int main()
{
 char arr[30]={'\0'};
 int iCnt=0;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 iCnt=CountChar(arr);
 
 printf("number of characters in string are : %d \n",iCnt);
 
 return 0;
}
