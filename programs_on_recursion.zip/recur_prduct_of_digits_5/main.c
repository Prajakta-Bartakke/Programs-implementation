
#include<stdio.h>

int MultDigits(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 static int iMult=1;
 
 if(iNo!=0)
 {
  if(iNo%10!=0)
  iMult=iMult*(iNo%10);
  
  iNo=iNo/10;
  
  MultDigits(iNo);
 }
 
 return iMult;
 
}

int main()
{
 int iNo=0;
 int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 iRet=MultDigits(iNo);
 
 printf("multiplication of digits is %d\n",iRet);
 
 return 0;
}
