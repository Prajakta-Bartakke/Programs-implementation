/*

problem statement: write a recursive program which will display below pattern

output:	a	b	c	d	e	f

*/

#include<stdio.h>

void DisplayI()
{
 char ch='a';
 
 while(ch<='f')
 {
  printf("%c\t",ch);
  ch++;
 }
 
}

void DisplayR()
{
 static char ch='a';
 
 if(ch<='f')
 {
  printf("%c\t",ch);
  ch++;
  DisplayR();
 }

}





int main()
{
 
 DisplayR();
 
 printf("\n");
 
 return 0;
}
