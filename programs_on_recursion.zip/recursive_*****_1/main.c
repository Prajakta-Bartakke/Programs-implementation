/*

problem statement:
	write a recursive program which display below pattern
	
	*	*	*	*	*
*/

#include<stdio.h>

void DisplayI()
{
 int i=0;
 
 for(i=1;i<=5;i++)
 {
  printf("*\t");
 }
 
 printf("\n");
}

void DisplayR()
{
 static int i=1;
 
 if(i<=5)
 {
  printf("*\t");
  
  i++;
  
  DisplayR();
 }
 
}

int main()
{
 
 DisplayR();
 printf("\n");
 return 0;
}
