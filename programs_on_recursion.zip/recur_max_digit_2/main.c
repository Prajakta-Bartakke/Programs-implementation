#include<stdio.h>

int MaxDigit(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 static int iMax=-1;
 
 if(iNo!=0)
 {
  if((iNo%10)>iMax)
  {
   iMax=(iNo%10);
  }
  iNo=iNo/10;
  
  MaxDigit(iNo);
  }
  return iMax;
}

int main()
{
 int iNo=0;
 int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 iRet=MaxDigit(iNo);
 
 printf("maximum digit in the number is %d \n",iRet);
 
 return 0;
}
