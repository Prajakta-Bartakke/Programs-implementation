/*

problem statement:
	accept number from user and return sum of its digits
	
*/

#include<stdio.h>

int SumDigits(int iNo)
{
 static int iSum=0;
 
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 if(iNo!=0)
 {
  iSum=iSum+(iNo%10);
  
  iNo=iNo/10;
  
  SumDigits(iNo);
 }
 
 return iSum;
}

int main()
{
 int iNo=0;
 int iRet=0;
 
 printf("Enter number:\n");
 scanf("%d",&iNo);
 
 iRet=SumDigits(iNo);
 
 printf("%d\n",iRet);
 
 return 0;
}
 
