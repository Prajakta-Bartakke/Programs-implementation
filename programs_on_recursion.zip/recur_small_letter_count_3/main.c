#include<stdio.h>

int CountSmall(char *arr)
{
 if(arr==NULL)
 {
  return -1;
 }
 
 static int iCnt=0;
 if((*arr)!='\0')
 {
  if((*arr)>='a' && (*arr)<='z')
  {
   iCnt++;
  }
  arr++;
  CountSmall(arr);
 }
 return iCnt;
}

int main()
{
 char arr[30]={'\0'};
 int iRet=0;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 iRet=CountSmall(arr);
 
 printf("there are %d small leters in string\n",iRet);
 
 return 0;
}
