
#include<stdio.h>

/*int Factorial(int iNo)
{
 int iFact=1;
 
 while(iNo!=0)
 {
  iFact=iFact*iNo;
  printf("%d\n",iFact);
  iNo--;
  
 }
 
 return iFact;
}*/

int Factorial(int iNo)
{
 static long int iFact=1;
 
 if(iNo!=0)
 {
  iFact=iFact*iNo;
  
  iNo--;
  
  Factorial(iNo);
 }
 return iFact;
}


int main()
{
 int iNo=0;
 int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 iRet=Factorial(iNo);
 
 printf("factorial of given number is :%d \n",iRet);
 
 return 0;
}
 
