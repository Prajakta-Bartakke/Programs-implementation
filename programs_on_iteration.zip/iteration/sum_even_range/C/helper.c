#include"header.h"
////////////////////////////////////////////////////////
//
//function name:	SumEven
//input:		integer,integer
//return value:	integer
//description:		used to perform sum of even numbers in range
//author:		Prajakta Aditya Bartakke
//date:		9 aug 2020
////////////////////////////////////////////////////////

int SumEven(int iStart,int iEnd)
{
 if(iStart<0 || iEnd<0 || iStart>iEnd)
 {
  return 0;
 }    
 
 int iSum=0;

 if(((iStart%2)!=0) && ((iEnd%2)!=0))
 {
   iStart=iStart+1;
   iEnd=iEnd-1;
 }
 else if(((iStart%2)!=0)  &&  ((iEnd%2)==0))
 {
  iStart=iStart+1;
 }
  
 else if(((iStart%2)==0)  &&  ((iEnd%2)!=0))
 {
  iEnd=iEnd-1;
 }
 
 while((iEnd-iStart)>=0)                                      
   {
    //printf("%d ",iStart);
    //printf("%d ",iEnd);
    iSum=iSum+iStart+iEnd;
    
    iStart=iStart+2;
    iEnd=iEnd-2;
    
    if(iStart==iEnd)
    { 
     //printf("%d ",iEnd);
     iSum=iSum+iEnd;
     break;
    }
   }
   return iSum;
   }
   
  
  
 
 
 
 
 
 
 
 
 
  
