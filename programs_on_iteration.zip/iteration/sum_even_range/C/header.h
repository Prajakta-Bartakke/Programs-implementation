#include<stdio.h>

int SumEven(int,int);
