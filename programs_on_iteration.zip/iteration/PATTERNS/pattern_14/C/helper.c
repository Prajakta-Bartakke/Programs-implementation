#include"header.h"

///////////////////////////////////////////////////
//
//function name:	Pattern
//input:		integer,integer
//return value:	none
//author:		Prajakta Aditya Bartakke
//date:		11 aug 2020
//////////////////////////////////////////////////

void Pattern(int iRow,int iCol)
{
 int i=0,j=0;
 if(iRow<0)
 {
  iRow=-iRow;
 }
 if(iCol<0)
 {
  iCol=-iCol;
 }
 
 for(int i=1;i<=iRow;i++)
 {
  for(int j=iCol;j>=1;j--)
  {
   printf("%d\t",j);
  }
  printf("\n");
 }

}
