/* problem statement:  accept number of rows and column from user and print below patten

input:		row=3  column=4
output:	1 1 1 1
		2 2 2 2 
		3 3 3 3 
*/

#include<stdio.h>
void Pattern(int iRow,int iCol)
{
 if(iRow<0)
 {
  iRow=-iRow;
 }
 if(iCol<0)
 {
  iCol=-iCol;
 }
 int i=0,j=0;
 
 for(i=1;i<=iRow;i++)
 {
  for(j=1;j<=iCol;j++)
  {
   printf("%d\t",i);
  }
 printf("\n"); 
 }
}
 
int main()
{
 int iRow=0,iCol=0;
 
 printf("enter number of rows and column\n");
 scanf("%d%d",&iRow,&iCol);

 Pattern(iRow,iCol);
 
 return 0;
}
                

