/*
 problem statement:
		Accept number of rows and column from user and print the below pattern
		
input:		row=5  column=5

output:	* * * * *
		* * * *
		* * *
		* *
		*	             
*/
#include<stdio.h>
void Pattern(int iRow,int iCol)
{
 if(iRow<0)
 {
  iRow=-iRow;
 }
 if(iCol<0)
 {
  iCol=-iCol;
 }
 if(iRow!=iCol)
 {
  printf("Error:invalid input\n");
  return;
 }
 int i=0;
 int j=0;
 
 for(i=0;i<iRow;i++)
 {
  for(j=1;j<=(iCol-i);j++)
  {
    printf("*\t");
  }
  printf("\n");
 }
 }

int main()
{
 int iRow=0,iCol=0;
 
 printf("enter number of rows and column\n");
 scanf("%d%d",&iRow,&iCol);
 
 Pattern(iRow,iCol);
 
 return 0;
}
