/*
problem statement:  accept row and column from user and print the following pattern

input:		4  3

output:	1 2 3
		1 2 3
		1 2 3
		1 2 3

*/
#include"header.h"
int main()
{
 int iRow=0,iColumn=0;
 
 printf("enter number of row and column\n");
 scanf("%d%d",&iRow,&iColumn);
 
 Pattern(iRow,iColumn);
 
 return 0;
}
