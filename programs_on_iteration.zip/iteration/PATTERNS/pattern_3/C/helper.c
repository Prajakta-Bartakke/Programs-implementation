#include"header.h"

///////////////////////////////////////////
//function name:	Display
//input arguments:	integer
//return value:	none
//description:		prints the * on screen for the given input
//author:		Prajakta Aditya Bartakke
//date:		27 july 2020
///////////////////////////////////////////

void Display(int iNo)
{
 int iCnt=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  printf("*\t");
 }
}
