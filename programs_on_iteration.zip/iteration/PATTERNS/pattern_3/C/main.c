/*
   problem statement:print number of * on screen
*/

#include"header.h"

int main()
{
 int iValue=5;
 
 Display(iValue);
 
 return 0;
}




