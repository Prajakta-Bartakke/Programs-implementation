#include"header.h"

///////////////////////////////////////////////////
//
//function name:	Pattern
//input:		integer
//return value:	none
//author:		Prajakta Aditya Bartakke
//date:		11 aug 2020
//////////////////////////////////////////////////

void Pattern(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 int iCnt=0;
 
 for(iCnt=iNo;iCnt>=1;iCnt--)
 {
  printf("%d\t#\t",iCnt);
 }
}
