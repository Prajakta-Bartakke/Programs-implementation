/*
problem statement:  accept number from user and print the following pattern

input:		5
output:	5 # 4 # 3 # 2 # 1 # 

*/
#include"header.h"
int main()
{
 int iVal=0;
 
 printf("enter number\n");
 scanf("%d",&iVal);
 
 Pattern(iVal);
 
 return 0;
}
