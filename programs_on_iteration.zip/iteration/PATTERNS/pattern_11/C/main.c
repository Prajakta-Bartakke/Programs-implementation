/*
problem statement:  accept number from user and print the following pattern

input:		8
output:	2 4 6 8 10 12 14 16

*/
#include"header.h"
int main()
{
 int iVal=0;
 
 printf("enter number\n");
 scanf("%d",&iVal);
 
 Pattern(iVal);
 
 return 0;
}
