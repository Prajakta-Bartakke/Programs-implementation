#include"header.h"

///////////////////////////////////
//function name:	Display
//paramtre:		integer
//retuen val:		none
//description:		prints * on screen for the given number of times input
//author:		Prajakta Aditya Bartakke
//date:		27 july 2020
///////////////////////////////////

/*void Display(int iNo)
{
 while(iNo>0)
 {
  printf("*");
  
  iNo--;
 }
}*/

void Display(int iNo)
{
 int iCnt=0;
 
 while(iNo>iCnt)
 {
   printf("*");
   
   if(iNo==0)
   { 
     break;
   }
   
   iCnt++;
 }
}

