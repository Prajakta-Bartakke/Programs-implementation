#include"header.h"

///////////////////////////////////////////////////
//
//function name:	Pattern
//input:		integer,integer
//return value:	none
//author:		Prajakta Aditya Bartakke
//date:		11 aug 2020
//////////////////////////////////////////////////

void Pattern(int iRow,int iCol)
{
 if(iRow<0)
 {
  iRow=-iRow;
 }
 if(iCol<0)
 {
  iCol=-iCol;
 }
 
 int iCnt1=0,iCnt2=0;
 
 for(iCnt1=1;iCnt1<=iRow;iCnt1++)
 {
  for(iCnt2=1;iCnt2<=iCol;iCnt2++)
  {
   printf("*\t");
  }
  printf("\n");
 }
}
