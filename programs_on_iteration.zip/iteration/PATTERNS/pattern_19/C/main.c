/* problem statement:    accept row and column from user and print below pattern

input:		row =4   col=5

output:	2 4 6 8 10
		1 3 5 7 9   	
		2 4 6 8 10
		1 3 5 7 9

*/

#include<stdio.h>
void Pattern(int iRow,int iCol)
{
 if(iRow<0)
 {
  iRow=-iRow;
 }
 if(iCol<0)
 {
  iCol=-iCol;
 }
 int i=0,j=0;
 
 for(i=1;i<=iRow;i++)
 {
  if((i%2)!=0)
  {
    for(j=1;j<=iCol;j++)
    {
     printf("%d\t",(j*2));
    }
    printf("\n");
  }
  
  else
  {
   for(j=1;j<=((iCol*2)-1);j=j+2)
   {
    printf("%d\t",j);
   }
   printf("\n");

  }
 }
}

int main()
{
  int iRow=0,iCol=0;
  
  printf("enter number of rows and column\n");
  scanf("%d%d",&iRow,&iCol);
  
  Pattern(iRow,iCol);
  
  return 0;
}
