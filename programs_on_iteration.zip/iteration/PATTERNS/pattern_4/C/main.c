/*
 problem statement:  accept two numbers from user and print first number for second number of times
*/
/*
algorithm:  
	START
		accept 2 numbers from user as iVal and iFrequency
		make a counter variable 
		print value iVal for second number of times till the second number 
		 continue iteration
	END
*/
#include"header.h"
int main()
{
 int iVal=0,iFrequency=0;

 printf("enter number from user:\n");
 scanf("%d",&iVal);
 
 printf("enter second number ie frequency:\n");
 scanf("%d",&iFrequency);
 
 Display(iVal,iFrequency);
 
 return 0;
}
		
