#include"header.h"

//////////////////////////////////////////////////////////
//
//function name:		Display
//input:			integer
//return value:		none
//description:			used to print $ and *
//author:			Prajakta Aditya Bartakke
//date:			6 August 2020
//////////////////////////////////////////////////////////

void Display(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 int iCnt=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  printf("$ * ");
 }
} 

 

