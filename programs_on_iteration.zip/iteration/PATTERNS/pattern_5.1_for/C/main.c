/*
  problem statement: accept number from user and print that number of times * on screen
*/

#include"header.h"
int main()
{
 int iVal=0;
 
 printf("enter the number:");
 
 scanf("%d",&iVal);
 
 Display(iVal);
 
 return 0;
}
