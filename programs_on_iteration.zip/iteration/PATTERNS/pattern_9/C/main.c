/*
problem statement:  accept number from user and print the following pattern

input:		5
output:	1 * 2 * 3 * 4 * 5 *

*/
#include"header.h"
int main()
{
 int iVal=0;
 
 printf("enter number\n");
 scanf("%d",&iVal);
 
 Pattern(iVal);
 
 return 0;
}
