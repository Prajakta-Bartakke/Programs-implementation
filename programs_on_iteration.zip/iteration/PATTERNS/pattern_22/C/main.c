/* problem statement:    accept row and column from user and print below pattern

input:		row =4   col=4

output:	
		1 2 3 4 
		2 3 4 5
		3 4 5 6
		4 5 6 7
		
*/

#include<stdio.h>
void Pattern(int iRow,int iCol)
{
 if(iRow<0)
 {
  iRow=-iRow;
 }
 if(iCol<0)
 {
  iCol=-iCol;
 }
 int i=0,j=0;
 
 for(i=1;i<=iRow;i++)
 {
  for(j=i;j<(i+iCol);j++)
  {
   printf("%d\t",j);
  }
  printf("\n");
 }
  
}

int main()
{
  int iRow=0,iCol=0;
  
  printf("enter number of rows and column\n");
  scanf("%d%d",&iRow,&iCol);
  
  Pattern(iRow,iCol);
  
  return 0;
}
