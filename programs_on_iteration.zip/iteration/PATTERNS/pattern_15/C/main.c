/* 
  problem statement:  accept row and column from user and display below pattern
  
  input:	3 4 
  
  output:	* # * #
  		* # * #
		* # * #
*/
#include"header.h"
int main()
{
 int iRow=0,iCol=0; 
 
 printf("enter number of rows and column\n");
 scanf("%d%d",&iRow,&iCol);   	
  
 Pattern(iRow,iCol);
 
 return 0;
}
