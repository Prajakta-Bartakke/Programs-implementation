#include"header.h"
////////////////////////////////////////////
//
//function name:	Pattern
//input:		integer,integer
//return value:	none
//description:		used to print given pattern
//author:		Prajakta Aditya Bartakke
//date:		11 aug 2020
/////////////////////////////////////////////

void Pattern(int iRow,int iCol)
{
 int i=0,j=0;
 
 if(iRow<0)
 iRow=-iRow;
 
 if(iCol<0)
 iCol=-iCol;
 
 for(i=1;i<=iRow;i++)
 {
  for(j=1;j<=iCol;j++)
  {
   if((j%2)!=0)
   {
    printf("*\t");
   }
   else
   {
    printf("#\t");
   }
 }
 printf("\n");
}
}
