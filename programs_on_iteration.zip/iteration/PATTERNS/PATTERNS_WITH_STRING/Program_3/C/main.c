/*
problem statement: accept string from user and display below patteren 

input: marvellous

output:
		
	m
	
	m	a	
	
	m	a	r
	
	m	a	r	v
	
	m	a	r	v	e
	
	m	a	r	v	e	l
	
	m	a	r	v	e	l	l
	
	m	a	r	v	e	l	l	o
	
	m	a	r	v	e	l	l	o	u
	
	m	a	r	v	e	l	l	o	u	s
	
*/

#include<stdio.h>

void Display(char *arr)
{
 if(arr==NULL)
 {
  return;
 }
 int iCnt=0,i=0,j=0;
 
 while((*(arr+iCnt))!='\0')
 {
  iCnt++;
 }
 
 for(i=0;i<iCnt;i++)
 {
  for(j=0;j<=i;j++)
  {
   printf("inner loop\n");
   printf("%c\t",(*(arr+j)));
  }
  printf("\n");
 }
}


int main()
{
 char arr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 Display(arr);
 
 return 0;
}
