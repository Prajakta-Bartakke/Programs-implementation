#include"header.h"

//////////////////////////////////////////////
//function name:	Display
//input arguments:	none
//return value:	none
//description:		it is used to display marvellous 5 times on screen
//author:		Prajakta Aditya Bartakke
//date:		26 july 2020
/////////////////////////////////////////////

void Display()
{
 int iCnt=0;
 
 for(iCnt=0;iCnt<5;iCnt++)
 {
  printf("marvellous\n");
 }
}


