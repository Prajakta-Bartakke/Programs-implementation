#include"header.h"

/////////////////////////////////////////////////
//
//function name:	Pattern
//input:		integer
//return value:	none
//description:		used to display pattern
//author:		Prajakta Aditya Bartakke
//date:		11 aug 2020
////////////////////////////////////////////////

void Pattern(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 int iCnt=0;
 
 for(iCnt=65;iCnt<(65+iNo);iCnt++)
 {
  printf("%c\t",iCnt);
 }
}
 
