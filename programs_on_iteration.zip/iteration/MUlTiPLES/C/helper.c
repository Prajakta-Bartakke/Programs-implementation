
#include"header.h"
/*void Display(int iNo)
{
 int iCnt=0;
 
 for(iCnt=1;iCnt<=5;iCnt++)
 { 
  printf("%d ",(iNo*iCnt));
 }
}*/

/*void Display(int iNo)
{
  int iCnt=0;
  int iNum=iNo;
  
  while(iCnt!=5)
  {
   printf("%d ",iNum);
   
   iNum=iNum+iNo;                              //repetitive addition
   
   iCnt++;
  }
}*/

void Display(int iNo)
{
 int iCntf=iNo,iCntb=(5*iNo);
 
 while(iCntf!=iCntb)
 {
  printf("%d ",iCntf);
  printf("%d ",iCntb);
  
  iCntf=iCntf+iNo;
  
  iCntb=iCntb-iNo;
  
  if(iCntf==iCntb)
  {
   printf("%d ",iCntf);
  }
 }
}
