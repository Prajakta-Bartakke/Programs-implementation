/*  problem statemnt:  write a program which accepts number from user and print the reverse table of it*/
#include"header.h"
int main()
{
 int iVal=0;
 printf("enter number\n");
 scanf("%d",&iVal);
 
 Display(iVal);
 
 return 0;
}
