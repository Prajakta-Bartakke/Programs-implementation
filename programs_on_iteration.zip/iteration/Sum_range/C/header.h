#include<stdio.h>

int SumRange(int,int);
