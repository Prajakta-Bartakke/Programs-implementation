/* 
 problem statement:	write a program which accepts range from user and print all the numbers in between in reverse order
*/
#include"header.h"
int main()
{
 int iStart=0;
 int iEnd=0;

 printf("enter starting point\n");
 scanf("%d",&iStart);
 
 printf("enter ending point\n");
 scanf("%d",&iEnd);
 
 PrintReverseRange(iStart,iEnd);
 
 return 0;
}
