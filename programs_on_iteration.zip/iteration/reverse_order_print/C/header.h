#include<stdio.h>

void PrintReverseRange(int,int);
