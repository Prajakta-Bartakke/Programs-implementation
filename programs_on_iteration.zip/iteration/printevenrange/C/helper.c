#include"header.h"
////////////////////////////////////////////////////////
//
//function name:	PrintEven
//input:		integer,integer
//return value:	none
//description:		used to print even numbers in range
//author:		Prajakta Aditya Bartakke
//date:		9 aug 2020
////////////////////////////////////////////////////////

void PrintEven(int iStart,int iEnd)
{
 if(iStart>iEnd)
 {
  printf("invalid range\n");
 }
 
 if(((iStart%2)!=0) && ((iEnd%2)!=0))
 {
   iStart=iStart+1;
   iEnd=iEnd-1;
 }
 else if(((iStart%2)!=0)  &&  ((iEnd%2)==0))
 {
  iStart=iStart+1;
 }
  
 else if(((iStart%2)==0)  &&  ((iEnd%2)!=0))
 {
  iEnd=iEnd-1;
 }
 
 while((iEnd-iStart)>=0)                                      
   {
    printf("%d ",iStart);
    printf("%d ",iEnd);
    
    iStart=iStart+2;
    iEnd=iEnd-2;
    
    if(iStart==iEnd)
    { 
     printf("%d ",iEnd);
     break;
    }
   }
   }
   
  
  
 
 
 
 
 
 
 
 
 
  
