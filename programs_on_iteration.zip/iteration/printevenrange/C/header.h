#include<stdio.h>

void PrintEven(int,int);
