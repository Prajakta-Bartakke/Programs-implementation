/*
  problem statement:	accept range from user and print the evwn numbers in between them 
*/
#include"header.h"

int main()
{
 int iStart=0;
 int iEnd=0;
 
 printf("enter starting point\n");
 scanf("%d",&iStart);
 
 printf("enter ending number\n");
 scanf("%d",&iEnd);
 
 PrintEven(iStart,iEnd);
 
 return 0;
}
