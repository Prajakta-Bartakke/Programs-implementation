#include"header.h"

//////////////////////////////////////////////////////////
//
//function name:		Display
//input:			integer
//return value:		none
//description:			used to print numbers
//author:			Prajakta Aditya Bartakke
//date:			6 August 2020
//////////////////////////////////////////////////////////

/*void Display(int iNo)
{
 int iCnt=1;
 
 for(iCnt=1;iCnt<=iNo;iCnt++)
 {
  printf("%d ",iCnt);
 }
}*/

void Display(int iNo)
{
 int iCntf=1,iCntb=iNo;
 
 while((iCntb!=(iCntf-1))   &&   (iCntb-iCntf>=0)  )
 {
 
   if(iCntf==iCntb)
   {
     printf("%d ",iCntf);
     break;
   }
   
   printf("%d ",iCntf);
   
   printf("%d ",iCntb);
   
   
   
   iCntf++;
   
   iCntb--;
 }
}
