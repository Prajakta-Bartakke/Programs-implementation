/*
  problem statemnt:	accept number from user and print its number line
*/
#include"header.h"

int main()
{
 int iVal=0;
 
 printf("enter number:\n");
 scanf("%d",&iVal);
 
 Display(iVal);
 
 return 0;
}
