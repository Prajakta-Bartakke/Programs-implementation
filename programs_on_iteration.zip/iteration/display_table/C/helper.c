#include"header.h"

////////////////////////////////////////////////////////
//
//function name:		Display
//input:			integer
//return value:		none
//description:			used to display the table of a number
//author:			Prajakta Aditya Bartakke
//date:			6 aug 2020
////////////////////////////////////////////////////////

/*void Display(int iNo)
{

 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 int iCnt=0;int iNum=iNo;
 
 while(iCnt!=10)
 {
  printf("%d\t",iNum);
  
  iNum=iNum+iNo;
  
  iCnt++;
 }
}*/

void Display(int iNo)
{
 
