/*  
  problem statement:  write a program which accpts number from user and display its table
*/
#include"header.h"

int main()
{
 int iVal=0;
 
 printf("enter number:\n");
 scanf("%d",&iVal);
 
 Display(iVal);
 
 return 0;
}
 
