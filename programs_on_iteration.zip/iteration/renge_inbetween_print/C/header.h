#include<stdio.h>

void PrintRange(int,int);
