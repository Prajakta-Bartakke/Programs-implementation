#include"header.h"
///////////////////////////////////////////////////////////
//
//function name:	PrintRange
//input:		integer,integer
//return value:	none
//description:		used to print numbers between the range
//author:		Prajakta Aditya Bartakke
//date:		8 aug 2020
////////////////////////////////////////////////////////////

void PrintRange(int iStart,int iEnd)
{
 if(iStart>iEnd)
 {
  int temp=0;
  temp=iEnd;
  iEnd=iStart;
  iStart=temp;
 }
 while(iEnd!=(iStart-1)  &&   (iEnd-iStart>=0))
 {
  if(iStart==iEnd)
  {
   printf("%d ",iStart);
   break;
  }
  
  printf("%d ",iStart);
  printf("%d ",iEnd);
  
  iStart++;
  iEnd--;
  
 }
}
 
