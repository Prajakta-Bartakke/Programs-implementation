/*

problem statement: accept two numbers from user and print the common on bits  

*/

#include<stdio.h>

void CommonOn(int iNo1,int iNo2)
{
 if(iNo1<0)
 {
  iNo1=-iNo1;
 }
 if(iNo2<0)
 {
  iNo2=-iNo2;
 }
 int iMask=0x00000001;
 int iRet1=0,iRet2=0;
 int iPos=1;
 
 while(iPos!=33)
 {
  iRet1=iNo1 & iMask;
  iRet2=iNo2 & iMask;
  
  if((iRet1==iMask) && (iRet2==iMask))
  {
   printf("%d\n",iPos);
  }
  
  iPos++;
  iMask=0x00000001;
  iMask=iMask<<(iPos-1);
 }
}

int main()
{
 int iNo1=0,iNo2=0;
 
 printf("enter first number:\n");
 scanf("%d",&iNo1);
 
 printf("enter second number:\n");
 scanf("%d",&iNo2);
 
 CommonOn(iNo1,iNo2);
 
 return 0;
}
