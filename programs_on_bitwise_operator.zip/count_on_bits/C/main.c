/*
problem statement: accept number from user and return the count the on bits

*/

#include<stdio.h>
typedef unsigned int UINT;
int CountOn(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 int iMask=0x00000001;
 
 int iPos=1;
 
 int iCnt=0,iRet=0;
 
 while(iPos!=33)
 {
  iRet=iNo & iMask;
  
  if(iRet==iMask)
  {
   iCnt++;
  }
 
  iPos++;
  iMask=0x00000001;
  iMask=iMask<<(iPos-1);
  
 }
 
 return iCnt;
}
 
int main()
{
 int iNo=0;
 int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 iRet=CountOn(iNo);
 
 printf("%d\n",iRet);
 
 return 0;
}
