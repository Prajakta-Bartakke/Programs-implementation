/*

problem statement: accept number from user also accept a position at that position check whether the bit is on or off

*/

#include<stdio.h>

typedef int BOOL;
#define TRUE 1
#define FALSE 0
#define INVALID -1

BOOL ChkBit(int iNo,int iPos)
{
 if(iPos>32)
 {
  return INVALID;
 }
 
 int iMask=0x00000001;
 
 iMask=iMask<<(iPos-1);
 
 int iRet=iNo & iMask;
 
 if(iRet==iMask)
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
}

int main()
{
 int iNo=0,iPos=0;
 BOOL bRet=FALSE;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 printf("enter position:\n");
 scanf("%d",&iPos);
 
 bRet=ChkBit(iNo,iPos);
 
 if(bRet==TRUE)
 {
  printf("ON\n");
 }
 else if(bRet==INVALID)
 {
  printf("Error:invalid position entered\n");
 }
 else
 {
  printf("OFF\n");
 }
 
 
 return 0;
}
