/*

problem statement: accept number from user and off 7th and 10th bit of that number and return the modified number

*/

#include<stdio.h>

int OffBit(int iNo)
{
 int iMask=0x00000240;
 
 int iRet=0;
 
 iRet=iNo & iMask;
 
 if(iRet==iMask)
 {
  int iMask7=0x00000040;
  
  int iMask10=0x00000200;
  
  int iRet1=0;
  
  iRet=((iNo ^ iMask7) | (iNo ^ iMask10));
  
  return iRet1;
 }
 
 //else if()
}

int main()
{
 int iNo=0;
 int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 iRet=OffBit(iNo);
 
 printf("%d\n",iRet);
 
 return 0;
}
