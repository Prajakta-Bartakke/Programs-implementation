/*

problem statement: accept one number and the ranege from user and toggle the bits for that range and return the modified number

*/

#include<stdio.h>
#define SIZE -1
int Toggle(int iNo,int iStart,int iEnd)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 if(iStart<0)
 {
  iStart=-iStart;
 }
 if(iEnd<0)
 {
  iEnd=-iEnd;
 }
 if(iStart>iEnd)
 {
  return SIZE;
 }
 
 int iMask=0x00000001;
 
 int i=0;
 
 int iRet=0;
 
 for(i=iStart;i<=iEnd;i++)
 {
  iMask=iMask<<(i-1);
  
  iRet=iRet | (iNo ^ iMask); 
  
  iMask=0x00000001;
 }
 
 return iRet;
}


int main()
{
 int iNo=0;
 int iStart=0;
 int iEnd=0;
 int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 printf("enter starting point of range:\n");
 scanf("%d",&iStart);
 
 printf("enter ending point of range:\n");
 scanf("%d",&iEnd);
 
 iRet=Toggle(iNo,iStart,iEnd);
 
 if(iRet==SIZE)
 {
  printf("Error:invalid size\n");
 }
 else
 {
  printf("toggled input is :%d\n",iRet);
 }
 return 0;
}
 
 
 
 
 
 
 
 
 
 
 
