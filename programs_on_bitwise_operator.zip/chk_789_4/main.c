/*

problem statement: accept number from user and check whether 7th & 8th & 9tg bit is on or off

*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE -1

BOOL ChkOn(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 int iMask=0x000001c0;
 
 int iRet=0;
 
 iRet=iNo & iMask;
 
 if(iRet==iMask)
 {
  return TRUE;
 }
 else
 {
   return FALSE;
 }
}

int main()
{
 int iNo=0;
 BOOL bRet=FALSE;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 bRet=ChkOn(iNo);
 
 if(bRet==TRUE)
 {
  printf("ON\n");
 }
 else
 {
  printf("OFF\n");
 }
 return 0;
}
