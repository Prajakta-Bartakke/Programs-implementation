/*

problem statement: accept number from user and check whether 7 and 15 and 21 and 28 bit is on or off

*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE -1

BOOL ChkOn(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 int iMask=0x08104040;
 
 int iRet=0;
 
 iRet=iNo & iMask;
 
 if(iRet==iMask)
 {
  return TRUE;
 }
 else
 {
   return FALSE;
 }
}

int main()
{
 int iNo=0;
 BOOL bRet=FALSE;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 bRet=ChkOn(iNo);
 
 if(bRet==TRUE)
 {
  printf("ON\n");
 }
 else
 {
  printf("eithr 7 or 15 or 21 or 28 is OFF\n");
 }
 return 0;
}
