/*

problem statement: accept one number and 2 positions and check whether the first or second bit is on or off

*/

#include<stdio.h>

typedef int BOOL;
#define TRUE 1
#define FALSE -1
#define SIZE -2
BOOL ChkOn(int iNo,int iBit1,int iBit2)
{

 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 if(iBit1>32 || iBit2>32)
 {
  return SIZE;
 }

 
 int iMask=0x00000001;
 
 int iMask1=0x00000001;
 
 int iPos=iBit1;
 
 iMask=iMask<<iPos;
 
 int iRet1=0,iRet2=0;
 
 iRet1=iNo & iMask;
 
 iMask1=iMask1<<iBit2;
 
 iRet2=iNo & iMask1;
 
 if(iRet1==iMask  ||  iRet2==iMask1)
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
 
}

int main()
{
 int iNo=0;
 int iBit1=0,iBit2=0;
 BOOL bRet=FALSE;
 
 printf("enter one number:\n");
 scanf("%d",&iNo);
 
 printf("enter first bit:\n");
 scanf("%d",&iBit1);
 
 printf("enter second bit:\n");
 scanf("%d",&iBit2);
 
 bRet=ChkOn(iNo,iBit1,iBit2);
 
 if(bRet==TRUE)
 {
  printf("either bit no %d is on or %d is on\n",iBit1,iBit2);
 }
 else if(bRet==FALSE)
 {
  printf("either bit no %d is off or %d is off or both are off\n",iBit1,iBit2);
 }
 else if(bRet==SIZE)
 {
  printf("Error:invalid size of either or both the bits\n");
 }
 
 return 0;
}
