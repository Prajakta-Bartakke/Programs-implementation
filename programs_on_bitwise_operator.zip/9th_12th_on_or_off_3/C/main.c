/*
problem statement: accept number from user and check either the 9th or 12th bit is on or off
*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE -1


BOOL ChkOn(int iNo)
{

 if(iNo<0)
 {
  iNo=-iNo;
 }
 
int iMask=0x00000001;
 
 int iRet1=0,iRet2=0;
 
 int iPos=0;
 
 iPos=9;
 
 iMask=iMask<<(iPos-1);
 
 iRet1=(iNo & iMask);
 
 int iMask1=0x00000001;
 
 iPos=12;
 
 iMask1=iMask1<<(iPos-1);
 
 iRet2=(iNo & iMask1);
 
 if((iRet1==iMask) || (iRet2==iMask1))
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
 
}

int main()
{
 int iNo=0;
 BOOL bRet=FALSE;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 bRet=ChkOn(iNo);
 
 if(bRet==TRUE)
 {
  printf("TRUE\n");
 }
 else
 {
  printf("FALSE\n");
 }
 
 return 0;
}





