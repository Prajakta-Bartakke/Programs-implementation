/*

problem statement : accept number from user and jar 7th bit on asel tar off and return modified number

*/

#include<stdio.h>

int OffBit(int iNo)
{
 int iMask=0x00000040;
 
 int iRet=0;
 
 iRet=iNo & iMask;
 
 if(iRet==iMask)
 {
  iRet=0;
  
  iRet=iMask ^ iNo;
  
  return iRet;
 }
 else 
 {
  return iNo;
 }
}

int main()
{
 int iNo=0;
 int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 iRet=OffBit(iNo);
 
 printf("%d\n",iRet);
 
 return 0;
}
