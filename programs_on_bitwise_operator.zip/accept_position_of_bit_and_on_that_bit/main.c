/*

problem statement: accept number from user and also accept position and on that bit

*/
#include<stdio.h>
#define INVALID -5

int OnBit(int iNo,int iPos)
{
 if(iPos>32)
 {
  return INVALID;
 }
 
 int iMask=0x00000001;
 
 iMask=iMask<<(iPos-1);
 
 int iRet=iNo & iMask;
 int iVal=0;
 
 if(iRet==iMask)
 {
  return iNo;
 }
 else
 {
  iVal=iMask ^ iNo;
  return iVal;
 }
}

int main()
{

 int iNo=0,iPos=0,iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 printf("enter position\n");
 scanf("%d",&iPos);
 
 iRet=OnBit(iNo,iPos);
 
 if(iRet==INVALID)
 {
  printf("Error:invalid position entered\n");
 }
 
 else
 {
  printf("%d\n",iRet);
 }
 
 
 return 0;
} 
