/*problem statement: accept numeber from user and on its first four bits
*/

#include<stdio.h>

int OnBits(int iNo)
{
 int iMask=0x0000000f;
 
 int iRet=iMask | iNo;
 
 return iRet;
}

int main()
{
 int iNo=0;
 int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 iRet=OnBits(iNo);
 
 printf("%d\n",iRet);
 
 return 0;
}
