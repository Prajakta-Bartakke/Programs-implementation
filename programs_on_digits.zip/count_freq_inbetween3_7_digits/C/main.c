/*
 problem statement:  write a program which accepts number from user and returs frequency of digits in between 3 and 7 that number
*/
#include"header.h"
int main()
{
 int iVal=0;
 int iRet=0;
 
 printf("enter number:");
 scanf("%d",&iVal);
 
 iRet=Frequency(iVal);
 
 printf("frequency of digits in between 3 and 7  in the number is:%d\n",iRet);
 
 return 0;
}
