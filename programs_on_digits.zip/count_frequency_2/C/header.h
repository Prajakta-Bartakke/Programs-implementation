#include<stdio.h>

int Frequency(int);
