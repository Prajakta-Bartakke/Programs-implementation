#include"header.h"

////////////////////////////////////////////////
//
//function name:	CountDiff
//input:		integer
//return value:	integer
//description:		used to return differnce between sum of even digits and odd digits
//author:		Prajakta Aditya Bartakke
//date:		4 aug 2020
/////////////////////////////////////////////////

/*int CountDiff(int iNo)
{
 int iDigit=0;
 int iSum1=0,iSum2=0;
 if(iNo<0)
 {
  iNo=-iNo;
 }
 while(iNo!=0)
 {
  iDigit=iNo%10;
  
  if((iDigit%2)==0)
  {
   iSum1=iSum1+iDigit;
  }
  else if((iDigit%2)!=0)
  {
   iSum2=iSum2+iDigit;
  }
  iNo=iNo/10;
  }
  return (iSum1-iSum2);

}*/

int CountDiff(int iNo)
{
 int iDigit=0;
 int SumDiff=0;
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 while(iNo!=0)
 {
  iDigit=iNo%10;
  
  if((iDigit%2)==0)
  {
   SumDiff=SumDiff+iDigit;
  }
  else
  {
   SumDiff=SumDiff-iDigit;
  }
  
  iNo=iNo/10;
  }
  
  return SumDiff;
}
