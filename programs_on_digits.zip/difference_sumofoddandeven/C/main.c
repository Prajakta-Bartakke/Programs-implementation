/*
 problem statement:  write a program which accepts number from user and returns the diffrenece between sum of even and sum of odd digits
*/
#include"header.h"
int main()
{
 int iVal=0;
 int iRet=0;
 
 printf("enter number:");
 scanf("%d",&iVal);
 
 iRet=CountDiff(iVal);
 
 printf("diffrence is:%d\n",iRet);
 
 return 0;
}
