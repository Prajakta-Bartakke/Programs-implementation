#include<stdio.h>

int Multiplication(int);
