#include"header.h"

////////////////////////////////////////////////
//
//function name:	Multiplication
//input:		integer
//return value:	integer
//description:		used to return multiplication of digits
//author:		Prajakta Aditya Bartakke
//date:		4 aug 2020
/////////////////////////////////////////////////

int Multiplication(int iNo)
{
 int iDigit=0;
 int iMul=1;
 
 while(iNo!=0)
 {
  iDigit=iNo%10;
  
  iMul=iMul*iDigit;
  
  iNo=iNo/10;
 }
 
 return iMul;
 
}
