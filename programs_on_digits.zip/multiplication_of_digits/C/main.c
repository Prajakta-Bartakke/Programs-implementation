/*
 problem statement:  write a program which accepts number from user and returs multiplication of the digits
*/
#include"header.h"
int main()
{
 int iVal=0;
 int iRet=0;
 
 printf("enter number:");
 scanf("%d",&iVal);
 
 iRet=Multiplication(iVal);
 
 printf("multipliaction of digits in number is:%d\n",iRet);
 
 return 0;
}
