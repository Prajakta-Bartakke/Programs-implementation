/*
 problem statement:  write a program which accepts number from user and check whether number contains 0 or not
*/
#include"header.h"
int main()
{
 int iVal=0;
 BOOL bRet=FALSE;
 
 printf("enter number:");
 scanf("%d",&iVal);
 
 bRet=ChkZero(iVal);
 
 if(bRet==TRUE)
 {
  printf("there is zero\n");
 }
 else
 {
  printf("there is no zero\n");
 }
 
 return 0;
}
