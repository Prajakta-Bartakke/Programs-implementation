#include"header.h"

////////////////////////////////////////////////
//
//function name:	ChkZero
//input:		integer
//return value:	boolean
//description:		used to check whether our number contains 0 or not
//author:		Prajakta Aditya Bartakke
//date:		4 aug 2020
/////////////////////////////////////////////////

BOOL ChkZero(int iNo)
{
 int iDigit=0;
 int iCnt=0;
 
 while(iNo!=0)
 {
  iDigit=iNo%10;
  
  if(iDigit==0)
  {
   iCnt++;
  }
  iNo=iNo/10;
 }
 if(iCnt>0)
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
 
}
