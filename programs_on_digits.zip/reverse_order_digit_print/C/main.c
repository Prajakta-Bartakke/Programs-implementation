/*
 problem statement:  write a program which accepts number from user and print the number in reverse order
*/
#include"header.h"
int main()
{
 int iVal=0;
 
 printf("enter number:");
 scanf("%d",&iVal);
 
 DisplayRev(iVal);
 
 return 0;
}
