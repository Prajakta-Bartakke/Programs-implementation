#include<stdio.h>

void DisplayRev(int);
