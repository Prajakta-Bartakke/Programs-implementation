#include"header.h"

////////////////////////////////////////////////
//
//function name:	DisplayRev
//input:		integer
//return value:	none
//description:		used to display the number in reverse order
//author:		Prajakta Aditya Bartakke
//date:		4 aug 2020
/////////////////////////////////////////////////

void DisplayRev(int iNo)
{
 int iDigit=0;
  if(iNo<0)
  {
   iNo=-iNo;
  }
 while(iNo!=0)
 {
  iDigit=iNo%10;
  
  printf("%d\n",iDigit);
  
  iNo=iNo/10;
  
 }
 
}
