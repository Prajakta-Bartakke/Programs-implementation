/* 
 problem statemnt: accept character from user and check whether vowel or not
*/
#include"header.h"
int main()
{
 char cVal='\0';BOOLEAN bRet=FALSE;
 
 printf("enter character:\n");
 scanf("%c",&cVal);
 
 bRet=CheckVowel(cVal);
 
 if(bRet==TRUE)
 {
  printf("vowel\n");
 }
 else
 {
  printf("not a vowel\n");
 }
 
 return 0;
}
