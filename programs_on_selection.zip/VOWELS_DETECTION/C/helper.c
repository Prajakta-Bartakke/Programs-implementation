#include"header.h"

///////////////////////////////////////////////
//
//function name:	CheckVowel
//input:		character
//return value:	boolean
//description:		used to check character is vowel or not
//author:		Prajakta Aditya Bartakke
//date:		1 aug 2020
///////////////////////////////////////////////////

BOOLEAN CheckVowel(char cVal)
{

 if((cVal=='a'   ||   cVal=='A')   ||   (cVal=='e'   ||   cVal=='E')   ||  (cVal=='i'   ||   cVal=='I')    ||   (cVal=='o'   ||   cVal=='O')    ||   (cVal=='u'   ||   cVal=='U'))
 {
   return TRUE;
 }
 else
 {
   return FALSE;
 }
}
