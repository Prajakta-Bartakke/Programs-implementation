/* problem statemnt:  write a program which accpets one number from user and check whether that number is greater than 100 or not.*/

#include"header.h"
int main()
{
  int iVal=0;
  BOOL bRet=FALSE;
  
  printf("enter number:\n");
  scanf("%d",&iVal);
  
  bRet=ChkGreater(iVal);
  
  if(bRet==TRUE)
  {
   printf("greater\n");
  }
  else
  {
   printf("smaller\n");
  }
  return 0;
 }
  
