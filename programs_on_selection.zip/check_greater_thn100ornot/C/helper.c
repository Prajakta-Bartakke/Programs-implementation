#include"header.h"

///////////////////////////////////////////////////////
//
//function name:		ChkGreater
//input:			integer
//return value:		boolean
//description:			used to check whether the number is greater than 100 or not
//author:			Prajakta Aditya Bartakke
//date:			5 aug 2020
//////////////////////////////////////////////////////

BOOL ChkGreater(int iNo)
{
 if(iNo>100)
 {
  return TRUE;
 }
 else
 {  
  return FALSE;
 }
} 

