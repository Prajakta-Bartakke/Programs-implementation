#include"header.h"

////////////////////////////////////////////////////////
//
//function name:		CountDigit
//input:			integer
//return value:		integer
//description:			used to count the digits of a number
//author:			Prajakta Aditya Bartakke
//date:			6 aug 2020
////////////////////////////////////////////////////////

int CountDigit(int iNo)
{

 /*if(iNo<0)
 {
  iNo=-iNo;
 }*/
 
 int iCnt=0;
 
 while(iNo!=0)
 {
  iNo=iNo/10;
  
  iCnt++;
 }
 
 return iCnt;
}

////////////////////////////////////////////////////////
//
//function name:		Display
//input:			integer
//return value:		none
//description:			used to display the word of the number
//author:			Prajakta Aditya Bartakke
//date:			6 aug 2020
////////////////////////////////////////////////////////

void Display(int iNo)
{
  if(iNo<0)
  {
   iNo=-iNo;
  }
  int iCnt=CountDigit(iNo);
  
  if(iCnt==1)
  {
    if(iNo==0)
    {
     printf("zero\n");
    }
    else if(iNo==1)
    {
     printf("one\n");
    }
    else if(iNo==2)
    {
     printf("two\n");
    }
    else if(iNo==3)
    {
     printf("three\n");
    }
    else if(iNo==4)
    {
     printf("four\n");
    }
    else if(iNo==5)
    {
     printf("five");
    }
    else if(iNo==6)
    {
     printf("six\n");
    }
    else if(iNo==7)
    {
     printf("seven\n");
    }
    else if(iNo==8)
    {
     printf("eight\n");
    }
    else if(iNo==9)
    {
     printf("nine\n");
    }
  }
  else 
  {
   printf("invalid input\n");
  }
}
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  


