/*
 problem statemnt:   write aprogram which accpet a single digit number and print it to word
*/
#include"header.h"
int main()
{
  int iVal=0;
  
  printf("enter a sigle digit number:\n");
  scanf("%d",&iVal);
  
  Display(iVal);
  
  return 0;
}
