#include<stdio.h>

int CountDigit(int);

void Display(int);
