/*

 problem statemnt:  accept a character from user and convert to its opposite case
 
 input : A		output: a
 input : c		output: C
 
*/
#include"header.h"
int main()
{
 char cVal='\0';
 
 printf("enter character:\n");
 scanf("%c",&cVal);
 
 DisplayConvert(cVal);
 
 return 0;
}
