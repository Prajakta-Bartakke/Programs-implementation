#include"header.h"

//////////////////////////////////////////////////
//
//function name:	DisplayConvert
//input:		character
//return value:	none
//description:		used to convert charater to opposite case
//author:		Prajakta Aditya BArtakke
//date: 		1 aug 2020
/////////////////////////////////////////////////


void DisplayConvert(char cVal)
{
 if((int)cVal<=90  ||  (int)cVal>=65)
 {
  char cChar=(int)cVal;
  printf("%c\n",(cChar+32));
 }
 if((int)cVal<=122  ||  (int)cVal>=97)
 {
  printf("%c\n",((int)cVal-32));
 }
 
 
}









