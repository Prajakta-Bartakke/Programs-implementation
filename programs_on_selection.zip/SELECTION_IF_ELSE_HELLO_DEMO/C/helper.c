#include"header.h"

///////////////////////////////////////////
//function name:	Display
//input:		integer
//return:		none
//descripton:		display hello or demo according to condition
//author:		Prajakta Aditya Bartakke
//date:		27 july 2020
///////////////////////////////////////////

void Display(int iNo)
{

 if(iNo<10)
 {
  printf("hello\n");
 }
 
 else
 { 
  printf("demo\n");
 }
}


