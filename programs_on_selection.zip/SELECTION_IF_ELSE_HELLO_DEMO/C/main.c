/*
  problem statement:  accept one number from user and if that number is less than 10 then print hello otherwise print demo
*/

#include"header.h" 
int main()
{
 int iVal=0;
 
 printf("enter a number:\n");
 
 scanf("%d",&iVal);
 
 Display(iVal);
 
 return 0;
} 
 
 
