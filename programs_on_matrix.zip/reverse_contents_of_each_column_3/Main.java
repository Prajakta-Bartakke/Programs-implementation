import java.util.Scanner;

class matrix
{
 void Display(int arr[][])
 {
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    System.out.print(arr[i][j]+"\t");
   }
   System.out.println();
  }
 }
 
 void Reverse(int[][] arr,int row,int col)
 {
  int temp=0;
  int k=0;
  
  for(int j=0;j<col;j++)            //column wise fira
  {
   k=0;
   for(int i=arr.length-1;i>=(arr.length/2);i--)
   {
    temp=arr[i][j];
    arr[i][j]=arr[k][j];
    arr[k][j]=temp;
    
    k++;
   }
  }

 } 
}
class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("enter number of rows:");
  int row=sobj.nextInt();
  
  System.out.println("enter number of columns:");
  int col=sobj.nextInt();
  
  int arr[][]=new int[row][col];
  System.out.println("enter elements:");
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    arr[i][j]=sobj.nextInt();
   }
  }
  
 matrix obj=new matrix();

 System.out.println("matrix before reversing columns:");
 obj.Display(arr);
 
 System.out.println("matrix after reversing columns:");
 obj.Reverse(arr,row,col);
 obj.Display(arr);
 
 }
}
