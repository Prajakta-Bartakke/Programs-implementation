import java.util.Scanner;

class matrix
{
 int Largest(int[][] arr)
 {
  int max=0;
  int val1=0,val2=0;
  int k=0;
  
  for(int i=0;i<arr.length;i++)
  {
   k=arr[i].length-1;
   
   for(int j=0;j<arr[i].length;j++)
   {
    if(i==j)
    {
     val1=arr[i][j];
    }
    else if(j==k-i)
    {
     val2=arr[i][j];
    }
   }
   
   if((val1>val2) && (val1>max))                       //max=9
   {
    max=val1;
   }
   else if((val2>val1) && (val2>max))                   
   {
    max=val2;
   }
   
  }
  return max; 
 }
 

 void Display(int arr[][])
 {
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    System.out.print(arr[i][j]+"\t");
   }
   System.out.println();
  }
 }

}
class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("enter number of rows:");
  int row=sobj.nextInt();
  
  System.out.println("enter number of columns:");
  int col=sobj.nextInt();
  
  int arr[][]=new int[row][col];
  
  System.out.println("enter elements:");
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    arr[i][j]=sobj.nextInt();
   }
  }
  
 matrix obj=new matrix();

 obj.Display(arr);
 
 int ret=obj.Largest(arr);
 
 System.out.println("largest number from both diagonal is :"+ret);
 
 }
}
