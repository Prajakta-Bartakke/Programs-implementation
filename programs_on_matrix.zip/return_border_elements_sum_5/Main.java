import java.util.Scanner;
import java.lang.Math;
class matrix
{
 void Display(int arr[][])
 {
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    System.out.print(arr[i][j]+"\t");
   }
   System.out.println();
  }
 }
 
 int sumborder(int[][] arr)
 {
  int sum=0;
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    if(i==0 || i==arr.length-1)            //for first row and last row j purna firnar
    {
     sum=sum+arr[i][j];
    }
    else if((i>0 && i<arr.length-1) && (j==0 || j==arr[i].length-1))
    {
     sum=sum+arr[i][j];
    }
   }
  }
  
  return sum;
 }   
}
class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("enter number of rows:");
  int row=sobj.nextInt();
  
  System.out.println("enter number of columns:");
  int col=sobj.nextInt();
  
  int arr[][]=new int[row][col];
  System.out.println("enter elements:");
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    arr[i][j]=sobj.nextInt();
   }
  }
  
 matrix obj=new matrix();

 System.out.println("matrix:");
 obj.Display(arr);
 
 int sum=obj.sumborder(arr);
 
 System.out.println("sum of border elements: "+sum);
 
 }
}
