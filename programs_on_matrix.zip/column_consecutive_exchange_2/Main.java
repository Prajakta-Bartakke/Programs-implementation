/*

problem statement:
	accept matrix from user and swap the contents of consecutive columns
	
input:
	11	21	51	20
	10	20	30	78	
	74	36	20	21	
	45	63	31	47
	
output:
	21	11	20	51
	20	10	78	30
	36	74	21	20
	63	45	47	31
*/

import java.util.Scanner;

class matrix
{
 void swapcol(int[][] arr)
 {
  int temp=0;
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    if((j%2)==0)
    {
     temp=arr[i][j];
     arr[i][j]=arr[i][j+1];
     arr[i][j+1]=temp;
    }  
   }
  }
 
 }
 
 void Display(int[][] arr)
 {
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    System.out.print(arr[i][j]+"\t");
   }
   System.out.println();
  }
 }
 
 
}

class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("enter number of rows:");
  int row=sobj.nextInt();
  
  System.out.println("enter number of columns:");
  int col=sobj.nextInt();
  
  int[][] arr=new int[row][col];
  
  System.out.println("enter elements:");
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
     arr[i][j]=sobj.nextInt();
    }
   }
   
   matrix obj=new matrix();
   
   System.out.println("matrix before swapping columns:");
   obj.Display(arr);
   
   obj.swapcol(arr);
   
   System.out.println("matrix after swapping columns:");
   obj.Display(arr);
   

 
 }
}






















