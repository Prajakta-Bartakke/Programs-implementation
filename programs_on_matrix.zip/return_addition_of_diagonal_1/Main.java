import java.util.Scanner;

class matrix
{
 int addDiagonal(int[][] arr)
 {
  int sum=0;
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    if(i==j)
    {
     sum=sum+arr[i][j];
    }
   }
  }
  return sum;
 }

}

class Main
{
 public static void main(String arg[])
 {
  matrix obj=new matrix();
  
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("enter row:");
  int row=sobj.nextInt();
  
  System.out.println("enter columns:");
  int col=sobj.nextInt();
  
  int[][] arr=new int[row][col];
  
  System.out.println("enter elements:");
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    arr[i][j]=sobj.nextInt();
   }
  }
  
  int sum=obj.addDiagonal(arr);
  
  System.out.println("sum of diagonal elements is:"+sum); 
 }
}
