import java.util.Scanner;

class matrix
{
 int frequency(int[][] arr,int no)
 {
  int cnt=0;
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    if(arr[i][j]==no)
    {
     cnt++;
    }
   }
  }
  return cnt; 
 }
 
 void Display(int arr[][])
 {
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    System.out.print(arr[i][j]+"\t");
   }
   System.out.println();
  }
 }
 
 
 
 
}
class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("enter number of rows:");
  int row=sobj.nextInt();
  
  System.out.println("enter number of columns:");
  int col=sobj.nextInt();
  
  int arr[][]=new int[row][col];
  
  System.out.println("enter elements:");
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    arr[i][j]=sobj.nextInt();
   }
  }
  
 matrix obj=new matrix();
 
 System.out.println("enter elements whose frequency is to be find:");
 int no=sobj.nextInt();
 obj.Display(arr);
 int ret=obj.frequency(arr,no);
 
 System.out.println("frequency of "+no+" is :"+ret);
 
 }
}
