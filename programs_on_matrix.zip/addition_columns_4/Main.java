import java.lang.*;
import java.util.*;
class Matrix
{
    void SumColumn(int arr[][],int row,int col)
    {
      int sum=0;
      int i=0,j=0;
      
      for(j=0;j<col;j++)
      {
       for(i=0;i<row;i++)
       {
        sum=sum+arr[i][j];
       }
       System.out.println(sum);
       sum=0;
      }
        
      } 
    }

class Main
{
    public static void main(String arg[])
    {
        Scanner sobj = new Scanner(System.in);
        System.out.println("Enter number of rows");
        int row = sobj.nextInt();
        System.out.println("Enter number of columns");
        int col = sobj.nextInt();
        int arr[][] = new int[row][col];
        System.out.println("Enter the elements");
        for(int i = 0; i<arr.length; i++)
        {
            System.out.println("Row with index : "+i);
            for(int j = 0; j< arr[i].length; j++)
            {
                System.out.println("Enter the element :"+i+" , "+j);
                arr[i][j] = sobj.nextInt();
            }
        }
        Matrix mobj = new Matrix();
        mobj.SumColumn(arr,row,col);
    }
}
