import java.util.Scanner;

class matrix
{
 void Display(int arr[][])
 {
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    System.out.print(arr[i][j]+"\t");
   }
   System.out.println();
  }
 }
 
 boolean chkidentity(int[][] arr,int row,int col)
 {
  int cnt=0,count=0;
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    if(i==j && arr[i][j]==1)
    {
     cnt++;
    }
    else if(arr[i][j]==0)
    {
     count++;
    }
   }
  }
  if((count+cnt)==row*col)
  {
   return true;
  }
  else
  {
   return false;
  }
     
}
  
}
class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("enter number of rows:");
  int row=sobj.nextInt();
  
  System.out.println("enter number of columns:");
  int col=sobj.nextInt();
  
  int arr[][]=new int[row][col];
  System.out.println("enter elements:");
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    arr[i][j]=sobj.nextInt();
   }
  }
  
 matrix obj=new matrix();

 boolean ret=obj.chkidentity(arr,row,col);
 
 if(ret==true)
 {
  System.out.println("Identity matrix");
 }
 else
 {
  System.out.println("not identity matrix");
 }
 }
}
