import java.util.Scanner;

class matrix
{
 void Display(int arr[][])
 {
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    System.out.print(arr[i][j]+"\t");
   }
   System.out.println();
  }
 }
 
 void Transpose(int[][] arr,int[][] brr)
 {
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
     brr[i][j]=arr[j][i];
    
   }
 }
 } 
}
class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("enter number of rows:");
  int row=sobj.nextInt();
  
  System.out.println("enter number of columns:");
  int col=sobj.nextInt();
  
  int arr[][]=new int[row][col];
  int brr[][]=new int[row][col];
  System.out.println("enter elements:");
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    arr[i][j]=sobj.nextInt();
   }
  }
  
 matrix obj=new matrix();

 System.out.println("matrix before transpose:");
 obj.Display(arr);
 
 System.out.println("matrix after transpose:");
 obj.Transpose(arr,brr);
 obj.Display(brr);
 
 }
}
