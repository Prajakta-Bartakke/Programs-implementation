import java.util.Scanner;
import java.lang.Math;
class matrix
{
 void Display(int arr[][])
 {
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    System.out.print(arr[i][j]+"\t");
   }
   System.out.println();
  }
 }
 
 int Trace(int[][] arr)
 {
  int trace=0;
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    if(i==j)
    {
     trace=trace+arr[i][j];
    }
   }
  }
  return trace;
 }
 
 double Normal(int[][] arr)
 {
  double sum=0;
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    sum=sum+arr[i][j];
   }
  }
  
  return (Math.sqrt(sum));
  

 }
 
 
  
}
class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("enter number of rows:");
  int row=sobj.nextInt();
  
  System.out.println("enter number of columns:");
  int col=sobj.nextInt();
  
  int arr[][]=new int[row][col];
  System.out.println("enter elements:");
  
  for(int i=0;i<arr.length;i++)
  {
   for(int j=0;j<arr[i].length;j++)
   {
    arr[i][j]=sobj.nextInt();
   }
  }
  
 matrix obj=new matrix();

 System.out.println("matrix:");
 obj.Display(arr);
 
 int trace=obj.Trace(arr);
 
 System.out.println("trace of matrix is :" + trace);
 
 double normal=obj.Normal(arr);
 
 System.out.println("trace of matrix is :" + normal);
 }
}
