/*

problem statement:
	accept string from user and return the freq of small letters and capital letters
*/

#include<stdio.h>
#define INVALID -1

int SmallCount(char *ptr)
{
 int iCnt=0,i=0;
 
 while((*(ptr+i))!='\0')
 {
  if(((*(ptr+i))>='a')&&((*(ptr+i))<='z'))
  {
   iCnt++;
  }
  i++;
 }
 return iCnt;
}

int CapCount(char *ptr)
{
 int iCnt=0,i=0;
 
 while((*(ptr+i))!='\0')
 {
  if(((*(ptr+i))>='A')&&((*(ptr+i))<='Z'))
  {
   iCnt++;
  }
  i++;
 }
 return iCnt;
}

int Difference(char *arr)               //istri dryclean separate..(reusability)
{
 int iSmallFreq=0,iCapFreq=0;
 
 int iCnt=0,iCount=0;
 int i=0;
 
 while((*(arr+i))!='\0')                                                  
 {
  iCount++;
  if((((*(arr+i))>='A')&&((*(arr+i))<='Z')) || (((*(arr+i))>='a')&&((*(arr+i))<='z'))   ||  (*(arr+i))==' ')   //filter digits kinva special symbols sathi
  {
   iCnt++;
  }
  i++;                                                                                    //ikde arr++ kela tr pudhe SmallCount ya function la base address pass hota nahi
 }
 if(iCount==iCnt)
 {
  
 iSmallFreq=SmallCount(arr);
 
 iCapFreq=CapCount(arr);
 
 return (iSmallFreq-iCapFreq);
 }
 else
 {
  return INVALID;
  
 }
}


int main()
{
 char arr[30];
 int iDiff=0;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 iDiff=Difference(arr);
 
 if(iDiff==INVALID)
 {
  printf("Error:invalid input,string should only contain alphabets.....\n");
 }
 else
 {
 printf("differenece is : %d \n",iDiff);
 }
 return 0;
}
 



