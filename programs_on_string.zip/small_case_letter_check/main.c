/*

problem statement:  accept character from user and check whether it is small letter or not

*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0;

BOOL ChkSmall(char cVal)
{
 if((cVal>='a')&&(cVal<='z'))
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
}

int main()
{
 char ch='\0';
 BOOL bRet=FALSE;
 
 printf("enter character:\n");
 scanf("%c",&ch);
 
 bRet=ChkSmall(ch);
 
 if(bRet==TRUE)
 {
  printf("small letter\n");
 }
 else
 {
  printf("not a small letter\n");
 } 

 return 0;
}
