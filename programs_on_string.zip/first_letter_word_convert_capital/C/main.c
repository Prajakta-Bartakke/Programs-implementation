/*

problem statement: accept a string from user and make the first letter of every word capital.

*/
#include<stdio.h>
void CapLetter(char *arr)
{
 int i=0;
 
 while(arr[i]!='\0')
 {
  if((i==0 && arr[i]!=' ')  ||  (arr[i]==' '  &&   arr[i+1]!=' '))
  {
   if(i==0)
   {
    if(arr[0]>='a' && arr[0]<='z')
    {
     arr[0]=arr[0]-32;
    }
   }
   else
   {
    if(arr[i+1]>='a' && arr[i+1]<='z')
    {
     arr[i+1]=arr[i+1]-32;
    }
   } 
  }
  i++;
 }
 //printf("%s\n",arr);

}


int main()
{
 char arr[100];
 //int iRet=0;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 CapLetter(arr);
 
 printf("%s\n",arr); 
 
 return 0;
}
