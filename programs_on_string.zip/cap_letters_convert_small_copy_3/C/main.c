/*
problem statement:accpt kara string and capital letter convert kara small mdhe convert karun mag copy kara dusrya string madhe	
*/

#include<stdio.h>
#include<stdlib.h>
void strCpySmall(char *arr,char *brr)
{
 int iCnt=0,iMem=0;
 
 while((*(arr+iCnt))!='\0')
 {
  if(((*(arr+iCnt))>='A')&&((*(arr+iCnt))<='Z'))
  {
   iMem++;
   brr=(char*)realloc(brr,sizeof(char)*iMem);
   (*(brr+iCnt))=(*(arr+iCnt))+32;
  }
  else
  {
   iMem++;
   brr=(char*)realloc(brr,sizeof(char)*iMem);
   (*(brr+iCnt))=(*(arr+iCnt));
  }
  iCnt++;
 }
 printf("%s\n",brr);
 
}

int main()
{
 char arr[30];
 //char brr[30];
 char *brr=NULL;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 strCpySmall(arr,brr);
 
 //printf("%s\n",brr);
 
 return 0;
}
