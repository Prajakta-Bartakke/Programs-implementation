/*
problem statement: accept division from user and print the timing of exam
*/

#include<stdio.h>

void DisplayTime(char cValue)
{
 if(cValue=='A' || cValue=='a')
 {
  printf("your exam time is 7 am\n");
 }
 else if(cValue=='B' || cValue=='b')
 {
  printf("your exam time is 8.30 am\n");
 }
 else if(cValue=='C' || cValue=='C')
 {
  printf("your exam time is 9.20 am\n");
 }
 else if(cValue=='D' || cValue=='d')
 {
  printf("your exam time is 10.30 am\n");
 }
 else
 {
  printf("no such division present\n");
 }
} 

int main()
{
 char ch='\0';
 
 printf("enter division:\n");
 scanf("%c",&ch);
 
 DisplayTime(ch);
 
 return 0;
}
