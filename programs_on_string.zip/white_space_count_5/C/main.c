/*

problem statement: accept string from user and return the count of white spaces in string

*/
#include<stdio.h>


int CountSpace(char ptr[])
{
 int i=0,iCnt=0;
 
 while(ptr[i]!='\0')
 {
  if(ptr[i]==' ')
  {
   iCnt++;
  }
  i++;
 }
 return iCnt;
}
 
int main()
{
 char arr[30];
 int iRet=0;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 iRet=CountSpace(arr);
  
 printf("balnk spaces in string are:%d\n",iRet);
 
 return 0;
}
 
