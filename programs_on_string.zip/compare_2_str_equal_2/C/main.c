/*

problem statement: accept 2 strings from user and compare they are equal or not

input:
	marvellous infosystems
	marvellous infosystems
	
output:	
	TRUE
	
*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE -1
#define ERRORMEMORY -3

BOOL strCmpX(char *arr,char *brr)
{
 if(arr==NULL || brr==NULL)
 {
  return ERRORMEMORY;
 }
 int iCnt1=0,iCnt2=0;
 
 while(arr[iCnt1]!='\0')
 {
  iCnt1++;
 }
 while(brr[iCnt2]!='\0')
 {
  iCnt2++;
 }
 if(iCnt1!=iCnt2)
 {
  return FALSE;
 }
 int i=0;
 int iVal=0;
 
 for(i=0;i<iCnt1;i++)
 {
  if(arr[i]==brr[i])
  {
    iVal++;
  }
 }
 
 if(iVal==iCnt1)
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
 }
int main()
{
 char arr[30];
 char brr[30];
 BOOL bRet=FALSE;
 
 printf("enter first string:\n");
 scanf("%[^'\n']s",arr);
 
 printf("enter second string:\n");
 scanf(" %[^'\n']s",brr);
 
 bRet=strCmpX(arr,brr);
 
 if(bRet==TRUE)
 {
  printf("strings are equal\n");
 }
 else if(bRet==ERRORMEMORY)
 {
  printf("memory pblm\n");
 }
 else
 {
  printf("strings not equal\n");
 }
 
 return 0;
}
