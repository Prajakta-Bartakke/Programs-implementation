/*

problem statement: accept character from user and return the count of small characters in it

*/

#include<stdio.h>

int CountSmall(char *ptr)
{
 int i=0,iCnt=0;
 
 while((*(ptr+i))!='\0')
 {
  if(((*(ptr+i))>='a')&&((*(ptr+i))<='z'))
  {
   iCnt++;
  }
  i++;
 }

 return iCnt;
}

int main()
{
 char arr[30];
 int iRet=0;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 iRet=CountSmall(arr);
 
 printf("count of small letters in string is:%d\n",iRet);
 
 return 0;
}
