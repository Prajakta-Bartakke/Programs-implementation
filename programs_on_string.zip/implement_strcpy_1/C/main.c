/*

problem statement:accept string from user and copy that string to other string

*/

#include<stdio.h>
#include<stdlib.h>

void strcpyX(char *cpy,char*arr)
{
 int i=0;
 int iCnt=0;
 
 cpy=(char*)malloc(sizeof(int)*iCnt);
 
 while(arr[i]!='\0')
 {
  iCnt++;
  
  cpy=(char*)realloc(cpy,sizeof(char)*iCnt);
  
  cpy[i]=arr[i];
  
  printf("%c",cpy[i]);
  
  i++;
 }
 
 /*i=0;
 
 for(i=0;i<iCnt;i++)
 {
  printf("%c",cpy[i]);
 }*/
 }


int main()
{
 char arr[30];
 char *cpy='\0';
 
 printf("enter string:\n");
 scanf("%[^'\n']",arr);
 
 strcpyX(cpy,arr);
 
 printf("\n");
 
 return 0;
}
 
 
 
