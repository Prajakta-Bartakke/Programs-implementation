/*

problem statement: accept string from user and convert into lower case

*/

#include<stdio.h>
#include<stdlib.h>

#define INVALID -1

void DisplaySmall(char *arr)
{
 int i=0;
 int iCount=0;			//complete string mdhe character kiti ahet mojayla
 int iCnt=0;			//alphabet ahe ki nahi check karayla
 
 while((*(arr+i))!='\0')                                                  
 {
  iCount++;
  if((((*(arr+i))>='A')&&((*(arr+i))<='Z')) || (((*(arr+i))>='a')&&((*(arr+i))<='z'))   ||  (*(arr+i))==' ')   //filter digits kinva special symbols sathi
  {
   iCnt++;
  }
  i++;                                                                                    
 } 
 
 if(iCount!=iCnt)
 {
  printf("Error:invalid input,string should only contain alphabet....");
  return;
 }
 
 i=0;
 char *ptr=(char*)malloc(sizeof(char)*iCnt);
 
 for(i=0;i<iCnt;i++)
 {
  if(((*(arr+i))>='A')&&((*(arr+i))<='Z'))
  {
   ptr[i]=arr[i]+32;
  }
  else if(((*(arr+i))>='a')&&((*(arr+i))<='z'))
  {
   ptr[i]=arr[i];
  }
  else if(arr[i]==' ')
  {
   ptr[i]=' ';
  }
  }
  i=0;
  for(i=0;i<iCnt;i++)
  {
   printf("%c",ptr[i]);
  }
}



int main()
{
 char arr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 DisplaySmall(arr);
 printf("\n");
 
 return 0;
}
