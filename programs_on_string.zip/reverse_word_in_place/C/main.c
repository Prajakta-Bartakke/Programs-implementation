/*
problem statement: accept string from user and reverse the word in a place

*/


#include<stdio.h>

void Reverse(char *arr)
{
 if(arr==NULL)
 {
  return;
 }
 int i=0;
 int iCntf=0,iCntb=0;
 char temp='\0';
 while(arr[i]!='\0')
 {
  if( (i==0 && arr[i]!=' ') || (arr[i]!=' '  &&  arr[i-1]==' '))
  {
   iCntf=i;
  }
  
  if(arr[i]==' ' && arr[i-1]!=' ')
  {
   iCntb=(i-1);
  }
  
  if(arr[i]==' '  &&  arr[i+1]!=' ')
  {
   while(iCntb-iCntf>=0)
   {
    temp=arr[iCntb];
    arr[iCntb]=arr[iCntf];
    arr[iCntf]=temp;
   
    iCntf++;
    iCntb--;
   }
  }
  i++;
 } 
 i--;
 iCntb=i;
 
 while(iCntb-iCntf>=0)
 {
  temp=arr[iCntb];
  arr[iCntb]=arr[iCntf];
  arr[iCntf]=temp;
   
  iCntf++;
  iCntb--;
s   }
}
 

int main()
{
 char arr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 Reverse(arr);
 
 printf("%s\n",arr);
 
 return 0;
}































































/*printf("inside reverse\n");
 int i=0;
 char *iStart;
 char *iEnd;
 char temp='\0';
 char *iArr=arr;
 int iCntf=0,iCntb=0;
 
 while(arr[i]!='\0')
 {
  if(((i==0 && arr[i]!=' ') || ((((*arr)!=' ')  &&   ((*(arr-1))==' ')))))
  {
   printf("inside first if\n");
   iStart=arr;
   iCntf=i;
  }
  if((arr[i]==' ') && (arr[i+1]!=' '))
  {
   /*printf("second if\n");
   iEnd=arr--;
   iCntb=i;
  }
  if(((*arr)==' ')&&((*(arr+1))!=' '))
  {
   while(iEnd-iStart>=0)
   {
   temp=(*iEnd);
   (*iEnd)=(*iStart);
   (*iStart)=temp;
   iStart++;
   iEnd--;
  }
  while(iCntb-iCntf>=0)
   {
   temp=arr[iCntb];
   arr[iCntb]=arr[iCntf];
   arr[iCntf]=temp;
   
   iCntf++;
   iCntb--;
   
   
   }
printf("%s\n",iArr);
}
  }*/
