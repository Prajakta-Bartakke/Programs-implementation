/*

problem statement:accept string from user and reverse string by toggling the case in a place

---------------------------------------------------------------

input:
	aCBdef
	
output:
	FEDcbA
	
---------------------------------------------------------------

input:
	MarVeLLous
	
output:
	SUOllEvRAm
	
---------------------------------------------------------------

*/

#include<stdio.h>

void DisplayRevToggle(char *arr)
{
 if(arr==NULL)
 {
  return;
 }
 char *iStart=arr;
 char *iArr=arr;
 
 while((*arr)!='\0')
 {
  if((*arr)>='a' && (*arr)<='z')
  {
   (*arr)=(*arr)-32;
  }
  else if((*arr)>='A'  &&  (*arr)<='Z')
  {
   (*arr)=(*arr)+32;
  }
  arr++;
 }
 arr--;
 
 char *iEnd=arr;
 char temp='\0';
 
 while(iEnd-iStart>=0)
 {
  temp=(*iEnd);
  (*iEnd)=(*iStart);
  (*iStart)=temp;
  
  iStart++;
  iEnd--;  
  
 }
 printf("%s\n",iArr);
 
}

int main()
{
 char arr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);

 
 DisplayRevToggle(arr);

 
 return 0;
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
