/*
problem statement: accept a string from user and copy it into another string till the input number has given

*/

#include<stdio.h>
#include<stdlib.h>

void strcpyX(char *cpy,char*arr,int iNo)
{
 /*if(cpy==NULL || arr==NULL )
 {
  printf("Error:memory problem\n");
  return;
 }*/
 /*else if(iNo==0)
 {
  printf("Error:nothing will be copied,As input is 0");
 }*/
 int i=0;
 
 int iCnt=0;
 cpy=(char*)malloc(sizeof(char)*iCnt);
 while(arr[i]!='\0')
 {
  iCnt++;
  cpy=(char*)realloc(cpy,sizeof(char)*iCnt);
  i++;
 }
 if(iNo>iCnt)
 {
  i=0;
  
  for(i=0;i<iCnt;i++)
  {
   cpy[i]=arr[i];
  }
 }
 else
 {
  i=0;
  
  for(i=0;i<iNo;i++)
  {
   cpy[i]=arr[i];
  }

 }
 for(i=0;i<iCnt;i++)
 {
  printf("%c",cpy[i]);
 }
 }
  
int main()
{
 char arr[30];
 int iNo=0;
 char *cpy='\0';
 
 printf("enter a string:\n");
 scanf("%[^'\n']s",arr);
 
 printf("enter a number till that number string will be copied...\n");
 scanf("%d",&iNo);
 
 strcpyX(cpy,arr,iNo);
 
 return 0;
}
