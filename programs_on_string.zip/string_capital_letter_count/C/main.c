/*

problem statement:accept a string from user and return the count of capital letters in it

*/

#include<stdio.h>
#define INVALID -1

int CountCap(char *ptr)
{
 int i=0;
 int iCnt=0;
 
 while((*(ptr+i))!='\0')
 {
  if(((*(ptr+i))>='A')&&((*(ptr+i))<='Z'))
  {
   iCnt++;
  }
  i++;
 }
 return iCnt;
}

int main()
{
 char arr[30];
 int iRet=0;
 
 printf("enter a string:\n");
 scanf("%[^'\n']s",arr);
 
 iRet=CountCap(arr);
 
 printf("count of capital letters is %d\n",iRet);
 

 return 0;
}
