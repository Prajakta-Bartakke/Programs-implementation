/*

problem statement: accept a string from user and count the number of words

*/

#include<stdio.h>

int CountWords(char *arr)
{
 int i=0,iCountWord=0;
 
 while(arr[i]!='\0')
 {
  if((i==0 && arr[i]!=' ')  ||  (arr[i]==' '  &&   arr[i+1]!=' '))
  {
   iCountWord++;
  }
  i++;
 }
 
 return iCountWord;

}

int main()
{
 char arr[100];
 int iRet=0;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 iRet=CountWords(arr);
 
 printf("total number of words %d\n",iRet); 

 return 0;
}
