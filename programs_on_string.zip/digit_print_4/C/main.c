/*

problem statement:
		accpet string from user and print such characters which are not alphabet
		
*/

#include<stdio.h>

void DisplayNonAlpha(char ptr[])
{
 int i=0;
 while(ptr[i]!='\0')
 {
 if(ptr[i]>='0' && ptr[i]<='9')
 {
  printf("%c",ptr[i]);
 }
 i++;
 }
}
int main()
{
 char arr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 DisplayNonAlpha(arr);
 
 printf("\n");
 
 return 0;
}
