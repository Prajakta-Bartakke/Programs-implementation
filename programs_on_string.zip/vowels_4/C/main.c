/*

problem statement:	accept string from user and check whether it contains vowels or not

*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0
#define INVALID -1

BOOL ChkVowel(char *ptr)
{
 int iCnt=0,i=0;
 
 int iCount=0;                                             //saglya character cha count check karnyasathi
 
 int iCn=0;						     //jar alphabet asel tr count vadhvnyasathi   ....(mhnje iCount==iCn)mhnje string mdhe fakt alphabet ahey ka filter
 
 
 while((*(ptr+i))!='\0')                                                  
 {
  iCount++;
  if((((*(ptr+i))>='A')&&((*(ptr+i))<='Z')) || (((*(ptr+i))>='a')&&((*(ptr+i))<='z'))   ||  (*(ptr+i))==' ')   //filter digits kinva special symbols sathi
  {
   iCn++;
  }
  i++;                                                                                    
 }
 
 if(iCount!=iCn)
 {
  return INVALID;
 }
 
 i=0;
 while((*(ptr+i))!='\0')
 {
  if(((*(ptr+i))=='A') || ((*(ptr+i))=='a') || ((*(ptr+i))=='E') || ((*(ptr+i))=='e') || ((*(ptr+i))=='I') || ((*(ptr+i))=='i') || ((*(ptr+i))=='O') || ((*(ptr+i))=='o') || ((*(ptr+i))=='U') || ((*(ptr+i))=='u')) 
  {
   return TRUE;
   break;
  } 
  i++;
}

}

int main()
{
 char arr[30];
 BOOL bRet=FALSE;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 bRet=ChkVowel(arr);
 
 if(bRet==TRUE)
 {
  printf("contains vowel\n");
 }
 else if(bRet==INVALID)
 {
  printf("Error:inavlid input,string should only contain alphabet....\n");
 }
 else
 {
  printf("do not contain vowel\n");
 }

 return 0;
}
