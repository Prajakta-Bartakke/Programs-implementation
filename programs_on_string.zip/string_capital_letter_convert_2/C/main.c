/*

problem statement:accept string from user and convert ecah character into capital letter

*/
#include<stdio.h>
#include<stdlib.h>

void DisplayCap(char ptr[])
{
 int i=0,iCount=0,iCnt=0;
 
 while((*(ptr+i))!='\0')            
 {
  iCount++;
  
  if(((ptr[i]>='A')&&(ptr[i]<='Z'))  || ((ptr[i]>='a')&&(ptr[i]<='z'))  || (ptr[i]==' '))                  //filter sathi
  {
   iCnt++;
  }
  i++;
 }
 
 if(iCnt!=iCount)
 {
  printf("Error:invalid input,string should only contain alphabet....\n");
  return;
 }
 
 char *arr=(char*)malloc(sizeof(char)*iCnt);
 
 i=0;
 
 for(i=0;i<iCnt;i++)
 {
  if(ptr[i]>='A' && ptr[i]<='Z')
  {
   arr[i]=ptr[i];
  }
  else if(ptr[i]==' ')
  {
   arr[i]=' ';
  }
  else if(ptr[i]>='a' && ptr[i]<='z')
  {
   arr[i]=ptr[i]-32;
  }
 }
 
 for(i=0;i<iCnt;i++)
 {
  printf("%c",arr[i]);
 }
 
}
int main()
{
 char arr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 DisplayCap(arr);
 printf("\n");
 
 return 0;
}
