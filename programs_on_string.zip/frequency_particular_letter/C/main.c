/*
problem statement:accept string from user and also accpt character from user and return the frequency of that character
*/
#include<stdio.h>

#define INVALID -1
int Frequency(char arr[],char cVal)
{
 if(arr==NULL)
 {
  return INVALID;
 }
 int i=0;
 int iCount=0;
 
 while(arr[i]!='\0')
 {
  if(arr[i]==cVal)
  {
   iCount++;
  }
  i++;
 }
 return iCount;
}

int main()
{ 
 int iRet=0;
 char arr[30];
 char ch='\0';
 
 printf("enter string:\n");
 scanf("%[^\n]s",arr);
 
 printf("enter character:\n");
 scanf(" %c",&ch);
 
 iRet=Frequency(arr,ch);
 
 if(iRet==INVALID)
 {
  printf("Error:memory problem\n");
 }
 else
 {
 printf("frequency of character %c is %d\n",ch,iRet);
 }
 
 
 return 0;
}
 
 
