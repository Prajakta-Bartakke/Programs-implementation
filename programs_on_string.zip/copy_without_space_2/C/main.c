/*

problem statement: accpet string from user and copy characters without blank spaces

*/
#include<stdio.h>
#include<stdlib.h>

/*void strcpyX(char arr[],char brr[])
{
 int iCnt=0;
 int i=0;
 
 if(arr==NULL || brr==NULL)
 {
  return;
 }

 while(arr[iCnt]!='\0')
 {
  if(arr[iCnt]!=' ')
  {
   brr[i]=arr[iCnt];
   i++;
  }
  iCnt++;
 }
 brr[i]='\0';
}*/
 
 
void strcpyX(char *arr,char *brr)
{
 int iCnt=0,i=0,iMem=0;
 
 while((*(arr+iCnt))!='\0')
 {
  if((*(arr+iCnt))!=' ')
  {
   iMem++;
   brr=(char*)realloc(brr,sizeof(char)*iMem);
   (*(brr+i))=(*(arr+iCnt));
   i++;
  }
  iCnt++;
 }
 printf("%s\n",brr);
}
 
 
  
int main()
{
 char arr[100];
 //char brr[100];
 char *brr=NULL;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 strcpyX(arr,brr);
 
// printf("%s\n",brr);
 
 return 0;
}
 
