/*
problem statement:accept string from user and toggle character and display
*/

#include<stdio.h>
#include<stdlib.h>

void DisplayToggle(char ptr[])
{
 int iCount=0,iCnt=0;
 int i=0;
 
 while(ptr[i]!='\0')
 {
  iCount++;
  
  if((ptr[i]>='A' && ptr[i]<='Z')||(ptr[i]>='a' && ptr[i]<='z'))                                      //filter
  {
   iCnt++;
  }
  i++;
 }
 if(iCount!=iCnt)
 {
  printf("Error:invalid input,string should only contain alphabets\n");
  return;
 }
 char *arr=(char*)malloc(sizeof(char)*iCnt);
 
 i=0;
 for(i=0;i<iCnt;i++)
 {
  if(ptr[i]>='A' && ptr[i]<='Z')
  {
   arr[i]=ptr[i]+32;
  }
  else if(ptr[i]>='a' && ptr[i]<='z')
  {
   arr[i]=ptr[i]-32;
  }
  else if(ptr[i])
  {
   arr[i]=' ';
  }
 }
 
 for(i=0;i<iCnt;i++)
 {
  printf("%c",arr[i]);
 }
 printf("\n");
}

int main()
{
 char arr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 DisplayToggle(arr);
 
 return 0;
}
