/*

problem statement: accept character from user and check whether it is a digit or not

*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0

BOOL ChkDigit(char cValue)
{
 if((cValue>='0')&&(cValue<='9'))
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
}

int main()
{
 char ch='\0';
 BOOL bRet=FALSE;
 
 printf("enter character:\n");
 scanf("%c",&ch);
 
 bRet=ChkDigit(ch);
 
 if(bRet==TRUE)
 {
  printf("it is digit\n");
 }
 else
 {
  printf("not a digit\n");
 }
 
 return 0;
}
 
