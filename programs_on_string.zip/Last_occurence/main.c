/*

problem statement:accept string from user and also accept character and return last occurence

*/
#include<stdio.h>
#define ABSENT -3
#define FALSE -1
int LastOccurence(char arr[],char ch)
{
 if(arr==NULL || ch=='\0')
 {
  return -1;
 }
 int i=0;
 int iIndex=0;
 
 while(arr[i]!='\0')
 {
  if(arr[i]==ch)
  {
   iIndex=i;
  }
  i++;
 }
 if(arr[i]==ch)  //jar letter present nasel tar.....loop kashane stop zlaa he check karnyasathi...ifelse
 {
  return i;
 }
 else
 {
  return FALSE;
 }
 
 
}
 
int main()
{
 char arr[30];
 char ch='\0';
 int iRet=0;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 printf("enter character:\n");
 scanf(" %c",&ch);
 
 iRet=LastOccurence(arr,ch);
 
 if(iRet==-1)
 {
  printf("Error:memory problem\n");
 }
 else if(iRet==ABSENT)
 {
  printf("Error:absent letter\n");
 }
 else
 {
  printf("%d\n",iRet);
 }
 
 
 return 0;
}
