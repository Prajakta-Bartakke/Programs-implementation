/*
problem statement:accept string from user and also accept one character also and return the first occurence of that character
*/

#include<stdio.h>
#define ERRORMEMORY -1
#define INVALID -2
#define ABSENT -3

int FirstOcc(char *ptr,char cVal)
{
 if(ptr==NULL)
 {
  return ERRORMEMORY;
 }
 if(cVal=='\0')
 {
  return INVALID;
 } 
 int i=0;
 
 while((*(ptr+i))!='\0')
 {
  if((*(ptr+i))==cVal)
  {
   break;
  }
  i++;
 }
 if((*(ptr+i))==cVal)
 {
  return i;
 }
 else
 {
  return ABSENT;
 }
}
int main()
{
 char arr[30];
 char ch='\0';
 int iRet=0;
 
 printf("enter a string:\n");
 scanf("%[^'\n']s",arr);
 
 printf("enter character:\n");
 scanf(" %c",&ch);
 
 iRet=FirstOcc(arr,ch);

 if(iRet==ERRORMEMORY)
 {
  printf("Error:memory not allocated...\n");
 }
 else if(iRet==INVALID)
 {
  printf("Error:invalid input...\n");
 } 
 else if(iRet==ABSENT)
 {
  printf("Error:element not present...\n");
 } 
 else
 {
  printf("first occurenec of %c is %d\n",ch,iRet);
 }
 return 0;
}
