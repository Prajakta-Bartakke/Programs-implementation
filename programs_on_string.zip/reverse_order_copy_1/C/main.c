/*
problem statement: accept string from user and copy that string into another string in reverse order
*/

#include<stdio.h>
#include<stdlib.h>

/*void Reverse(char *arr,char *brr)
{
 if(arr==NULL || brr==NULL)
 {
  return;
 }
 int iCnt=0,i=0;

 while((*(arr+iCnt))!='\0')
 {
  iCnt++;
 }
 iCnt--;
 int iVal=iCnt;
 
 for(i=0;i<=iVal;i++)
 {
  (*(brr+i))=(*(arr+iCnt));
  iCnt--;
 }
 //(*(brr+i))='\0';
}*/

void Reverse(char*arr,char *brr)
{
 int iCnt=0;
 
 while((*(arr+iCnt))!='\0')
 {
  iCnt++;
 }
 brr=(char*)malloc(sizeof(char)*iCnt);
 iCnt--;
 int iVal=iCnt;
 int i=0;
 
 for(i=0;i<=iVal;i++)
 {
  (*(brr+i))=(*(arr+iCnt));
  iCnt--;
 }
 printf("%s\n",brr);
}

int main()
{
 char arr[30];
 char *brr=NULL;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 Reverse(arr,brr);
 
 //printf("%s\n",brr);
 
 return 0;
}
