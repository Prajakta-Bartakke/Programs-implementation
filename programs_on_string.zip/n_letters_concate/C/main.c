/*

problem statement: accept 2 strings and 1 number from user and concatenate that number of characters after the first string

-----------------------------------------------------------------------------------------

input:  marvellous infosystems
	logic building
	5	
output:
	marvellous infosystems logic
	
-----------------------------------------------------------------------------------------

input:
	marvellous infosystems
	os
	5
output:
	marvellous infosystem os

-----------------------------------------------------------------------------------------
*/
#include<stdio.h>

void strCatX(char *arr,char *brr,int iNo)
{
 if(arr==NULL || brr==NULL)
 {
  return;
 }
 if(iNo<0)
 {
  iNo=-iNo;
 }
 int i=0,j=0,k=0;
 
 while(arr[i]!='\0')
 {
  i++;
 }
 arr[i]=' ';
 i++;
 
 while(brr[j]!='\0')
 {
  j++;
 }
 
 if(iNo>j)
 {
  for(k=0;k<j;k++)
  {
   arr[i]=brr[k];
   i++;
  }
  arr[i]='\0';
 }
 else
 {
  for(k=0;k<iNo;k++)
  {
   arr[i]=brr[k];
   i++;
  }
  arr[i]='\0';
 }
  
}

/*void strCatX(char *arr,char *brr,int iNo)
{
 if(arr==NULL || brr==NULL)
 {
  return;
 }
 if(iNo<0)
 {
  iNo=-iNo;
 }
 int j=0,k=0;
 while((*arr)!='\0')
 {
  arr++;
 }
 (*arr)=' ';
 
 arr++;
 
 while((*(brr+j))!='\0')
 {
  j++;
 }
 
 if(j<iNo)
 {
  for(int k=0;k<j;k++)
  {
  (*arr)=(*brr);
  arr++;
  brr++;
 }
 (*arr)='\0';
}
 else
 {
  for(k=0;k<iNo;k++)
  {
   (*arr)=(*brr);
   arr++;brr++;
  }
  (*arr)='\0';
  
}
}*/
int main()
{
 char arr[50];
 char brr[30];
 int iNo=0;
 
 printf("enter first string:\n");
 scanf("%[^'\n']s",arr);
 
 printf("enter second string:\n");
 scanf(" %[^'\n']s",brr);
 
 printf("enter number:\n");
 scanf("%d",&iNo);
 
 strCatX(arr,brr,iNo);
 
 printf("%s\n",arr);

 return 0;
}
 
 
 
 
 
 
 
 
 


