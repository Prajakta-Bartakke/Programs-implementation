/*
problem statement:accept string from user and copy the captal letters in it to otheer string
*/

#include<stdio.h>
#include<stdlib.h>

void CapCopy(char *arr)
{
 int i=0;
 int iCnt=0;
 
 if(arr==NULL)
 {
  printf("Error:memory has not been allocated\n");
  return;
 }
 char *cpy='\0';
 int j=0;
 
 while((*(arr+i))!='\0')
 {
  if(((*(arr+i))>='A') && ((*(arr+i))<='Z'))
  {
   iCnt++;
   cpy=(char*)realloc(cpy,sizeof(char)*iCnt);
   (*(cpy+j))=(*(arr+i));
   printf("%c",(*(cpy+j)));
   j++;
  }
  i++;
 }
 free(cpy);
}

int main()
{
 char arr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 CapCopy(arr);
 printf("\n");
 
 return 0;
}
