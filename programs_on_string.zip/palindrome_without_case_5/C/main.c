/*
problem statement: accept string from user and check whether it is palindrome or not

input:
	1abccBA1
	
output:
	TRUE
	
*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE -1
#define ERRORMEMORY -3

BOOL ChkPalindrome(char *arr)
{
 int i=0;
 char *iStart=arr;
 
 while((*arr)!='\0')
 {
  arr++;
  i++;
 }
 arr--;
 int iCnt=0;
 
 char *iEnd=arr;
 
 while(iEnd-iStart>=0)
 {
  if( (((*iStart)>='a' && (*iStart<='z')) || ((*iStart)>='A' && (*iStart<='Z')) )  ||  (((*iEnd)>='a' && (*iEnd<='z')) || ((*iEnd)>='A' && (*iEnd<='Z')) )) 
  {
   	if( ((*iStart)-(*iEnd)==32)  ||  ((*iStart)-(*iEnd)==-32) ||  ((*iStart)-(*iEnd)==0))
   	{ 
   		iCnt++;
   	}
  }
  else
  {
   	if((*iStart)==(*iEnd))
   	{
        	iCnt++;
        }
  }
  iStart++;
  iEnd--;
 }
 
 if(i%2==0   &&   iCnt==(i/2))
 {
  return TRUE;
 }
 else if(i%2!=0   &&   iCnt==((i/2)+1))
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 } 
}                                  
int main()
{
 char arr[30];
 BOOL bRet=FALSE;
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 bRet=ChkPalindrome(arr);

 if(bRet==TRUE)
 {
  printf("palindrome\n");
 }
 else if(bRet==FALSE)
 {
  printf("not a palindrome\n");
 }
 else
 {
  printf("mmeory pblm\n");
 }
 return 0;
}
