/*

problem statement: accept string from user and return the length of the largest word

*/

#include<stdio.h>

int MaxLen(char *arr)
{
 int i=0,iCnt=0,iMax=0;
 
 while(arr[i]!='\0')
 { 
 if(arr[i]!=' ')
 {
  iCnt++;
  
  if(iCnt>iMax)
  {
   iMax=iCnt;
  }
 }
 else if(arr[i]==' ')
 {
  iCnt=0;
 }
 
 i++;
}
 return iMax;    
}
int main()
{
 char arr[100];
 int iRet=0;
 
 printf("enter string:\n");
 scanf("%[^\n]s",arr);
 
 iRet=MaxLen(arr);
 
 printf("maximum length is :%d\n",iRet);
 
 return 0;
}
 
