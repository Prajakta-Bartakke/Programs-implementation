/*

problem statement: accept 2 strings from user and also accept a number from user and compare that number of contenets of first string equal ahet ka

input: 
	marvellous infosystems
	marvellous
	10
output:
	TRUE
*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE -1
#define ERRORMEMORY -3
#define SIZE -4

BOOL strCmpX(char *arr,char *brr,int iNo)
{
 if(arr==NULL || brr==NULL)
 {
  return ERRORMEMORY;
 }
 if(iNo<0)
 {
  iNo=-iNo;
 }
 int i=0,j=0;
 while(arr[i]!='\0')
 {
  i++;
 }
 while(arr[j]!='\0')
 {
  j++;
 }
 if(i<iNo  ||  j<iNo)
 {
  return SIZE;
 }
 int iVal=0,k=0;
 
 for(k=0;k<iNo;k++)
 {
  if(arr[k]==brr[k]);
  {
   iVal++;
  }
 }
 if(iVal==iNo)
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
 }
 
int main()
{
 char arr[30];
 char brr[30];
 int iNo=0;
 BOOL bRet=FALSE;
 
 printf("enter first string:\n");
 scanf("%[^'\n']s",arr);
 
 printf("enter second string:\n");
 scanf(" %[^'\n']s",brr);
 
 printf("enter how many letters you wnat to check:\n");
 scanf("%d",&iNo);
 
 bRet=strCmpX(arr,brr,iNo);
 
 if(bRet==TRUE)
 {
  printf("first %d letters are same\n",iNo);
 }
 else if(bRet==ERRORMEMORY)
 {
  printf("Error:memory problem\n");
 }
 else if(bRet==SIZE)
 {
  printf("Error:to compare either the first string is small or second string is small than the entered number\n");
 }
 else
 {
  printf("not same\n");
 }
 
 
 return 0;
}
