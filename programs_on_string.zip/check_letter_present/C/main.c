/*

problem statement: accept string from user accept one character also and check whether our string contains that character or not

*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0
#define INVALID -1
#define ERRORMEMORY -2

BOOL ChkChar(char *ptr,char cVal)
{
 if(ptr==NULL)
 {
  return ERRORMEMORY;
 }
 int i=0;
 
 while((*(ptr+i))!='\0')
 {
  if((*(ptr+i))==cVal)
  {
   break;
  }
  i++;
 }
 if((*(ptr+i))==cVal)
 {
  return TRUE;
 }
 else 
 {
  return FALSE;
 }  

}

int main()
{
 char arr[30];
 BOOL bRet=FALSE;
 char ch='\0';
  
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);

 printf("enter character:\n");
 scanf(" %c",&ch);
 
 bRet=ChkChar(arr,ch);
 
 if(bRet==ERRORMEMORY)
 {
  printf("Error:memory problem\n");
 }
 else if(bRet==TRUE)
 {
  printf("TRUE\n");
 }
 else if(bRet==FALSE)
 {
  printf("FALSE\n");
 }
 
 
 return 0;
}
 

 
