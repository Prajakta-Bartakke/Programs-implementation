/*

prblem statemet:accept string from user and display the string in reverse order

*/

#include<stdio.h>
#include<stdlib.h>

/*void Display(char *ptr)
{
 int iCnt=0,i=0;
 
 while((*(ptr+i))!='\0')
 {
  iCnt++;
  i++;
 }
 
 char *rev=(char*)malloc(sizeof(char)*iCnt);
 
 i=0;
 int iVal=iCnt;
 
 for(i=0;i<=iCnt;i++)
 {
  rev[i]=ptr[iVal];
  iVal--;
 }
 printf("reverse string is :\n");
 for(i=0;i<=iCnt;i++)
 {
  printf("%c",rev[i]);
 } 
 
 
}*/

/*void Display(char *ptr)
{
 int i=0;
 int iCnt=0;
 
 while(ptr[i]!='\0')
 {
  iCnt++;
  i++;
 }
 
 i=0;
 int iVal=iCnt-1;
 
 for(i=0;i<iCnt;i++)
 {
  ptr[i]=ptr[iVal];
  iVal--;
  //printf("%c",ptr[i]);
 }
 for(i=0;i<iCnt;i++)
 {
  printf("%c",ptr[i]);
 }
 }*/
 
 
void Display(char *ptr)
{
 int i=0;
 while(ptr[i]!='\0')
 {
  i++;
 }
 for(int j=0;j<i;j++)
 {
  ptr[i]=ptr[j];
 }
  
 

 
 
int main()
{
 char arr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 Display(arr);
 printf("\n");
 
 return 0;
}
