/*
problem statement: accept a character from user and chek whether it is alphabet or not
*/

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0

BOOL ChkAlphabet(char cValue)
{
 if(((cValue>='A')&&(cValue<='Z')) || ((cValue>='a')&&(cValue<='z')))
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
} 

int main()
{
 char ch='\0';
 BOOL bRet=FALSE;
  
 printf("enter character:\n");
 scanf("%c",&ch);
 
 bRet=ChkAlphabet(ch);
 
 if(bRet==TRUE)
 {
  printf("it is a alphabet\n");
 }
 else
 {
  printf("not a alphabet\n");
 }
 
 return 0;
}
