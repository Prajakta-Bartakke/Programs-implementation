/*

problem statement:	accept character from user and check whether it is in capital letter or not

*/
#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0

BOOL ChkCapital(char cValue)
{
 if((cValue>='A')&&(cValue<='Z'))                       //internally convert hota ascii madhe..ani ascii lihu naye..so that readble rahto code.
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 } 
}

int main()
{
 char ch='\0';
 BOOL bRet=FALSE;
 
 printf("enter character:\n");
 scanf("%d",&ch);
 
 bRet=ChkCapital(ch);
 
 if(bRet==TRUE)
 {
  printf("capital letter\n");
 }
 else
 {
  printf("not capital letter\n");
 }
 
 return 0;
}
  
