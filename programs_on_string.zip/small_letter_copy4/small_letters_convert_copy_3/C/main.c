/*
problem statement:accpt kara string and small letter convert kara cap mdhe convert karun mag copy kara dusrya string madhe	
*/

#include<stdio.h>

void strCpyCap(char arr[],char brr[])
{
 int iCnt=0;
 
 if(arr==NULL || brr==NULL)
 {
  return;
 }
 
 while(arr[iCnt]!='\0')
 {
  if((arr[iCnt]>='a')&&(arr[iCnt]<='z'))
  {
   brr[iCnt]=arr[iCnt]-32;
  }
  else
  {
   brr[iCnt]=arr[iCnt];
  }
  iCnt++;
 } 

}

int main()
{
 char arr[30];
 char brr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 strCpyCap(arr,brr);
 
 printf("%s\n",brr);
 
 return 0;
}
