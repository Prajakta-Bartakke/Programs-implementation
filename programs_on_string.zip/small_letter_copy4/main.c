/*
problem statement:accpet string from user and copy the small letters in another string 
*/

#include<stdio.h>
#include<stdlib.h>

void SmallCopy(char *arr,char *copy)
{
 /*if(arr==NULL)
 {
  printf("Error:source address NULL\n");
  return;
 }
 if(copy==NULL)
 {
  printf("Error:destination address NULL\n");
  return;
 }*/
 int i=0,iCnt=0;
 int j=0;
 while(*((arr+i))!='\0')
 {
  if(((*(arr+i))>='a')&&((*(arr+i))<='z'))
  {
   iCnt++;
   copy=(char*)realloc(copy,sizeof(char)*iCnt);	//heap 
   (*(copy+j))=(*(arr+i));
   //printf("%c",(*(copy+j)));
   j++;
  }
  i++;
 }
 
}
int main()
{
 char arr[30];
 char *copy='\0';
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 SmallCopy(arr,copy);
 
 //printf("%s\n",copy);				//SmallCopy madhe copy navacha pointer la actual address milala..tymule ya function cha scope samplyawar ikde print kela tar segmentation fault yeto
 
 return 0;
}
