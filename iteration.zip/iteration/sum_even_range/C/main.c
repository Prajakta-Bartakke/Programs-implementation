/*
  problem statement:	accept range from user and calculate the sum of even numbers in between
*/
#include"header.h"

int main()
{
 int iStart=0;
 int iEnd=0;
 int iRet=0;
 
 printf("enter starting point\n");
 scanf("%d",&iStart);
 
 printf("enter ending number\n");
 scanf("%d",&iEnd);
 
 iRet=SumEven(iStart,iEnd);
 
 if(iRet==0)
 {
  printf("invalid range\n");
 }
 else 
 { 
 printf("sum of even numbers is %d\n",iRet);
 }
 return 0;
}
