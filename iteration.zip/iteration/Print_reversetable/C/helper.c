#include"header.h"

////////////////////////////////////////////////////////
//
//function name:		Display
//input:			integer
//return value:		none
//description:			used to print reverse table
//author:			Prajakta Aditya Bartakke
//date:			6 aug 2020
////////////////////////////////////////////////////////

void Display(int iNo)
{
  if(iNo<0)
  {
   iNo=-iNo;
  }
  
  int iCnt=0;
  int iNum=(10*iNo);
  
  while(iCnt!=10)
  {
   printf("%d\t",iNum);
   
   iNum=(iNum-iNo);
   
   iCnt++;
  }
}
  

