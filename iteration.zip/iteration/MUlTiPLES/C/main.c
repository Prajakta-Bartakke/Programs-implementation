/* 
 problem statement:  write a program which accept number from user and show the fisrt five multiples of the number
*/
#include"header.h"
int main()
{
 int iVal=0;
 
 printf("enter number\n");
 scanf("%d",&iVal);
 
 Display(iVal);
 
 return 0;
}
