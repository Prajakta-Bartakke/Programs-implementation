#include"header.h"

//////////////////////////////////////////////////////////
//
//function name:		Display
//input:			integer
//return value:		none
//description:			used to print odd numbers
//author:			Prajakta Aditya Bartakke
//date:			6 August 2020
//////////////////////////////////////////////////////////

/*void Display(int iNo)
{
 int iCnt=1;
 
 while(iCnt!=(iNo-1))
 {
  printf("%d ",iCnt);
  
  iCnt=iCnt+2;
 }
 printf("\n");
}*/


/*void Display(int iNo)
{
 int iCnt=1;
 
 for(iCnt=1;iCnt<18;iCnt=iCnt+2)
 {
  printf("%d ",iCnt);
 }
}*/

/////////////////////////////////////////////
//
//time complexity: O(N)
//
///////////////////////////////////////////// 
void Display(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 int iCntf=1,iCntb=(iNo-1);
 
 while((iCntb!=(iCntf-1))   &&   ((iCntb-iCntf>=0)))
 {
 
  if(iCntf==iCntb)
  {
   if(iCntf%2!=0)
   {
    printf("%d ",iCntf);
   }
   break;
  }
  
  if(iCntf%2!=0)
  {
    printf("%d ",iCntf);
  }
  
  if(iCntb%2!=0)
  {
   printf("%d ",iCntb);
  }
  
  iCntf++;
  iCntb--;
 }
} 
/////////////////////////////////////////////
//
//time complexity: O(N/2)
//
///////////////////////////////////////////// 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

