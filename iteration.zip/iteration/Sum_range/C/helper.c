#include"header.h"
////////////////////////////////////////////////////////
//
//function name:	SumRange
//input:		integer,integer
//return value:	integer
//description:		used to perform sum of numbers in range
//author:		Prajakta Aditya Bartakke
//date:		10 aug 2020
////////////////////////////////////////////////////////

int SumRange(int iStart,int iEnd)
{
 if(iStart<0 || iEnd<0 )
 {
  return 0;
 }    
 
 int iSum=0;
 
 while((iEnd-iStart)>=0)
 {
   iSum=iSum+iStart+iEnd;
 
   iStart++;
   
   iEnd--;
   
   if(iStart==iEnd)
   {
    iSum=iSum+iStart;
    break;
   }
  }
  return iSum;
}
   
  
  
 
 
 
 
 
 
 
 
 
  
