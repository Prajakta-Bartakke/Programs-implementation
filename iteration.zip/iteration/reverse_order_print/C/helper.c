#include"header.h"
///////////////////////////////////////////////////////////
//
//function name:	PrintReverseRange
//input:		integer,integer
//return value:	none
//description:		used to print numbers between the range in reverse order
//author:		Prajakta Aditya Bartakke
//date:		8 aug 2020
////////////////////////////////////////////////////////////

void PrintReverseRange(int iStart,int iEnd)
{
 if(iStart>iEnd)
 {
  printf("invalid range\n");
 }
 while(iEnd!=(iStart-1))
 {
  printf("%d ",iEnd);
  iEnd--;
 }
}
 
