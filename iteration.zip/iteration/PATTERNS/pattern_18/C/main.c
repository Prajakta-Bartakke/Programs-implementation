/* problem statement:    accept row and column from user and print below pattern

input:		row =4   col=4

output:   	1  2  3  4 
		5  6  7  8 
		9  1  2  3
		4  5  6  7
*/

#include<stdio.h>
void Pattern(int iRow,int iCol)
{
 if(iRow<0)
 {
  iRow=-iRow;
 }
 if(iCol<0)
 {
  iCol=-iCol;
 }
 int i=0,j=0;
 int iCnt=1;
 for(i=1;i<=iRow;i++)
 {
  for(j=1;j<=iCol;j++)
  {
   printf("%d\t",iCnt);
   iCnt++;
   if(iCnt==10)
   iCnt=1;
  }
  printf("\n");
 }
}


int main()
{
  int iRow=0,iCol=0;
  
  printf("enter number of rows and column\n");
  scanf("%d%d",&iRow,&iCol);
  
  Pattern(iRow,iCol);
  
  return 0;
}
