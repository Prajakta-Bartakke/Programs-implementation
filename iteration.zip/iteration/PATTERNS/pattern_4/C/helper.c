#include"header.h"

///////////////////////////////////////////////
//
//function name:	Display
//input:		integer,integer
//return value:	none
//description:		used to print the first nuber second number of times
//author:		Prajakta Aditya Bartakke
//date:		31 july 2020
///////////////////////////////////////////////

void Display(int iNo,int iFrequency)
{
 int iCnt=0;
 
 if(iFrequency<0)                              //input updator for second number...even if negative number dila as input tar to positive modify karun dya
 {
  iFrequency=-iFrequency;
 }
 for(iCnt=0;iCnt<iFrequency;iCnt++)
 {
  printf("%d\n",iNo);
 }
}


