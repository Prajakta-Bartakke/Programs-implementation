#include<stdio.h>

void Pattern(int,int);
