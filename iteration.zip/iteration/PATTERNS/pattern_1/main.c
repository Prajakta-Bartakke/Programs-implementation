/*
  problem statement:   write a program to display marvellous on screen for 5 times
*/
#include"header.h"
int main()
{
 Display();
 
 return 0;
}
