#include<stdio.h>

void Display(int);


