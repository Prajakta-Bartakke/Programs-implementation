/* 
problem statement: accept string from user and display the below pattern


input: marvellous


output:
	M	A	R	V	E	L	L	O	U	S
	
	M	A	R	V	E	L	L	O	U	S
	
	M	A	R	V	E	L	L	O	U	S
	
	M	A	R	V	E	L	L	O	U	S
	
	M	A	R	V	E	L	L	O	U	S
	
	M	A	R	V	E	L	L	O	U	S
	
	M	A	R	V	E	L	L	O	U	S
	
	M	A	R	V	E	L	L	O	U	S
	
	M	A	R	V	E	L	L	O	U	S
	
	M	A	R	V	E	L	L	O	U	S
*/

#include<stdio.h>

void Display(char *arr)
{
 int iCnt=0;
 
 if(arr==NULL)
 {
  return;
 }
 
 while(arr[iCnt]!='\0')
 {
  iCnt++;
 }
 
 int i=0,j=0;
 
 for(i=0;i<iCnt;i++)
 {
  for(j=0;j<iCnt;j++)
  {
   if(((*(arr+j))>='a')&&((*(arr+j))<='z'))
   {
    printf("%c\t",((*(arr+j))-32));
   }
   else
   {
    printf("%c\t",(*(arr+j)));
   }
  }
  printf("\n");
 }
}

int main()
{
 char arr[30];
 
 printf("enter string:\n");
 scanf("%[^'\n']s",arr);
 
 Display(arr);
 
 return 0;
}
