/*
problem statement:  accept row and column from user and print the following pattern

input:		3  5

output:	
		5 4 3 2 1 
		5 4 3 2 1
		5 4 3 2 1

*/
#include"header.h"
int main()
{
 int iRow=0,iColumn=0;
 
 printf("enter number of row and column\n");
 scanf("%d%d",&iRow,&iColumn);
 
 Pattern(iRow,iColumn);
 
 return 0;
}
