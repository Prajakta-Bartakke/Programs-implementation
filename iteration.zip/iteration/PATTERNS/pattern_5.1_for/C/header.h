#include<stdio.h>

void Display(int iNo);
