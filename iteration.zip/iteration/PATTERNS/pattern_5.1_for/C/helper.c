#include"header.h"

/////////////////////////////////////
//function name:	Display
//input args:		integer
//return val:		none
//description:		it printd * on screen for the given input
//author:		Prajakta Aditya Bartakke
//date:		27 july 2020
/////////////////////////////////////

void Display(int iNo)
{
 int iCnt=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  printf("*");
 }
}
