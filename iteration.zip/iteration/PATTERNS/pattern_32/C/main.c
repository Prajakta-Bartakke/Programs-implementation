/*
 problem statement:
		Accept number of rows and column from user and print the below pattern
		
input:		row=4  column=4

output:	1 2 3 4
		  2 3 4
		    3 4 
		      4     
*/
#include<stdio.h>
void Pattern(int iRow,int iCol)
{
 if(iRow<0)
 {
  iRow=-iRow;
 }
 if(iCol<0)
 {
  iCol=-iCol;
 }
 if(iRow!=iCol)
 {
  printf("Error:invalid input\n");
  return;
 }
 int i=0;
 int j=0;
 
 /*for(i=1;i<=iRow;i++)
 {
  for(j=i;j<iCol;j++)
  {
   printf("%d\t",j);
  }
  printf("\n");
 }*/
 
 for(i=1;i<=iRow;i++)
 {
  for(j=1;j<=iCol;j++)
  {
   if(j>=i)
   {
    printf("%d\t",j);
   }
   else
   {
    printf("\t");
   }
   
  }
  printf("\n");
 }
 }

int main()
{
 int iRow=0,iCol=0;
 
 printf("enter number of rows and column\n");
 scanf("%d%d",&iRow,&iCol);
 
 Pattern(iRow,iCol);
 
 return 0;
}
