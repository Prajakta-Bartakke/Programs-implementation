class reverse
{ 
 public void display()
 {
  int iCnt=5;
  
  for(iCnt=5;iCnt>=1;iCnt=iCnt-2)
  { 
    System.out.println(iCnt);
    iCnt++;
   }
 }
}
