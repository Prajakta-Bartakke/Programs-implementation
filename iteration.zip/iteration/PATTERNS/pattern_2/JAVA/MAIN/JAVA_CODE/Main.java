/*
 problem statement: program to print numbers in reverse order
*/

/* 
 helper navachya folder mdhe reverse navacha class ahe tyachi .class file tyach folder mdhe CLASS_CODE ya subfolder mdhe ahe
 helper navacha class compile karun to veglya(CLASS_CODE) mdhe thevnyasathi javac -d ../CLASS_CODE hi command dyaychi
 
 Main.java hi file ata complie hotana error dete karan reverse exactly kay ahe he tyala samjat nahi tyamule command detana 
 .class file main chi store karaychi ahe MAIN/CLASS_CODE mdhe mhnun command:- $MAIN/JAVA_CODE/ javac -d ../CLASS_CODE -cp ../../HELPER/CLASS_CODE Main.java
 compile keleli Main.class ata MAIN/CLASS_CODE mdhe store hote
 
 program run hotana pan bomba marto exceptions deto
 tyamule command detana
 $MAIN/CLASS_CODE/ java -cp ../../HELPER/CLASS_CODE/: Main
 
 */
 



class Main
{
 public static void main(String arg[])
 {
   reverse robj=new reverse();
   
   robj.display();
 }
}
