#include"header.h"

//////////////////////////////////////////////////////////
//
//function name:		Display
//input:			integer
//return value:		none
//description:			used to print number line
//author:			Prajakta Aditya Bartakke
//date:			6 August 2020
//////////////////////////////////////////////////////////

/*void Display(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 int iCnt=-iNo;
 
 while(iCnt!=(iNo+1))
 {
  printf("%d ",iCnt);
  
  iCnt=iCnt+1;
 }
}*/

void Display(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 int i=0;
 
 for(i=(-iNo);i<=iNo;i++)
 {
  printf("%d\t",i);
 }
 printf("\n");
 
}
