using namespace std;

#include<iostream>

template <class T>
T Maximum(T *arr,int size)
{
 T max=arr[0];
 
 int i=0,j=0;
 
 for(i=0,j=size-1;j-i>=0;i++,j--)
 {
  if(arr[i]>max /*&& arr[i]>arr[j]*/)
  {
   max=arr[i];
  }
  if(arr[j]>max /*&& arr[j]>arr[i]*/)
  {
   max=arr[j];
  }
 }
 
 return max;
}

int main()
{
 int size=0;
 float max=0;
 float arr[]={11.2,15.3,45.78,78.3};
/* printf("enter size:\n");
 scanf("%d",&size);
 int *arr=(int*)malloc(sizeof(int));
 printf("enter element:\n");
 
 for(int i=0;i<size;i++)
 {
  scanf("%d",&arr[i]);
 }*/
 
 max=Maximum(arr,4);
 
 cout<<"maximum number from arrays is:\n"<<max<<endl;
 
 return 0;
 



}
