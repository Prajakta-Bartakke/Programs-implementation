using namespace std;

#include<iostream>
#define FALSE -2
#define ERRORMEM -1
template <class T>
int LastOcc(T *arr,int size,T no)
{
 int i=0,index=0;
 if(arr==NULL)
 {
  return ERRORMEM ;
 }
 for(i=0;i<size;i++)
 {
  if(arr[i]==no)
  {
   index=i;
  }
 }
 
 if(arr[index]==no)
 {
  return (index+1);
 }
 else
 {
  return FALSE;
 }
}
int main()
{
 int size=0,no=0;
 
 cout<<"enter size:\n";
 cin>>size;
 
 int*arr=(int*)malloc(sizeof(int)*size);
 
 cout<<"enter elemnts:\n";
 
 for(int i=0;i<size;i++)
 {
  cin>>arr[i];
 }
 cout<<"enter number whose last occurence is to find out:\n";
 cin>>no;

 int LOcc=LastOcc(arr,size,no);
 
 if(LOcc==ERRORMEM)
 {
  cout<<"memory not allocated\n";
 }
 else if(LOcc==FALSE)
 {
  cout<<"number absent\n";
 }
 else
 {
 
 cout<<"last occurence of "<<no<<" is "<<LOcc<<endl; 
}

 return 0;
}
