using namespace std;

#include<iostream>

template <class T>
T LargestThree(T no1,T no2,T no3)
{
 T max;
 
 if(no1>=no2  &&  no1>=no3)
 {
  max=no1;
 }
 else if(no2>=no1 && no2>=no3)
 {
  max=no2;
 }
 else
 {
  max=no3;
 }
 
 return max; 

}


int main()
{
 int no1=0,no2=0,no3=0,largest=0;
 
 cout<<"enter first number:\n";
 cin>>no1;
 
 cout<<"enter second number:\n";
 cin>>no2;
 
 cout<<"enter third number:\n";
 cin>>no3;
 
 largest=LargestThree(no1,no2,no3);

 cout<<"largest of three is :"<<largest<<endl;
 
 float fno1=0.0,fno2=0.0,fno3=0.0,flargest=0.0;
 
 cout<<"enter first number:\n";
 cin>>fno1;
 
 cout<<"enter second number:\n";
 cin>>fno2;
 
 cout<<"enter third number:\n";
 cin>>fno3;
 
 flargest=LargestThree(fno1,fno2,fno3);

 cout<<"largest of three is :"<<flargest<<endl;

 return 0;
}
