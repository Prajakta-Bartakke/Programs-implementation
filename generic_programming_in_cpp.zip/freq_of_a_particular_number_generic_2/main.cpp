using namespace std;

#include<iostream>

template <class T>
int frequency(T *arr,int size,T no)
{
 if(arr==NULL)
 {
  return -1;
 }
 int i=0,j=0,cnt=0;
 
 for(i=0,j=size-1;j-i>=0;i++,j--)
 {
  if(i==j && arr[i]==no)
  {
   cnt++;
   break;
  }
  if(arr[i]==no)
  {
   cnt++;
  }
  if(arr[j]==no)
  {
   cnt++;
  }
 }
 
 /*for(i=0;i<size;i++)
 {
  cout<<"--------------------------\n";
  cout<<"arr:\t"<<arr[i]<<endl;
  cout<<"no:\t"<<no<<endl;
  cout<<"i:\t"<<i<<endl;
  if(arr[i]==no)
  {
   cnt++;
  }
 } */

 return cnt; 
} 

int main()
{
 int size=0,no=0,i=0,freq=0;
 
 cout<<"enter size\n";
 cin>>size;
 
 int *arr=(int*)malloc(sizeof(int)*size);
 cout<<"enter elements:\n";
 
 for(i=0;i<size;i++)
 {
  cin>>arr[i];
 }
 
 cout<<"enter number whose freq is to find out:\n";
 cin>>no;
 
 freq=frequency(arr,size,no);
 
 cout<<"frequency of "<<no<<" is "<<freq<<endl;
  
 return 0;
}
