using namespace std;

#include<iostream>

template <class T>
void Reverse(T *arr,int size)
{
 if(arr==NULL)
 {
  return;
 }
 
 T temp=T();
 int start=0,end=0;
 
 for(start=0,end=size-1;end-start>=0;start++,end--)
 {
  temp=arr[start];
  arr[start]=arr[end];
  arr[end]=temp;
 }
 }
 
int main()
{
 int size=0;
 
 cout<<"enter size:\n";
 cin>>size;
 
 int *arr=(int*)malloc(sizeof(int)*size);
 
 cout<<"enter elements:\n";
 
 for(int i=0;i<size;i++)
 {
  cin>>arr[i];
 }
 
 Reverse(arr,size);
 
 cout<<"elemnts after reversing:\n";
 
 for(int i=0;i<size;i++)
 {
  cout<<arr[i]<<"\t";
 }
 cout<<endl;


 return 0;
}
