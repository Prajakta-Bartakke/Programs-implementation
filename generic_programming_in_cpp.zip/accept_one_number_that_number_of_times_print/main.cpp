using namespace std;

#include<iostream>
template <class T>
void Display(T val,int no)
{
 if(no<0)
 {
  no=-no;
 }
 
 for(int i=0;i<no;i++)
 {
  cout<<val<<"\t";
 }
 cout<<endl;
}

int main()
{
 int val=0,no=0;
 
 printf("enter the value to be displayed:\n");
 scanf("%d",&val);
 
 printf("enter how many number of times the value to be repeated:\n");
 scanf("%d",&no);
 
 Display(val,no);
 
 char cval=0;int cno=0;
 
 printf("enter the value to be displayed:\n");
 scanf(" %c",&cval);
 
 printf("enter how many number of times the value to be repeated:\n");
 scanf("%d",&cno);
 
 Display(cval,cno);
 
 
 return 0;
}
