using namespace std;

#include<iostream>
#define FALSE -2
#define ERRORMEM -1
template <class T>
int FirstOcc(T *arr,int size,T no)
{
 int i=0;
 if(arr==NULL)
 {
  return ERRORMEM ;
 }
 for(i=0;i<size;i++)
 {
  if(arr[i]==no)
  {
   break;
  }
 }
 
 if(i<=size-1 && arr[i]==no)
 {
  return i+1;
 }
 
 else
 {
  return FALSE;
 }
 
}
int main()
{
 int size=0,no=0;
 
 cout<<"enter size:\n";
 cin>>size;
 
 int*arr=(int*)malloc(sizeof(int)*size);
 
 cout<<"enter elemnts:\n";
 
 for(int i=0;i<size;i++)
 {
  cin>>arr[i];
 }
 cout<<"enter number whose first occurence is to find out:\n";
 cin>>no;

 int FOcc=FirstOcc(arr,size,no);
 
 if(FOcc==ERRORMEM)
 {
  cout<<"memory not allocated\n";
 }
 else if(FOcc==FALSE)
 {
  cout<<"number absent\n";
 }
 else
 {
 
 cout<<"first occurence of "<<no<<" is "<<FOcc<<endl; 
}

 return 0;
}
