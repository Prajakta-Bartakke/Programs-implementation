using namespace std;

#include<iostream>

template <class T>
T summation(T *arr,int size)
{
 int i=0,j=0;
 T sum=T();     //way to initialise the template variable
 for(i=0,j=size-1;j-i>=0;i++,j--)
 {
  if(i==j)
  {
   sum=arr[i]+sum;
   break;
  }
  sum=arr[i]+arr[j]+sum;
 }
 return sum;

}

int main()
{
 int size=0;
 float sum=0;
 float arr[]={11.2,15.3,45.78,78.3};
 /*printf("enter size:\n");
 scanf("%d",&size);
 int *arr=(int*)malloc(sizeof(int));
 printf("enter element:\n");
 
 for(int i=0;i<size;i++)
 {
  scanf("%d",&arr[i]);
 }*/
 
 sum=summation(arr,4);
 
 cout<<"sum of numbers is:\n"<<sum<<endl;
 
 return 0;
 



}
