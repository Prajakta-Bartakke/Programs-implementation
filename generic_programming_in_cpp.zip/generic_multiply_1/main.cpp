using namespace std;

#include<iostream>

template <class T>
T multiply(T no1,T no2)          //jyat store karacycha to initialise nahi kela tr garbage yeu shakto     
{
 return (no1*no2);
}


int main()
{
 int no1=0,no2=0;
 int mult=0;
 cout<<"enter first number:\n";
 cin>>no1;

 cout<<"enter second number:\n";
 cin>>no2;
 
 mult=multiply(no1,no2);
  
 cout<<"multiplication of 2 numbers is :"<<mult<<endl;
 
 
 float fno1=0,fno2=0;
 float fmult=0.0;
 cout<<"enter first number:\n";
 cin>>fno1;

 cout<<"enter second number:\n";
 cin>>fno2;

 fmult=multiply(fno1,fno2);
 
 cout<<"multiplication of 2 numbers is :"<<fmult<<endl;
 

 return 0;
}
