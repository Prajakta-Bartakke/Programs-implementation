using namespace std;

#include<iostream>

template <class T>
T Minimum(T *arr,int size)
{
 T min=arr[0];
 
 int i=0,j=0;
 
 for(i=0,j=size-1;j-i>=0;i++,j--)
 {
  if(arr[i]<min /*&& arr[i]>arr[j]*/)
  {
   min=arr[i];
  }
  if(arr[j]<min /*&& arr[j]>arr[i]*/)
  {
   min=arr[j];
  }
 }
 
 return min;
}

int main()
{
 int size=0;
 int min=0;
 //float arr[]={11.2,15.3,45.78,78.3};
 printf("enter size:\n");
 scanf("%d",&size);
 int *arr=(int*)malloc(sizeof(int));
 printf("enter element:\n");
 
 for(int i=0;i<size;i++)
 {
  scanf("%d",&arr[i]);
 }
 
 min=Minimum(arr,size);
 
 cout<<"minimum number from arrays is:\n"<<min<<endl;
 
 return 0;
 



}
