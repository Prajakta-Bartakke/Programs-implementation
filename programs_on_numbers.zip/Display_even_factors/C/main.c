/* 
problem statement: 	accept number from user and display its even factors
*/
#include"header.h"
int main()
{
 int iVal=0;
  
 printf("enter number:\n");
 scanf("%d",&iVal);
 
 DisplayEvenFact(iVal);
 
 return 0;
}
