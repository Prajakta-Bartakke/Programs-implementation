#include<stdio.h>

void DisplayEvenFact(int);
