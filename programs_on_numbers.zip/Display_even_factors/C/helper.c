#include"header.h"

////////////////////////////////////////////
//
//function name:	DisplayEvenFact
//input:		integer
//return value:	none
//author:		Prajakta Aditya Bartakke
//date:		1 aug 2020
////////////////////////////////////////////

void DisplayEvenFact(int iNo)
{
 int iCnt=0;
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 for(iCnt=2;iCnt<=iNo/2;iCnt=iCnt+2)
 {
  if((iNo%iCnt)==0)
  {
   printf("%d\n",iCnt);
  }
 }
}
