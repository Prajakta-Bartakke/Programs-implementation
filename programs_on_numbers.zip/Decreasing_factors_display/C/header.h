#include<stdio.h>

void FactRev(int);
