#include"header.h"

//////////////////////////////////////////////
//
//function name:	FactRev
//input:		integer
//retrun value:	none
//description:		used to display the factors in reverse order
//author:		Prajakta Aditya Bartakke
//date:		1 aug 2020
////////////////////////////////////////////////

void FactRev(int iNo)
{

  if(iNo<0)
  {
   iNo=-iNo;
  }
  int iCnt=0;
  
  for(iCnt=(iNo/2);iCnt>=1;iCnt--)
  {
    if((iNo%iCnt)==0)
    { 
     printf("%d\n",iCnt);
    }
  }
}
