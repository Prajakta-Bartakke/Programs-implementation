/*  
  problem statement:	accept numeber from user and displya the factors in decreasing order
*/
#include"header.h"
int main()
{
 int iVal=0;
 printf("enter number:\n");
 scanf("%d",&iVal);
 
 FactRev(iVal);
 
 return 0;
}
