#include<stdio.h>

void DisplayNonFactors(int);
