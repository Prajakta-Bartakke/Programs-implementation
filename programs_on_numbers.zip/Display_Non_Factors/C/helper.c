#include"header.h"

//////////////////////////////////////////////////
//
//function name:	DisplayNonFactors
//input:		integer
//return value:	none
//description:		used to display non factors of a number
//author:		Prajakta Aditya Bartakke
//date:		1 August 2020
//////////////////////////////////////////////////

void DisplayNonFactors(int iNo)
{
  int iCnt=0;
  
  if(iNo<0)
  {
   iNo=-iNo ;
  }
  
  for(iCnt=1;iCnt<iNo;iCnt=iCnt+2)
  {
    if((iNo%iCnt)!=0)
    {
     printf("%d\n",iCnt);
    }
    if((iNo%(iCnt+1))!=0)
    {
      printf("%d\n",(iCnt+1));
    }
  }
}

/*
1 3 5 7 9 11 13 15 17 19 21 23                                                  2 ne pudhe jato loop tyamule iNo/2 complexity               O(iNo/2)    if no 24 loop 12 vela firto(no mhnje input) 

1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23			    1 ne pudhe gela tr loop tar complexity iNo		  O(iNo)

///////////////////////////////////////////////////
//
//time complexity:	O(N/2)
//
///////////////////////////////////////////////////





*/
