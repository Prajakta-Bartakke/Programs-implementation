#include<stdio.h>

int OddFactorial(int);


