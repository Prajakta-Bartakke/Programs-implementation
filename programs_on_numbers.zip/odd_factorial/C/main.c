/*
  problem statement: accept a number from user and calculate its odd factorial
*/
#include"header.h"
int main()
{
 int iVal=0;
 long int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iVal);
 
 iRet=OddFactorial(iVal);
 printf("%ld\n",iRet);
 return 0;
}

