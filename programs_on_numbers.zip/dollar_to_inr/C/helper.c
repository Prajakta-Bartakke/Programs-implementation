#include"header.h"

///////////////////////////////////////////////////////
//
//function name:	DollarToINR
//input:		integer
//return value:	integer
//description:		used to calculate amount in INR 
//author:		Prajakta Aditya Bartakke
//date:		9 aug 2020
////////////////////////////////////////////////////////

int DollarToINR(int iNo)
{
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 return (iNo*70);
}


 
 
 
 
 
 
 
 
