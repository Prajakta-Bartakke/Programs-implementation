/*
  problem statement: accept a amount in dollar from user and calculate its corresponding INR
*/
#include"header.h"
int main()
{
 int iVal=0;
 int iRet=0;
 
 printf("enter ammount in dollar:\n");
 scanf("%d",&iVal);
 
 iRet=DollarToINR(iVal);
 printf("%d\n",iRet);
 return 0;
}

