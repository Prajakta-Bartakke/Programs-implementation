#include<stdio.h>

int DollarToINR(int);
