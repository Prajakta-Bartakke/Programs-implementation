#include<stdio.h>

int EvenFactorial(int);

int OddFactorial(int);

int DiffFactorial(int);
