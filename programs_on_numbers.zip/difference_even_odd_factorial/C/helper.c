#include"header.h"

///////////////////////////////////////////////////////
//
//function name:	EvenFactorial
//input:		integer
//return value:	integer
//description:		used to print even factorial of number
//author:		Prajakta Aditya Bartakke
//date:		9 aug 2020
////////////////////////////////////////////////////////

int EvenFactorial(int iNo)
{
 int iMul=1;
 
 if(iNo==0)
 {
  return 0;
 }
 
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 while(iNo!=0)
 {
  if((iNo%2)!=0)
  {
   iNo=iNo-1;
  }
  iMul=iMul*iNo;
  iNo=iNo-2;
 }
 
 return iMul;
}
   
//////////////////////////////////////////
//
//time complexity:	O(N/2)
//
//////////////////////////////////////////
 
///////////////////////////////////////////////////////
//
//function name:	OddFactorial
//input:		integer
//return value:	integer
//description:		used to print odd factorial of number
//author:		Prajakta Aditya Bartakke
//date:		9 aug 2020
////////////////////////////////////////////////////////

int OddFactorial(int iNo)
{
 int iMul=1;
 
 if(iNo==0)
 {
  return 0;
 }
 
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 while(iNo!=1)
 {
  if((iNo%2)==0)
  {
   iNo=iNo-1;
  }
  iMul=iMul*iNo;
  iNo=iNo-2;
  	
 }
 
 return iMul;
}
   
//////////////////////////////////////////
//
//time complexity:	O(N/2)
//
//////////////////////////////////////////
 
 
///////////////////////////////////////////////////////
//
//function name:	DiffFactorial
//input:		integer
//return value:	integer
//description:		used to calculate difference between even factorial and odd factorial
//author:		Prajakta Aditya Bartakke
//date:		9 aug 2020
////////////////////////////////////////////////////////

int DiffFactorial(int iNo)
{
 int iEvenFact=0;
 int iOddFact=0;
 
 iEvenFact=EvenFactorial(iNo);
 
 iOddFact=OddFactorial(iNo);

 return (iEvenFact-iOddFact);
}

 
 
 
 
 
 
 
 
 
