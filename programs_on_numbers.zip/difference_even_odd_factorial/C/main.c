/*
  problem statement: accept a number from user and calculate difference between even and odd factorial
*/
#include"header.h"
int main()
{
 int iVal=0;
 int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iVal);
 
 iRet=DiffFactorial(iVal);
 printf("%d\n",iRet);
 return 0;
}

