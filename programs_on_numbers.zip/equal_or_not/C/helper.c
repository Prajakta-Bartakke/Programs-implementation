////////////////////////////////////////////////////////////
//
//function name:		ChkSame
//input:			integer
//return value:		boolean
//description:			used to check the 2 numbers are equal or not
//author:			Prajakta Aditya Bartakke
//date:			5 August 2020
////////////////////////////////////////////////////////////
#include"header.h"
BOOL ChkSame(int iNo1,int iNo2)
{
 if(iNo1==iNo2)
 {
   return TRUE;
 }
 else
 {
  return FALSE;
 }
} 

