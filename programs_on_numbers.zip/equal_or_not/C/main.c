/* 
  problem statement:  write a program which accepts 2 number from user and check  whether the number are same or not*/
 
#include"header.h"
int main()
{
 int iVal1=0,iVal2=0;
 BOOL bRet=FALSE;
 
 printf("enter first and second number\n");
 scanf("%d%d",&iVal1,&iVal2);
 
  bRet=ChkSame(iVal1,iVal2);
  
  if(bRet==TRUE)
  {
   printf("equal\n");
  }
  else
  {
   printf("not equal\n");
  }
  
  return 0;
 }
