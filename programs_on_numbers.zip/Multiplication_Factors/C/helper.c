#include"header.h"

//////////////////////////////////////////////////
//
//function name:	MultiFact
//input:		integer
//return value:	integer
//description:		it returns multiplication of factors
//author:		Prajakta Aditya Bartakke
//date:		1 aug 2020
/////////////////////////////////////////////////

int MultiFact(int iNo)
{

 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 int iCnt=0,iMul=1;
 
 for(iCnt=1;iCnt<=iNo/2;iCnt++)
 { 
   if((iNo%iCnt)==0)
   { 
     iMul=iMul*iCnt;
   }
 }
 return iMul;
}

//////////////////////////////////////////////
//
//time complexity:O(N/2)
//
//////////////////////////////////////////////
