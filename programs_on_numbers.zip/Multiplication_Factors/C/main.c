/*
  problem statemnt:	accept number from user and return its multiplication
*/
#include"header.h"
int main()
{
 int iVal=0,iRet=0;
 printf("enter number:\n");
 scanf("%d",&iVal);
 
 iRet=MultiFact(iVal);
 
 printf("multiplication is:%d\n",iRet);	
 
 return 0;
}
