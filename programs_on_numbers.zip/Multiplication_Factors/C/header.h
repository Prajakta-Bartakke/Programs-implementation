#include<stdio.h>

int MultiFact(int);
