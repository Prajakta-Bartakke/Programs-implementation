#include<stdio.h>

int Factorial(int);
