#include"header.h"

////////////////////////////////////////////////////////
//
//function name:		Factorial
//input:			integer
//return value:		integer
//description:			used to return factorial of a number
//author:			Prajakta Aditya Bartakke
//date:			6 aug 2020
////////////////////////////////////////////////////////

int Factorial(int iNo)
{

 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 int iFact=1;
 
 while(iNo!=0)
 {
  iFact=iFact*iNo;
  
  iNo--;
 }
 
 return iFact;
}
