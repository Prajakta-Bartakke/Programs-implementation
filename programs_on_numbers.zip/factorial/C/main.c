/*  
 problem sattemnt:  write a program which is used to accept number from user and return the factorial
*/

#include"header.h"
int main()
{
  int iVal=0,iRet=0;
  
  printf("enter number:\n");
  scanf("%d",&iVal);
  
  iRet=Factorial(iVal);
  
  printf("factorial of number is:%d\n",iRet);
  
  return 0;
}
