/* 
  problem statement: accept number from user and display all its non factors
*/

#include"header.h"
int main()
{
 int iVal=0;
 printf("enter number:\n");
 scanf("%d",&iVal);
 
 int iRet=AddNonFactors(iVal);
 printf("addition of non factors is:%d\n",iRet);
 
 return 0;
}
