#include<stdio.h>

int AddNonFactors(int);


