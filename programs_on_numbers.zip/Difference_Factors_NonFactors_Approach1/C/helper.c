
#include"header.h"

/////////////////////////////////////////////////////
//
//function name:	SumFactors
//input:		integer
//return value:	integer
//description:		it returns the sum of factors of given number
//author:		Prajakta Aditya Bartakke
//date:		30 july 2020
/////////////////////////////////////////////////////

int SumFactors(int iNo)
{
 int iCnt=0,iSum=1;
 
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 if(iNo==0)
 {
  iSum=0;
 }

 for(iCnt=2;iCnt<iNo;iCnt++)
 {
   if((iNo%iCnt)==0)
   {
     iSum=iSum+iCnt;
   }
 }
 
 return iSum;
}

///////////////////////////////////////////
// 
//time complexity: O(N)
//reduce time complexity loop half paryant firwa 
//new time coplexity:O(N/2)
///////////////////////////////////////////


/*
12%1==0

12%2==0

12%3==0

12%4==0

12%5!=0

12%6==0

12%7!=0

12%8!=0

12%9!=0

12%10!=0

12%11!=0*/
//////////////////////////////////////////////////
//
//function name:	AddNonFactors
//input:		integer
//return value:	integer
//description:		used to perfrom addition non factors of a number
//author:		Prajakta Aditya Bartakke
//date:		1 August 2020
//////////////////////////////////////////////////



int AddNonFactors(int iNo)
{
  int iCnt=0;
  int iSum=0;
  
  if(iNo<0)
  {
   iNo=-iNo;
  }
  
  for(iCnt=1;iCnt<iNo;iCnt=iCnt+2)
  {
    if((iNo%iCnt)!=0)
    {
     //printf("%d\n",iCnt);
     iSum=iSum+iCnt;
    }
    if((iNo%(iCnt+1))!=0)
    {
      //printf("%d\n",(iCnt+1));
      iSum=iSum+(iCnt+1);
    }
  }
  
  return iSum;
}

/*
1 3 5 7 9 11 13 15 17 19 21 23                                                  2 ne pudhe jato loop tyamule iNo/2 complexity               O(iNo/2)


1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23			    1 ne pudhe gela tr loop tar complexity iNo		  O(iNo)

*/

//////////////////////////////////////////////////
//
//function name:	FactDiff
//input:		integer
//return value:	integer
//description:		used to perfrom difference of non factors and factors of a number
//author:		Prajakta Aditya Bartakke
//date:		1 August 2020
//////////////////////////////////////////////////

int FactDiff(int iNo)
{
 int SumFact=SumFactors(iNo);
 
 int SumNonFact=AddNonFactors(iNo);
 
 int diffFact=(SumFact-SumNonFact);
 
 return diffFact;
}

































