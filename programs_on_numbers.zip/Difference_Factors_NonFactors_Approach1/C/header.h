#include<stdio.h>

int AddNonFactors(int);

int SumFactors(int );

int FactDiff(int);
