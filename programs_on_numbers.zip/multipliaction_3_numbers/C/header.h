#include<stdio.h>

int Multiplication(int,int,int);
