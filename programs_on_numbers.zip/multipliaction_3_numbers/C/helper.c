#include"header.h"

/////////////////////////////////////////////////////
//
//function name:		Multiplication
//input:			integer,integer,integer
//return value:		integer
//description:			used to multiply three numbers
//author:			Prajakta Aditya Bartakke
//date:			5 Aug 2020
/////////////////////////////////////////////////////

int Multiplication(int iNo1,int iNo2,int iNo3)
{
 int iMult=1;
 if(iNo1==0  &&  iNo2==0  &&  iNo3==0)
 {
  return 0;
 }
 if(iNo1==0)
 {
  iNo1=1;
 }
 if(iNo2==0)
 {
  iNo2=1;
 }
 if(iNo3==0)
 {
  iNo3=1;
 }
 
 iMult=(iNo1*iNo2*iNo3);
 
 return iMult;
}
