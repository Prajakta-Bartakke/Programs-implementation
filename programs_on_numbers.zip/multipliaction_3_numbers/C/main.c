/* 
 problem statement: write a program which accepts number from user and returns the multipliaction of them*/
 
#include"header.h"
int main()
{
 int iVal1=0,iVal2=0,iVal3=0,iMul=0;
 
 printf("enter three numbers:\n");
 scanf("%d%d%d",&iVal1,&iVal2,&iVal3);
 
 iMul=Multiplication(iVal1,iVal2,iVal3);
 
 printf("multiplication is : %d\n",iMul);
 
 return 0;
}
