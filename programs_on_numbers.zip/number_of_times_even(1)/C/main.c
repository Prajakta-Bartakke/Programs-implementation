
#include"header.h"
int main()
{
 int iVal=0;
 printf("enter number:\n");
 scanf("%d",&iVal);
 
 DisplayEven(iVal);
 
 return 0;
}
