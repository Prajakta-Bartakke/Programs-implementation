#include"header.h"

//////////////////////////////////////////////
// 
//function name:	DisplayEven
//input:		integer
//return value:	none
//description: 	it is used to display even numbers
//author:		Prajakta Aditya Bartakke
//date:		1 aug 2020
///////////////////////////////////////////////

void DisplayEven(int iNo)
{

 if(iNo<0)
 {
  iNo=-iNo;
 }
 int iCnt=2;
 
 int iCount=0;
 
 while(iCount!=iNo)
 {
  printf("%d\n",iCnt);
 
 iCnt=iCnt+2;
 
 iCount++;
}
}
