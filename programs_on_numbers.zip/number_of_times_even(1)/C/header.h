#include<stdio.h>

void DisplayEven(int);
