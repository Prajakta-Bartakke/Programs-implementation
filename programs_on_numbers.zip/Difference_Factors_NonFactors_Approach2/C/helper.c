#include"header.h"

//////////////////////////////////////////////////////
//
//function name:	DiffFactNonfact
//input:		integer
//return value:	integer
//discription:		used to return difference between summation of factors and summation of non factors
//author:		Prajakta Aditya Bartakke
//date:		1 aug 2020
//////////////////////////////////////////////////////

int DiffFactNonfact(int iNo)
{
 int iCnt=0;
 int iSum1=0,iSum2=0;
 
 for(iCnt=1;iCnt<iNo;iCnt++)
 {
   if((iNo%iCnt)==0)
   {
    iSum1=iSum1+iCnt;
   }
   if((iNo%iCnt)!=0)
   {
     iSum2=iSum2+iCnt;
   }
 }	
  
  return (iSum1-iSum2);
  
}

///////////////////////////////////////////////
//
//time complexity:	O(N-1);
//
///////////////////////////////////////////////
