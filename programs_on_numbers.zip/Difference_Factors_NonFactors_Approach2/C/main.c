/* 
  problem statement :   Accept number from user and return the diffrenece between summation between summation of factors and summation of non factors
*/

#include"header.h"
int main()
{
 int iVal=0;
 int iRet=0;
 
 printf("enter number:\n");
 scanf("%d",&iVal);
 
 iRet=DiffFactNonfact(iVal);
 printf("differenec is:%d\n",iRet);
 return 0;
}
