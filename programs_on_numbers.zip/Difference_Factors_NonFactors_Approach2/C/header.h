#include<stdio.h>

int DiffFactNonfact(int);
