#include"header.h"

///////////////////////////////////////////////////////
//
//function name:	EvenFactorial
//input:		integer
//return value:	integer
//description:		used to print even factorial of number
//author:		Prajakta Aditya Bartakke
//date:		9 aug 2020
////////////////////////////////////////////////////////

/*long int EvenFactorial(int iNo)
{
 long int iMul=1;
 
 if(iNo==0)
 {
  return 0;
 }
 
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 while(iNo!=0)
 {
  //printf("hi\n");
  if((iNo%2)==0)
  {  
   iMul=iMul*iNo;
  }
  iNo--;
 }
 return iMul;
}*/

///////////////////////////////////////////
//
//time complexity:	O(N)
//
///////////////////////////////////////////



long int EvenFactorial(int iNo)
{
 long int iMul=1;
 
 if(iNo==0)
 {
  return 0;
 }
 
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 while(iNo!=0)
 {
  if((iNo%2)!=0)
  {
   iNo=iNo-1;
  }
  iMul=iMul*iNo;
  iNo=iNo-2;
 }
 
 return iMul;
}
   
//////////////////////////////////////////
//
//time complexity:	O(N/2)
//
//////////////////////////////////////////
 
 
 
 
 
 
 
 
 
 
 
 
