#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
struct student
{
 int rollno;
 char name[20];
 int marks;
};

void OpenFile(char *fname,char *Iname)
{
 int fd=0;
 int ret=0,iCnt=0,iCnt1=0;
 struct student sobj;
 
 fd=open(fname,O_RDONLY);
 
 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }
 int no=1;
 while((ret=read(fd,&sobj,sizeof(sobj)))!=0)
 {
   no=strcmp(sobj.name,Iname);
   
   if(no==0)
   {
    printf("name:%s\n",sobj.name);
    printf("roll number:%d\n",sobj.rollno);
    printf("marks :%d\n",sobj.marks);
   }
   no=1;
 }
}
  
int main()
{
 char fname[20];
 char name[20];
 
 printf("enter file name:\n");
 scanf("%s",fname);
 
 printf("enter name of student:\n");
 scanf("%s",name);
 
 OpenFile(fname,name);
 
 return 0;
}
