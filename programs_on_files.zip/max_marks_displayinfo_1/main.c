#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
//size of object:->4+20+4=28

struct student
{
 int rollno;
 char name[20];
 int marks;
};

void OpenFile(char *fname)
{
 int fd=0;
 int ret=0;
 struct student sobj;                //ya object mdhe eka veli 24 bytes cha data yenar
 int iMax=0;
 int i=0;
 fd=open(fname,O_RDONLY);
 struct student* temp=(struct student*)malloc(sizeof(struct student));
 int j=0;
 
 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }
 iMax=sobj.marks;
 while((ret=read(fd,&sobj,sizeof(sobj)))!=0)
 {
   if(sobj.marks>iMax || sobj.marks==iMax)
   {
    iMax=sobj.marks;
    strcpy(temp[i].name,sobj.name);
    temp[i].rollno=sobj.rollno;
    temp[i].marks=sobj.marks;
    i++;
   }
 }
 
 for(j=0;j<i;j++)
 {
  printf("---------------------------------\n");
  if(temp[j].marks==iMax)
  {
  printf("name:%s\n",temp[j].name);
  
  printf("roll number:%d\n",temp[j].rollno);
  
  printf("marks:%d\n",temp[j].marks);
 }
 }
 
}
 
int main()
{
 char fname[20];

 printf("enter file name:\n");
 scanf("%s",fname);
  
 OpenFile(fname);
  
 return 0;
}






/*

structure cha objects cha array->
		way 1:count navacha function vaprun statically kara/lseek
		
		way 2:dynamically allocate kara
		
		
		way 1:
			int *arr;
			
			struct student *temp=(struct student*)malloc(sizeof(struct student));
			
*/
		
		
		































