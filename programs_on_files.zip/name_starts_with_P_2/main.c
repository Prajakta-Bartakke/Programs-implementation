#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>

//size of object:->4+20+4=28

struct student
{
 int rollno;
 char name[20];
 int marks;
};

void OpenFile(char *fname)
{
 int fd=0;
 int ret=0;
 struct student sobj;                //ya object mdhe eka veli 24 bytes cha data yenar
 
 fd=open(fname,O_RDONLY);
 
 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }
 
 while((ret=read(fd,&sobj,sizeof(sobj)))!=0)
 {
   char *ch=&(sobj.name);
   
   if((*ch)=='p')
   {
    printf("%s\n",sobj.name);
   }
 }

}
 
int main()
{
 char fname[20];

 printf("enter file name:\n");
 scanf("%s",fname);
  
 OpenFile(fname);
 
 return 0;
}
