#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>

struct student
{
 int rollno;
 char name[20];
 int marks;
};

void OpenFile(char *name)
{
 int fd=0;
 int ret=0;
 struct student sobj;
 fd=open(name,O_RDONLY);
 
 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }
 
 while((ret=read(fd,&sobj,sizeof(sobj)))!=0)
 {
  printf("---------------------------------\n");
  
  //printf("roll number is %d\n",sobj.rollno);
  
  printf("name of student is %s\n",sobj.name);
  
  //printf("marks of student is %d\n",sobj.marks);
  
  
 // printf("---------------------------------\n");
 }
 }

  

int main()
{
 char name[20];
 
 printf("enter file name:\n");
 scanf("%s",name);
 
 OpenFile(name);
 
 return 0;
}
