#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>

//size of object:->4+20+4=28

struct student
{
 int rollno;
 char name[20];
 int marks;
};

void OpenFile(char *fname,int marks)
{
 int fd=0;
 int ret=0;
 struct student sobj;                //ya object mdhe eka veli 24 bytes cha data yenar
 int iCnt=0;
 
 fd=open(fname,O_RDONLY);
 
 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }
 
 while((ret=read(fd,&sobj,sizeof(sobj)))!=0)
 {
  if(sobj.marks==marks)
  {
   printf("------------------------\n");
   printf("name:%s\n",sobj.name);
   printf("marks:%d\n",sobj.marks);
   printf("roll number:%d\n",sobj.rollno);
   
  }    
 }
}
 
int main()
{
 char fname[20];
 int marks=0;
 
 printf("enter file name:\n");
 scanf("%s",fname);
 
 printf("enter marks:\n");
 scanf("%d",&marks);
   
  
  
 OpenFile(fname,marks);
 
 return 0;
}
