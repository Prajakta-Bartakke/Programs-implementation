#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

typedef int BOOL;
#define UNABLE -9

int Count(char *fname)
{
 int fd=0;
 int ret=0,iCnt=0;
 char mug[100];
 
 fd=open(fname,O_RDONLY);
 
 if(fd==-1)
 {
  return UNABLE;
 }
   
 while((ret=read(fd,mug,100))!=0)  
 {
  for(int i=0;i<ret;i++)
  {
   if((mug[i])>=' ' && (mug[i])<=' ')
   {
    iCnt++;
   }
  }
 }
 return iCnt;
}
   
int main()
{
 char fname[20];
 int iRet=0;
 
 printf("enter file name:\n");
 scanf("%s",fname);
 
 iRet=Count(fname);
 
 if(iRet==UNABLE)
 {
  printf("Error:unable to opne\n");
 }
 else
 {
 printf("no of spaces are:%d\n",iRet);
 }
 
 return 0;
}
