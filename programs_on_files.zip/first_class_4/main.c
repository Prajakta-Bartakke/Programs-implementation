#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
//size of object:->4+20+4=28

struct student
{
 int rollno;
 char name[20];
 int marks;
};

void OpenFile(char *fname)
{
 int fd=0;
 int ret=0;
 struct student sobj;                //ya object mdhe eka veli 24 bytes cha data yenar
 int i=0;
 fd=open(fname,O_RDONLY);

 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }
 
 while((ret=read(fd,&sobj,sizeof(sobj)))!=0)
 {
   printf("---------------------------------\n");
   printf("name:%s\n",sobj.name);
   printf("roll number:%d\n",sobj.rollno);
   printf("marks:%d\n",sobj.marks);
   
   if(sobj.marks>=60 && sobj.marks<=100)
   {
    printf("first class\n");
   }
   else if(sobj.marks>=50 && sobj.marks<60)
   {
    printf("second class\n");
   }
   else if(sobj.marks>=0 && sobj.marks<50)
   {
    printf("pass class\n");
   }
   else
   {
    printf("fail\n");
   }
 }
 
}
 
int main()
{
 char fname[20];

 printf("enter file name:\n");
 scanf("%s",fname);
  
 OpenFile(fname);
  
 return 0;
}






/*

structure cha objects cha array->
		way 1:count navacha function vaprun statically kara/lseek
		
		way 2:dynamically allocate kara
		
		
		way 1:
			int *arr;
			
			struct student *temp=(struct student*)malloc(sizeof(struct student));
			
*/
		
		
		































