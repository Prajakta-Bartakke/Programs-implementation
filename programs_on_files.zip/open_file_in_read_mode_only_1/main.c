/*

accpet file name and open that file in read mode only

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{
 char name[20];
 int fd=0;
 
 printf("enter name of file:\n");
 scanf("%s",name);
 
 fd=open(name,O_RDONLY);
 
 if(fd==-1)
 {
  printf("Error:unable to open \n");
 }
 
 else 
 {
  printf("file opened succcessfully with file descriptor as %d\n",fd);
 }
 
 close (fd);
 return 0;
}


