/*

problem statement:
accept name from user and create that file

*/
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{
 char name[20];
 int fd=0;
 
 printf("enter name of file:\n");
 scanf("%s",name);
 
 fd=open(name,O_RDONLY | O_CREAT,0777);
 
 if(fd==-1)
 {
  printf("Error:unable to open file\n");
 }
 else
 {
  printf("file successfully created with file descriptor as %d\n",fd);
 }
 
 close (fd);
 
 return 0;
}
 
