/*

accept name of file and also accept one string from user and write that string at the end of the file

*/

#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>

void Append(char *filename,char *string)
{
 int fd=0,ret=0;
 int size=0;
 char arr[100]={'\0'};
 int i=0;
 char brr[100]={'\0'};
 fd=open(filename,O_RDWR);
 while((*string)!='\0')
 {
  i++;
  string++;
 }
 if(fd==-1)
 {
  printf("Error:unable to open file\n");
  return;
 }
 
 size=lseek(fd,0,SEEK_END);
 
 //while((ret=read(string,arr,100))!=0)
 //{
  //write(fd,arr,ret);
 //}
 
 size=lseek(fd,0,SEEK_SET);
 //ret=0;
 
 write(fd,string,(sizeof(char)*i));
 
 while((ret=read(fd,brr,100))!=0)
 {
  write(1,brr,ret);
 }
 //printf("%d\n",size);
 
}
int main()
{
 char name[20];
 char str[100];
 
 printf("enter name of file:\n");
 scanf("%s",name);
 
 printf("enter string:\n");
 scanf(" %[^'\n']s",str);
 
 Append(name,str);
 
 return 0;
}



/*write(fd,string,100);
 
 lseek(fd,0,SEEK_SET);
 
 while((ret=read(fd,arr,1))!=0)
 {
  write(1,arr,ret);
 }*/



