/*

accept file name and return the size of file

*/

/*
lseek->returns the size if parameter is SEEK_END

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int FileSize(char *name)
{
 int fd=0;
 int iCnt=0;
 int ret=0;
 char mug[1];
 
 fd=open(name,O_RDONLY);
 
 if(fd==-1)
 {
  printf("Error:unable to open file\n");
  return -1;
 }
 /*else                           
 {
  while((ret=read(fd,mug,1))!=0)         //os hard disk to ram sarkha sarkha karana is heavy
  {
   iCnt++;
  }
 }*/
 
 iCnt=lseek(fd,0,SEEK_END);              //ya lseek function sathi sarkha sarkha java nahi lagla hard disk var..//0...parametre mhje 0 pasun start

 return iCnt;
}

int main()
{
 char name[20];
 int iSize=0;
 
 printf("enter name of file:\n");
 scanf("%s",name);
 
 iSize=FileSize(name);

 printf("size of file is : %d\n",iSize);

 return 0;
}
