#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

void Display(char *fname)
{
 int fd=0;
 int ret=0;
 char mug[100];
 int i=0;
 fd=open(fname,O_RDONLY);
 
 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }
   
 while((ret=read(fd,mug,1))!=0  && i!=12)  
 {
  write(1,mug,1);
  i++;
 }
 
}
   
int main()
{
 char fname[20];
 int iRet=0;
 
 printf("enter file name:\n");
 scanf("%s",fname);
 
 Display(fname);
 
 return 0;
}
