
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>
//size of object:->4+20+4=28

struct student
{
 int rollno;
 char name[20];
 int marks;
};

void OpenFile(char *fname)
{
 int fd=0;
 //int avg=0,iSize=0,total=0,isum=0,ret=0;
 int isum=0;
 int ret=0;
 //int avg=0;
 int total=0;
 int isize=0;
 struct student sobj;                //ya object mdhe eka veli 24 bytes cha data yenar
 
 
 fd=open(fname,O_RDONLY);
 struct student* temp=(struct student*)malloc(sizeof(struct student));
 int j=0;
 
 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }

 while((ret=read(fd,&sobj,sizeof(sobj)))!=0)
 {
  isum=isum+sobj.marks;
 }

 isize=lseek(fd,0,SEEK_END);                        //lseek(SEEK_END)  cursor end la yeun jato tyamule he stmt adhi asel tar sum 0 yeil
 total=isize/(sizeof(struct student));
 
 printf("avearge marks:%d\n",isum/total);
 
}
 
int main()
{
 char fname[20];

 printf("enter file name:\n");
 scanf("%s",fname);
  
 OpenFile(fname);
  
 return 0;
}

/*

structure cha objects cha array->
		way 1:count navacha function vaprun statically kara/lseek
		
		way 2:dynamically allocate kara
		
		
		way 1:
			int *arr;
			
			struct student *temp=(struct student*)malloc(sizeof(struct student));
			
*/
