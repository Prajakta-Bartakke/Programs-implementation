/*

problem statement:accept name of file from user and read all the contenets>

*/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

void FileRead(char *name)
{
 int fd=0;
 char mug[100]={'\0'};
 int ret=0;
 
 //aadhi file open kara.
 
 fd=open(name,O_RDONLY | O_CREAT ,0777);
 
 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }
 else                       //open hot asel tarch 
 {
  printf("contents of the files are:\n");
  
  while((ret=read(fd,mug,100))!=0)    //fd->file descriptor..jo file asto  //mug->jyat data bhartoy,scanf la jasa address deto tasa..mug ha array tyamule arraycha address navat..//100->ekaveli 100bytes uchla
  {
   write(1,mug,ret);
  }
 }
}

int main()
{
 char name[30];
 int ret=0;
 
 printf("enter file name:\n");
 scanf("%s",name);
 
 FileRead(name);
 
 return 0;
}
