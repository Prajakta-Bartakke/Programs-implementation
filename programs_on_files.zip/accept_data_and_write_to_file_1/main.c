#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>

struct student
{
 int rollno;
 char name[20];
 int marks;
};

void StoreInfo(char *fname)
{
 int fd=0;
 int size=0,i=0;
 struct student sobj;
 
 fd=open(fname,O_WRONLY | O_CREAT,0777);
 
 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }
 
 printf("enter total number of students:\n");
 scanf("%d",&size);
 
 for(i=0;i<size;i++)
 {
  printf("enter roll number of student:\n");
  scanf("%d",&sobj.rollno);
  
  printf("enter name of student:\n");
  scanf("%s",&sobj.name);
 
  printf("enter marks of student:\n");
  scanf("%d",&sobj.marks);
  
  write(fd,&sobj,sizeof(sobj));
 } 
}

void OpenFile(char *name)
{
 int fd=0;
 int ret=0;
 struct student sobj;
 fd=open(name,O_RDONLY);
 
 if(fd==-1)
 {
  printf("Error:unable to open\n");
  return;
 }
 
 while((ret=read(fd,&sobj,sizeof(sobj)))!=0)
 {
  printf("---------------------------------\n");
  
  printf("roll number is %d\n",sobj.rollno);
  
  printf("name of student is %s\n",sobj.name);
  
  printf("marks of student is %d\n",sobj.marks);
  
  
 // printf("---------------------------------\n");
 }
 }

  

int main()
{
 char name[20];
 
 printf("enter file name:\n");
 scanf("%s",name);
 
// StoreInfo(name);
 
 OpenFile(name);
 
 return 0;
}
