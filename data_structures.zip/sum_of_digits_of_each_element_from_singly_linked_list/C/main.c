/*

problem statemnt:displya sum of all the digits of all numbers in linked list


*/


#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
 int data;
 struct Node*next;
}NODE,*PNODE,**PPNODE;

/////////////////////////////////////////
//
//Function name:	InsertFirst
//input parameter:	pointer cha address and integer
//return value:	none
//description:		used to add node at first position
//
///////////////////////////////////////////

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}

/////////////////////////////////////////
//
//Function name:	Display
//input parameter:	pointer 
//return value:	none
//description:		used to display nodes
//
///////////////////////////////////////////

void Display(PNODE first)
{
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
}

/////////////////////////////////////////
//
//Function name:	SumDigits
//input parameter:	pointer 
//return value:	none
//description:		used to display sum of digits of every number present in linked list
//
///////////////////////////////////////////


void SumDigits(PNODE first)
{
 int iDigit=0,iSum=0;
 
 if(first==NULL)
 {
  return;
 }
 
 while(first!=NULL)
 {
  if(first->data<0)
  {
   (first->data)=-(first->data);
  }
  while(first->data!=0)
  {
   iDigit=(first->data)%10;
   
   iSum=iSum+iDigit;
   
   (first->data)=((first->data)/10);
  }
  printf("%d\n",iSum);
  
  iSum=0;
  
  first=first->next;
 }
}

int main()
{
 PNODE Head=NULL;
 int iNo=0;
 int iRet=0;
 
 InsertFirst(&Head,89);
 InsertFirst(&Head,6);
 InsertFirst(&Head,41);
 InsertFirst(&Head,17);
 InsertFirst(&Head,28);
 InsertFirst(&Head,11);
 InsertFirst(&Head,-11);
 
 printf("content of linked list are:\n");
 Display(Head);
 
 //printf("\n");
 
 printf("-------------------------------------------------\n");
 
 SumDigits(Head);
 
 
 
 
 
 return 0;
}































