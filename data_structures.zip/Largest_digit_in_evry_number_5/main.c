#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node *next;
}NODE,*PNODE,**PPNODE;

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  return;
 }
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
}

void LargestDigit(PNODE first)
{
 int iMax=0;
 int iNo=0;
 
 if(first==NULL)
 {
  printf("Error:linked list empty\n");
  return;
 }
 else
 {
  while(first!=NULL)
  {
   iNo=first->data;
   if(iNo<0)
   {
    iNo=-iNo;
   }
   iMax=(iNo%10);
   while(iNo!=0)
   {
    if(iNo%10>iMax)
    {
      iMax=(iNo%10);
    }
    iNo=iNo/10;
   }
   printf("%d\n",iMax);
   first=first->next;
  }
 }
 }
 

int main()
{

 PNODE head=NULL;

 InsertFirst(&head,89);
 InsertFirst(&head,6);
 InsertFirst(&head,41);
 InsertFirst(&head,17);
 InsertFirst(&head,28);
 InsertFirst(&head,11);
 InsertFirst(&head,-789999);
 InsertFirst(&head,414);
 InsertFirst(&head,-414);
 InsertFirst(&head,2010805);
 InsertFirst(&head,0);
 Display(head);
 printf("----------------------------------------------\n");
 
 LargestDigit(head);
 
 printf("----------------------------------------------\n");
 Display(head);
 
 return 0;
}



