/*
problem statemnt: return the smallest element from the linked list
*/

#include<stdio.h>
#include<stdlib.h>
#define EMPTY -2

typedef struct Node
{
 int data;
 struct Node*next;
}NODE,*PNODE,**PPNODE;

/////////////////////////////////////////
//
//Function name:	InsertFirst
//input parameter:	pointer cha address and integer
//return value:	none
//description:		used to add node at first position
//
///////////////////////////////////////////

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}

/////////////////////////////////////////
//
//Function name:	Smallest
//input parameter:	pointer
//return value:	integer
//description:		used to return the Smallest elemnt from linked list
//
///////////////////////////////////////////

int Smallest(PNODE first)
{
 int iMin=0;
 
 if(first==NULL)
 {
  return EMPTY;
 }

 iMin=(first->data);
 
 while(first!=NULL)
 {
  if((first->data)<iMin)
  {
   iMin=(first->data);
  }
  first=first->next;
 }
 return iMin;

}

////////////////////////////////////////////////////
//
//function name:	Display
//input:		pointer
//return:		none
//description:		used to display the contents
//
///////////////////////////////////////////////////

void Display(PNODE first)
{
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
 }

int main()
{
 PNODE Head=NULL;
 int iNo=0;
 int iRet=0;
 
 InsertFirst(&Head,70);
 InsertFirst(&Head,30);
 InsertFirst(&Head,50);
 InsertFirst(&Head,40);
 InsertFirst(&Head,30);
 InsertFirst(&Head,20);
 InsertFirst(&Head,10);
 
 Display(Head);
 
 iRet=Smallest(Head);
 
 if(iRet==EMPTY)
 {
  printf("Error:linked list is empty\n");
 }
 else
 {
  printf("smalest element is:%d\n",iRet);
 }
 

 return 0;
}





























