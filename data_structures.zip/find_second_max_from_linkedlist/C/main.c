/*

problem statement: display return second maximum 

*/
#include<stdio.h>
#include<stdlib.h>
#define EMPTY -9
typedef struct Node
{
 int data;
 struct Node*next;
}NODE,*PNODE,**PPNODE;

/////////////////////////////////////////
//
//Function name:	InsertFirst
//input parameter:	pointer cha address and integer
//return value:	none
//description:		used to add node at first position
//
///////////////////////////////////////////

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}


/////////////////////////////////////////
//
//Function name:	SecMax
//input parameter:	pointer 
//return value:	int
//description:		used to return second maximum from linked list
//
///////////////////////////////////////////

int SecMax(PNODE first)
{
 if(first==NULL)
 {
  return EMPTY;
 }
 int iMax=0;
 int iSecmax=0;
 iMax=(first->data);
 
 while(first!=NULL)
 {
  if(first->data>iMax)
  {
   iSecmax=iMax;
   iMax=(first->data);
  }
  else if((first->data)<iMax  &&  (first->data)>iSecmax)
  {
   iSecmax=(first->data);
  }
  first=first->next;
  }
  
 return iSecmax;
}
 

void Display(PNODE first)
{
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
}

int main()
{
 PNODE Head=NULL;
 int iNo=0;
 int iRet=0;
 
 /*InsertFirst(&Head,240);
 InsertFirst(&Head,320);
 InsertFirst(&Head,230);
 InsertFirst(&Head,110);*/
 
 
 InsertFirst(&Head,28);
 InsertFirst(&Head,25);
 InsertFirst(&Head,51);
 InsertFirst(&Head,21);
 InsertFirst(&Head,11);
 
 printf("content of linked list are:\n");
 Display(Head);
 
 iRet=SecMax(Head);
 
 if(iRet==EMPTY)
 {
  printf("Error:linked list empty\n");
 }
 else
 {
  printf("second maximum numer is : %d\n",iRet);
 }
 
 printf("\n");
 
 return 0;
}




