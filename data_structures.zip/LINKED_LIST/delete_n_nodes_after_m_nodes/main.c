#include<stdio.h>
#include<stdlib.h>

typedef int BOOL;
#define SUCCESS 1
#define INVALID -2
//#define FAILURE -3
#define ERRORMEMORY -4
#define FALSE -9
typedef struct node
{
 int data;
 struct node*next;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:linked list empty\n");
  return;
 }
 else
 {
  while(first!=NULL)
  {
   printf("%d\t",first->data);
   first=first->next;
  }
  printf("\n");
 }
}
 
int Count(PNODE first)
{
 int cnt=0;
 
 if(first==NULL)
 {
  return -1;
 }
 else
 {
  while(first!=NULL)
  {
   cnt++;
   first=first->next;
  }
  
 }
 return cnt;
}


BOOL DeleteNodes(PPNODE first,int m,int n)
{
 if((*first)==NULL)
 {
  return ERRORMEMORY;
 }
 int cnt=Count((*first));
 if(m<0)      //updater
 {
  m=-m;
 }
 if(n<0)
 {
  n=-n;
 }
 if(cnt>=m+n)  //filter
 {
 int i=0,j=0;
 PNODE temp=(*first);
 PNODE tempprev=NULL,temp1=NULL;
 
 for(i=1;i<m;i++)
 {
  temp=temp->next;
 }
 tempprev=temp;
 for(j=1;j<=n;j++)
 {
  temp1=tempprev->next;
  
  if(tempprev==(*first) && tempprev->next==NULL)
  {
   temp1=tempprev;
   free (temp1);
   (*first)=NULL;
   return SUCCESS;                         //important stmt ahe.
  }
  if(j==1)
  {
   tempprev->next=temp->next->next;
  }
  else
  {
   if(temp!=NULL)
   tempprev->next=temp->next;
  }
  temp=tempprev->next;
  if(temp1!=NULL)
  free (temp1);
 }
 return SUCCESS;
}
else
{
 return INVALID;
}
}



int main()
{
 PNODE head=NULL;
 InsertLast(&head,1);
 InsertLast(&head,2);
 InsertLast(&head,3);
 InsertLast(&head,4);
 InsertLast(&head,5);
 InsertLast(&head,6);
 printf("before deleting nodes:\n");
 Display(head);
 
 int m=0,n=0;
 BOOL bret=FALSE;
 printf("from where the nodes are to be deleted\n");
 scanf("%d",&m);
 
 printf("enter how many nodes are to be deleted:\n");
 scanf("%d",&n);
 
 bret=DeleteNodes(&head,m,n);
 
 if(bret==INVALID)
 {
  printf("Error:invalid input\n");
 }
 else
 {
 printf("after deleting nodes:\n");
 Display(head);
}
 return 0;
}
