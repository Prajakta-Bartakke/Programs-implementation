
#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node *next;
 struct node *prev;
}NODE,*PNODE,**PPNODE;

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 newn->prev=NULL;

 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  
  (*first)->prev=newn;
  
  (*first)=newn;
 }
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  return;
 }
 else
 {
  while(first!=NULL)
  {
   printf("|%d|->\t",first->data);
   first=first->next;
  }
  printf("\n");
 }
}

void DeleteEven(PPNODE first)
{
 if((*first)==NULL)
 {
  return;
 }
 PNODE temp1=(*first);
 
 if((temp1->prev==NULL)  &&  (temp1->next==NULL)  &&  ((temp1->data)%2==0))
 {
  free (temp1);
  
  (*first)=NULL;
  
  return;
 }
 
 while(temp1!=NULL)
 {

  if((temp1->data)%2==0)
  {
   if(temp1==(*first))
   {
     temp1=temp1->next;
     
     free (temp1->prev);
     
     temp1->prev=NULL;
     
     (*first)=temp1;
   }
   
   else if(temp1->next!=NULL)
   {
     temp1->prev->next=temp1->next;
     
     temp1=temp1->prev;
     
     free (temp1->next->prev);
     
     temp1->next->prev=temp1;
     
     temp1=temp1->next;
     
   }
   
   else if(temp1->next==NULL)
   {
     free (temp1->prev->next);
     
     temp1->prev->next=NULL;
     
     break;
    }
    
  }
  
  else
  {
   temp1=temp1->next;
  }
 }
}     

int main()
{

 PNODE head=NULL;
 
 InsertFirst(&head,4);
 InsertFirst(&head,5);
 InsertFirst(&head,11);
 InsertFirst(&head,8);
 InsertFirst(&head,7);
 InsertFirst(&head,10);
 InsertFirst(&head,51);
 InsertFirst(&head,26);
 
 Display(head);
 
 printf("\n");
 
 DeleteEven(&head);
 
 Display(head);
 
 
 return 0;
}
