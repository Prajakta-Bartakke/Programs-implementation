#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node*next;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
 PNODE temp=(*first);
 while(temp->next!=NULL)
 {
  temp=temp->next;
 }
 temp->next=newn;
 }
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  return;
 }
 while(first!=NULL)
 {
  printf("%d\t",first->data);
  first=first->next;
 }
 printf("\n");
 
}

int Count(PNODE first)
{
 if(first==NULL)
 {
  return -1;
 }
 
 int cnt=0;
 
 while(first!=NULL)
 {
  cnt++;
  first=first->next;
 }
 return cnt;
}

void TripletDisplay(PNODE first,PNODE second,PNODE third,int no)
{
 if((first==NULL || second==NULL || third==NULL))
 {
  printf("Error:invalid input\n");
  return;
 }
 
 int cnt1=Count(first);
 int cnt2=Count(second);
 int cnt3=Count(third);
 int i=0,j=0,k=0;
 PNODE temp1=first,temp2=second,temp3=third;
 
 if((cnt1==cnt2) && (cnt2==cnt3))
 {
  for(i=0;i<=cnt1-1;i++)
  {
   for(j=0;j<=cnt1-1;j++)
   {
    for(k=0;k<=cnt1-1;k++)
    {
     if(temp1->data+temp2->data+temp3->data==no)
     {
      printf("%d\t",temp1->data);
      printf("%d\t",temp2->data);
      printf("%d\t",temp3->data);
     }
     temp3=temp3->next;
    }
   
    temp3=third;
    temp2=temp2->next;
   }
   temp2=second;
   temp1=temp1->next;
  }
   
 }
 
 else
 {
  printf("Error:invalid input\n");
  return;
 }
 printf("\n");
}


int main()
{
 PNODE head1=NULL;
 PNODE head2=NULL;
 PNODE head3=NULL;
 int no=0;
 
 InsertLast(&head1,12);
 InsertLast(&head1,6);
 InsertLast(&head1,29);
 
 InsertLast(&head2,23);
 InsertLast(&head2,5);
 InsertLast(&head2,8);
 
 InsertLast(&head3,90);
 InsertLast(&head3,20);
 InsertLast(&head3,59);
 
 
 
 printf("enter number for which the triplets has to be displayed\n");
 scanf("%d",&no);
 
 TripletDisplay(head1,head2,head3,no);

 return 0;
}
