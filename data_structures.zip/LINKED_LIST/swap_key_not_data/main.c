/*
 test cases:
 	whereever the head pointer is used 
 	
 	means if xpos or ypos 1 asel tar
 	
 	ani last node ani first node swap kelyawar
 	
*/


#include<stdio.h>
#include<stdlib.h>

typedef int BOOL;
#define TRUE 1
#define FALSE 0
//#define FAILURE -3
#define ERRORMEMORY -4
//#define FALSE -9
typedef struct node
{
 int data;
 struct node*next;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:linked list empty\n");
  return;
 }
 else
 {
  while(first!=NULL)
  {
   printf("%d\t",first->data);
   first=first->next;
  }
  printf("\n");
 }
}

BOOL ChkPresent(PNODE first,int x,int y)
{
 BOOL flag1=FALSE;
 BOOL flag2=FALSE;
 
 while(first!=NULL)
 {
  if(first->data==x)
  {
   flag1=TRUE;
  }
  if(first->data==y)
  {
   flag2=TRUE;
  }
  first=first->next;
 }
 
 if(flag1==TRUE && flag2==TRUE)
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
}

int Position(PNODE first,int no)
{
 int i=0;
 
 while(first!=NULL)
 {
  i++;
  if(first->data==no)
  {
   break;
  }
  first=first->next;
 }
 if(first!=NULL && first->data==no)
 {
  return i;
 }
 else
 {
  return -1;
 }
}

void SwapNodes(PPNODE first,int x,int y)
{
 if((*first)==NULL  ||  x==y)
 {
  return;
 }
 BOOL Chk=ChkPresent((*first),x,y);               //donhi number present astil tar proceeed
 
 int xpos=0,ypos=0,i=0;
 
 PNODE temp=(*first);
 PNODE temp1=NULL;

 PNODE NextLink1=NULL;
 PNODE NextLink2=NULL;
 
 
 PNODE PrevSmall=NULL;
 PNODE PrevLarge=NULL;
 
 if(Chk==TRUE)
 {
  xpos=Position((*first),x);
  ypos=Position((*first),y);
  
  if(ypos-xpos==1  &&  xpos!=1)     //ekapudhe dusri node
  {
   for(i=1;i<=ypos-1;i++)
   {
    if(temp->next->data==x)
    {
     PrevSmall=temp;         //prevsmall->200
     temp1=temp->next;	      //temp1=300
    }
    temp=temp->next;
   }//temp=400	
   NextLink1=temp->next;
   /*printf("prevsmall:%d\n",PrevSmall->data);
   printf("temp:%d\n",temp->data);
   printf("temp1:%d\n",temp1->data);*/
  PrevSmall->next=temp;
  temp->next=temp1;
  temp1->next=NextLink1;
  }
  
  else if(ypos-xpos==-1)     //ekapudhe dusri node
  {
   for(i=1;i<=xpos-1;i++)
   {
    if(temp->next->data==y)
    {
     PrevSmall=temp;         //prevsmall->200
     temp1=temp->next;	      //temp1=300
    }
    temp=temp->next;
   }//temp=400	
   NextLink1=temp->next;
   /*printf("prevsmall:%d\n",PrevSmall->data);
   printf("temp:%d\n",temp->data);
   printf("temp1:%d\n",temp1->data);*/
  PrevSmall->next=temp;
  temp->next=temp1;
  temp1->next=NextLink1;
  }
  
  else if(xpos==1)         //mhnje pahili node
  {
   temp1=temp;             //temp mdhe 100
   NextLink1=temp->next;   //NextLink1=200
   for(i=1;i<=ypos-1;i++)
   {
    if(i==ypos-2)
    {
     PrevLarge=temp->next;       //prevlarge=500    ;500 cha next mdhe 100
    }
    temp=temp->next;
    printf("temp data inside for loop:%d\n",temp->data);
   }
   NextLink2=temp->next;   //Nexlink2=NULL;
   
   (*first)=temp;          //head mdhe 600
   (*first)->next=NextLink1;
   PrevLarge->next=temp1;
   temp1->next=NextLink2;
   
   /*printf("NextLink1 cha data:%d\n",NextLink1->data);
   printf("prevlarge chi val:%d\n",PrevLarge->data);
   printf("temp cha data outside loop:%d\n",temp->data);
   printf("temp1 cha data:%d\n",temp1->data);*/
  }

  else if(ypos>xpos)
  {
   for(i=1;i<=ypos-1;i++)
   {
    if(temp->next->data==x)
    {
     PrevSmall=temp;
     temp1=temp->next;
     NextLink1=temp->next->next;
    }
    else if(i==ypos-2)   
    {
     PrevLarge=temp->next;
     NextLink2=PrevLarge->next->next;
    }
    temp=temp->next;
   }
   
   temp->next=NextLink1;
   PrevSmall->next=temp;
   PrevLarge->next=temp1;
   temp1->next=NextLink2;
  
  }
  else if(xpos>ypos)
  {
   for(i=1;i<=xpos-1;i++)
   {
    if(temp->next->data==y)
    {
     PrevSmall=temp;
     temp1=temp->next;
     NextLink1=temp->next->next;
    }
    else if(i==xpos-2)   
    {
     PrevLarge=temp->next;
     NextLink2=PrevLarge->next->next;
    }
    temp=temp->next;
   }
   
   temp->next=NextLink1;
   PrevSmall->next=temp;
   PrevLarge->next=temp1;
   temp1->next=NextLink2;

  }
 
 }
 else       //either ek number present nahi kiva donhi number linked list mdhe nahi
 {
  return;
 }
 
}
int main()
{
 PNODE head=NULL;
 int x=0,y=0;

 InsertLast(&head,10);
 InsertLast(&head,15);
 InsertLast(&head,12);
 InsertLast(&head,13);
 InsertLast(&head,20);
 InsertLast(&head,14);

 printf("enter the first number:\n");
 scanf("%d",&x);
 
 printf("enter second number:\n");
 scanf("%d",&y);
 
 
 printf("before swapping the nodes:\n");
 Display(head);
 
 SwapNodes(&head,x,y);
 
 printf("after swapping nodes:\n");
 Display(head);
 
 return 0;
}

/*
 100 ->200 ->300 ->400 -> 500 ->600
 
 600 ->200 ->300 ->400 ->500 ->100
 
 
 
 links ->  500 cha pudhe 100
 
 	    100 cha pudhcha 600 cha pudhcha hoto
 	    
 	    100 cha next mdhe 600 cha next jayla hava


*/
 
