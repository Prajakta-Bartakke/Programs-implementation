#include<stdio.h>
#include<stdlib.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0
#define EMPTY -2

typedef struct node
{
 char ch;
 struct node *next;
}NODE,*PNODE,**PPNODE;


void InsertLast(PPNODE first,char ch)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->ch=ch;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
}

void Display(PNODE head)
{
 while(head!=NULL)
 {
  printf("%c\t",head->ch);
  head=head->next;
 }
 printf("\n");
}

int Count(PNODE head)
{
 int iCnt=0;
 
 while(head!=NULL)
 {
  iCnt++;
  head=head->next;
 }
 
 return iCnt;
}


BOOL ChkPalindrome(PNODE first)
{
 if(first==NULL)
 {
  return EMPTY;
 }
 else if(first->next==NULL)
 {
  return TRUE;
 }

 PNODE temp1=first;
 int iCount=0;
 
 int i=0,j=0;
 int iCnt=Count(first);
 
 if((iCnt%2)!=0)
 {
  for(i=1;i<=(iCnt/2)+1;i++)
  {
   PNODE temp2=first;
   
   for(j=1;j<=(iCnt-i);j++)
   {
    temp2=temp2->next;
   }
   
   if(temp1->ch==temp2->ch)
   {
    iCount++;
   }
   
   temp1=temp1->next;
  }
}
 
 else if((iCnt%2)==0)
 {
  for(i=1;i<=iCnt;i++)
  {
   PNODE temp2=first;
   
   for(j=1;j<=(iCnt-i);j++)
   {
    temp2=temp2->next;
   }
   
   if(temp1->ch==temp2->ch)
   {
    printf("%c\n",temp1->ch);
    iCount++;
   }
   
   temp1=temp1->next;
  }
}
printf("%d\n",iCount);
printf("%d\n",(iCnt/2));
printf("%d\n",iCnt);
if(iCnt%2==0  &&  iCount==iCnt)
{
  return TRUE;
}
else if(iCnt%2!=0  &&  iCount==((iCnt/2)+1))
{
  return TRUE;
}
else 
{
  return FALSE;
}
}

int main()
{
 PNODE head=NULL;
 BOOL bRet=FALSE;
 
 //InsertLast(&head,'r');
 /*InsertLast(&head,'a');
 InsertLast(&head,'d');
 InsertLast(&head,'a');*/
 //InsertLast(&head,'r');
 
 Display(head);
 
 bRet=ChkPalindrome(head);
 
 if(bRet==EMPTY)
 {
  printf("Error:linked list empty\n");
 }
 
 else if(bRet==TRUE)
 {
  printf("palindrome\n");
 }
 else
 {
  printf("not a palindrome\n");
 }
 
 
 return 0;
}
