#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node*next;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:linked list empty\n");
  return;
 }
 else
 {
  while(first!=NULL)
  {
   printf("%d\n",first->data);
   first=first->next;
  }
 }
}

int CountDigit(int no)
{
 int cnt=0;
 
 while(no!=0)
 {
  cnt++;
  no=no/10;
 }
 return cnt;
}

int CountNodes(PNODE first)
{
 int cnt=0;
 if(first==NULL)
 {
  return -1;
 }
 else
 {
  while(first!=NULL)
  {
   cnt++;
   first=first->next;
  }
 }
 return cnt;
}




int SumList(PNODE first,PNODE second)
{
 if(first==NULL && second==NULL)
 {
  return -1;
 }
 int size1=0,size2=0;
 
 if(first!=NULL)
 {
 size1=CountNodes(first);
 }
 int arr1[size1];

 if(second!=NULL)
 {
 size2=CountNodes(second);
 }
 int arr2[size2];
 int i=0,j=0,cnt=0,num1=0,num2=0;
 while(first!=NULL)
 {
  arr1[i]=first->data;
  i++;
  first=first->next;
 }
 i=0;
 while(second!=NULL)
 {
  arr2[i]=second->data;
  i++;
  second=second->next;
 }
 
 
 for(j=size1-1;j>=0;j--)
 {
  cnt=CountDigit(arr1[j]);
  
  if(cnt==1)
  {
   num1=num1*10+(arr1[j]);
  }
 }
 
 for(j=size2-1;j>=0;j--)
 {
  cnt=CountDigit(arr2[j]);
  
  if(cnt==1)
  {
   num2=num2*10+(arr2[j]);
  }
 }
 
 return (num1+num2);
}

int main()
{
 PNODE head=NULL;
 PNODE head1=NULL;
 InsertLast(&head,5);
 InsertLast(&head,6);
 InsertLast(&head,3);
 //InsertLast(&head1,1);
 InsertLast(&head1,8);
 InsertLast(&head1,4);
 InsertLast(&head1,2);
 //Display(head);
 int sum=SumList(head,head1);
 printf("sum of linked lists are:%d\n",sum);
 return 0;
}
