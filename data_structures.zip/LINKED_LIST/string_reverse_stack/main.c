/*

 kaamal goshta:=memory free kara


*/
#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
 char data;
 struct node *next;
}NODE,*PNODE;

void ReverseString(char arr[])
{
 if(arr==NULL)
 {
  printf("Error:invalid input\n");
  return;
 }
 int i=0,start=0,end=0;
 PNODE head=NULL;
 
 while(arr[i]!='\0')
 {
  if((i==0 && arr[i]!=' ') || (arr[i]!=' '))
  {
   if((i==0 && arr[i]!=' ')||(i!=0 && arr[i]!=' ' &&  arr[i-1]==' '))
   {
   start=i;
   }
   PNODE newn=(PNODE)malloc(sizeof(NODE));
   newn->data=arr[i];
   newn->next=NULL;
   if(head==NULL)
   {
    head=newn;
   }
   else
   {
    newn->next=head;
    head=newn;
   } 
  }
  
  if((arr[i]==' ' &&  arr[i+1]!=' ') ||  (arr[i]!=' '  &&  arr[i+1]=='\0'))
  {
   PNODE temp=head;
   
   while(temp!=NULL)
   {
    arr[start]=temp->data;
    temp=temp->next;
    start++;
   }
   
   while(head!=NULL)
   {
    temp=head;
    head=head->next;
    free (temp);
   } 
  }
 i++;
 }
 
 printf("new string is :%s\n",arr);

}

int main()
{
 char str[100]={'\0'};
 
 printf("enter string:\n");
 scanf("%[^'\n']s",str);

 ReverseString(str);


 return 0;
}


