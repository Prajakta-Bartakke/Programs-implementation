#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node *next;
}NODE,*PNODE,**PPNODE;

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:linked list empty\n");
  return;
 }
 else
 {
  while(first!=NULL)
  {
   printf("%d->",first->data);
   first=first->next;
  }
  printf("NULL\n");
 }
}


int Count(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:linked list empty\n");
  return -1;
 }
 else
 {
  int iCnt=0;
  while(first!=NULL)
  {
   iCnt++;
   first=first->next;
  }
  return iCnt;
 }
 
}

int SumNodes(PNODE first,int n)
{
 int iCnt=Count(first);
 if(n<1 || n>iCnt)
 {
  printf("Error:invalid input\n");
  return -1;
 }
  
 if(first==NULL)
 {
  printf("Error:linked list empty\n");
  return -1;
 }
 else
 {
  int i=0,iSum=0;
  int iCnt=Count(first);
  
  for(i=1;i<=(iCnt-n);i++)
  {
   printf("for\n");
   first=first->next;
  }
 
  if(n==iCnt)
  {
   for(i=1;i<=iCnt;i++)
   {
    iSum=iSum+(first->data);
    first=first->next;
   }
  }
  
  else
  {
  for(i;i<=iCnt;i++)
  {
   iSum=iSum+(first->data);
   first=first->next;
  }
  }
  
  return iSum; 
 }

}

int main()
{
 PNODE head=NULL;
 int iRet=0;
 int iVal=0;
 
 InsertFirst(&head,111);
 InsertFirst(&head,101);
 InsertFirst(&head,51);
 InsertFirst(&head,21);
 InsertFirst(&head,11);
 
 Display(head);
 
 printf("sum of last how many nodes you want\n");
 scanf("%d",&iVal);
 
 iRet=SumNodes(head,iVal);
 printf("%d\n",iRet);
 
 
 return 0;
}
