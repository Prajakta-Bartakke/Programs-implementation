#include<stdio.h>
#include<stdlib.h>
typedef int BOOL;
#define TRUE 1
#define FALSE 0
typedef struct node
{
 char data;
 struct node *next;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,char c)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=c;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:linked list empty\n");
  return;
 }
 else
 {
  while(first!=NULL)
  {
   printf("%c\t",first->data);
   first=first->next;
  }
  printf("\n");
 }
}

int Count(PNODE first)
{
 int cnt=0;
 if(first==NULL)
 {
  return -1;
 }
 else
 {
  
  while(first!=NULL)
  {
   cnt++;
   first=first->next;
  }
 }
 return cnt;
}

int CompareX(PNODE first,PNODE second)
{
 if((first==NULL && second==NULL) || (first==NULL && second!=NULL) || (first!=NULL && second==NULL))
 {
  return -2;
 }
 
 int cnt1=Count(first);
 int cnt2=Count(second);
 BOOL flag=TRUE;
 if(cnt1!=cnt2)
 {
  return 1;
 }
 
 else
 {
  while(first!=NULL  &&  second!=NULL)
  {
   if(first->data!=second->data)
   {
    flag=FALSE;
    break;
   }
   first=first->next;
   second=second->next;
  }
 }
 if(flag==TRUE)
 {
  return 0;
 }
 else
 {
  return -1;
 }
}
  

int main()
{
 PNODE head=NULL;
 PNODE head1=NULL;
 
 InsertLast(&head,'g');
 InsertLast(&head,'e');
 InsertLast(&head,'e');
 InsertLast(&head,'k');
 InsertLast(&head,'a');
 
 InsertLast(&head1,'g');
 InsertLast(&head1,'e');
 InsertLast(&head1,'e');
 InsertLast(&head1,'k');
 InsertLast(&head1,'b');
 
 
 Display(head);
 Display(head1);
 
 int ret=CompareX(head,head1);
 
 if(ret==0)
 {
  printf("equal\n");
 }
 else if(ret==1)
 {
  printf("size of linked list mismatched\n");
 }
 else if(ret==-1)
 {
  printf("not equal\n");
 }
 else
 {
  printf("invalid input\n");
 }
 return 0;
}
