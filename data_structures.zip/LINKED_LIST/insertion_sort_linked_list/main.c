/*

first element is sorted

mhnje start from 1 st index  

compare karaycha tyacha adhicha elemnet sobat jar kami asel tar to paraynat compare karaycha jopryant aaplyakde aslela elemant motha yet nahi

jar particulat index cha element jar adhicha ele peksha lahan asel tar to element pudhcha dabyat thevaycha.


*/
#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node *next;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
 
}

void Display(PNODE temp)
{
 if(temp==NULL)
 {
  printf("Error:linked list empty\n");
  return;
 }
 while(temp!=NULL)
 {
  printf("%d\t",temp->data);
  temp=temp->next;
 }
 printf("\n");
 
}

void InsertionSort(int *arr,int size)
{
 if(arr==NULL)
 {
  return;
 }
 
 int i=0,temp=0,prev=0;
 
 for(i=1;i<size;i++)
 {
  prev=i-1;
  temp=arr[i];
  
  if(temp<arr[prev])
  {  
   while(temp<arr[prev] && prev>=0)
   {
    arr[prev+1]=arr[prev];
    prev=prev-1;
   }
   arr[prev+1]=temp;
  }
 }
 
}
int main()
{
 /*PNODE head=NULL;
 InsertLast(&head,11);
 InsertLast(&head,21);
 InsertLast(&head,51);
 InsertLast(&head,101);
 InsertLast(&head,111);
 Display(head);*/
 int size=0;
 
 printf("Enter size:\n");
 scanf("%d",&size);
 
 int *arr=(int*)malloc(sizeof(int)*size);
 
 printf("Enter elements:\n");
 
 for(int i=0;i<size;i++)
 {
  scanf("%d",&arr[i]);
 }
 
 InsertionSort(arr,size);
 
 for(int i=0;i<size;i++)
 {
  printf("%d\t",arr[i]);
 }
 printf("\n");
 
 return 0;
}
