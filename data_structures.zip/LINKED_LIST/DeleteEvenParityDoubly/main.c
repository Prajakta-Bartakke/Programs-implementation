/*

Input: CLL = 9 -> 11 -> 34 -> 6 -> 13 -> 21 


*/

#include<stdio.h>
#include<stdlib.h>



typedef struct node
{
 int data;
 struct node*next;
 struct node* prev;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,PPNODE last,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 newn->prev=NULL;
 
 if((*first)==NULL && (*last)==NULL)
 {
  (*first)=newn;
  (*last)=newn;
 }
 else
 {
  (*last)->next=newn;
  newn->prev=(*last);
  (*last)=newn;
 }
  
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  return;
 }
 
  while(first!=NULL)
  {
   printf("%d\t",first->data);
   first=first->next;
  } 
 
 printf("\n");
 
}

int CreateOne(int no)
{
 PNODE head=NULL;
 int cnt=0;
 
 while(no!=0)
 {
  PNODE newn=(PNODE)malloc(sizeof(NODE));
  newn->data=no%2;      //
  if(newn->data==1)
  {
   cnt++;
  }
  newn->next=NULL;
  
  if(head==NULL)
  {
   head=newn;
  }
  else
  {
   newn->next=head;
   head=newn;
  }
  no=no/2;
 }
 
 PNODE temp=head;
 
 /*while(temp!=NULL)
 {
  printf("%d",temp->data);
  temp=temp->next;
 }
 printf("\n");*/
 
 return cnt; 
 
}

void DeleteEvenParity(PPNODE first)
{
 if((*first)==NULL)
 {
  return;
 }
 PNODE temp=(*first),temp1=NULL,tempprev=NULL;
 int no=0;
 
 while(temp!=NULL)
 {
  Display((*first));
  no=CreateOne(temp->data);
  
  if((no%2)==0)      //even parity wale delete
  {
   if(temp==(*first)  &&  (*first)->next==NULL)    //ekach node
   {
    free (*first);
    (*first)=NULL;
   }
   else if(temp==(*first))    //require head node
   {
    (*first)=temp->next;
    temp=temp->next;
    free ((*first)->prev);
    (*first)->prev=NULL;
    //printf("%d\n",temp->data);
   }
   else
   {
    tempprev->next=temp->next;     
    temp=temp->next;
    free (tempprev->next->prev);
    tempprev->next->prev=tempprev;
   }  
  }
  else
  {
   tempprev=temp;
   temp=temp->next;
  }
 }

}


int main()
{
 PNODE head=NULL;
 PNODE tail=NULL;
 
 InsertLast(&head,&tail,9);
 InsertLast(&head,&tail,11);
 InsertLast(&head,&tail,34);
 InsertLast(&head,&tail,6);
 InsertLast(&head,&tail,13);
 InsertLast(&head,&tail,21);
 
 /*printf("before deleting nodes:\n");
 Display(head);*/
 
 DeleteEvenParity(&head);
 
 printf("after deleting even parity nodes:\n");
 
 Display(head);

 
 return 0;
}
