#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node *next;
}NODE,*PNODE,**PPNODE;

void InsertNode(PPNODE first,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  *first=newn;
 }
 
 else if((*first)->next==NULL)       //ekach node aahe ani insert karaychay.........loop perfectly fine
 {
  if(newn->data>(*first)->data)
  {
   (*first)->next=newn;
  }
  else if(newn->data<(*first)->data)
  {
   newn->next=(*first);
   (*first)=newn;
 }
 }

 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)      //ya loop sathi somethingggggg
  {
   if(newn->data<temp->data  &&  temp==(*first))
   {
    printf("inside if\n");
    newn->next=(*first);
    (*first)=newn;
    break;
   }
   else if(newn->data>temp->data  &&  newn->data<temp->next->data)
   {
    newn->next=temp->next;
    temp->next=newn;
    break;
   }  
  
   temp=temp->next;
  }
  
  if(newn->data>temp->data)       //at last
  {
  temp->next=newn;
  }

 }
}
   
void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:linked list is empty\n");
  return;
 }
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
}   
   
    
int main()
{
 PNODE head=NULL;
 
 int no=0;
 int val=0;
 
 while(1)
 {
  printf("to insert node in linked list enter 1\n");
  printf("to display linked list enter 2\n");
  printf("to exit enter 0\n");
  scanf("%d",&no);
  if(no==0)
  {
   break;
  }  
  switch(no)
  {
   case 1:
   	printf("enter number to be inserted:\n");
   	scanf("%d",&val);
	InsertNode(&head,val);
   break;
  
   case 2:
   	Display(head);
   break;
   
  }
  }

 return 0;

}

