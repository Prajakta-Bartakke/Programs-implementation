/*

Input: CLL = 9 -> 11 -> 34 -> 6 -> 13 -> 21 


*/

#include<stdio.h>
#include<stdlib.h>

typedef int BOOL;
#define TRUE 1
#define FALSE 0

typedef struct node
{
 int data;
 struct node*next;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,PPNODE last,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL && (*last)==NULL)
 {
  (*first)=newn;
  (*last)=newn;
 }
 else if((*first)==(*last))    //have one node
 {
  (*last)=newn;
  (*first)->next=newn;
 }
 else
 {
  (*last)->next=newn;
  (*last)=newn;
 }
 (*last)->next=(*first);

}

void Display(PNODE first,PNODE last)
{
 if(first==NULL)
 {
  printf("Error:linked list empty\n");
  return;
 }
 do
 {
  printf("%d\t",first->data);
  first=first->next;
 }while(first!=last->next);
 printf("\n");
}

int CreateOne(int no)
{
 PNODE head=NULL;
 int cnt=0;
 
 while(no!=0)
 {
  PNODE newn=(PNODE)malloc(sizeof(NODE));
  newn->data=no%2;      //
  if(newn->data==1)
  {
   cnt++;
  }
  newn->next=NULL;
  
  if(head==NULL)
  {
   head=newn;
  }
  else
  {
   newn->next=head;
   head=newn;
  }
  no=no/2;
 }
 
 PNODE temp=head;
 
 /*while(temp!=NULL)
 {
  printf("%d",temp->data);
  temp=temp->next;
 }
 printf("\n");*/
 
 return cnt; 
 
}

void DeleteEvenParity(PPNODE first,PPNODE last)
{
 if((*first)==NULL)
 {
  return;
 }
 PNODE temp=(*first),temp1=NULL,tempprev=NULL;
 int no=0;
 
 do             //circular linked list
 {
  no=0;
  no=CreateOne(temp->data);
  
  if((no%2)==0)
  {
   if(temp==(*first) && temp->next==(*last)) //ekach node
   {
    printf("if\n");
    free (*last);
    (*first)=NULL;
    (*last)=NULL;
   }
   else if(temp==(*first))      //required jar head asel tar
   {
    printf("else if\n");
    temp1=temp;
    (*first)=temp->next;
    temp=temp->next;            //this statement brings temp to head
    free (temp1);
    (*last)->next=(*first);
   }      
   else
   {
    printf("else\n");
    temp1=temp;
    tempprev->next=temp->next;
    temp=temp->next;
    free (temp1);
   }

  }
  else
  {
   tempprev=temp;
   temp=temp->next;
  }
  
 }while(temp!=(*first));     //mhnje tail cha next jopryant yet nahi    //circular aslyamule gadabad
 
 
  



}


int main()
{
 PNODE head=NULL;
 PNODE tail=NULL;
 
 InsertLast(&head,&tail,9);
 InsertLast(&head,&tail,11);
 InsertLast(&head,&tail,34);
 InsertLast(&head,&tail,6);
 InsertLast(&head,&tail,13);
 InsertLast(&head,&tail,21);
 
 printf("before deleting nodes:\n");
 Display(head,tail);
 
 DeleteEvenParity(&head,&tail);
 
 printf("after deleting even parity nodes:\n");
 
 Display(head,tail);

 
 return 0;
}
