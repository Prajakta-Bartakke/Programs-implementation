#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
  int data;
  struct node*next;
}NODE,*PNODE,**PPNODE;

void Insertlast(PPNODE first,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
 
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:linked list empty");
  return;
 }
 else 
 {
  while(first!=NULL)
  {
   printf("%d\t",first->data);
   first=first->next;
  }
  printf("\n");
 }
}

int Count(PNODE first)
{
 int cnt=0;
 
 if(first==NULL)
 {
  return -1;
 }
 else
 {
  while(first!=NULL)
  {
   cnt++;
   first=first->next;
  }
 }
 return cnt;
}


void DeleteNode(PPNODE first,int k)
{
 if((*first)==NULL)
 {
  return;
 }
 int cnt=0,i=0;
 cnt=Count(*first);
 
 if(k>cnt || k==0)             //total nodes jar 2 astil ani k jar 3 asel tar 3rd node dlt karan not possible
 {
  return;
 }
 
 PNODE temp=(*first);
 PNODE temp1=NULL;
 
 if(k<0)
 {
  k=-k;
  if(k>cnt)
  {
   return;
  }
 }
   
 while(temp!=NULL)
 {
  
  if(k==1)
  {
  temp1=temp;
  
  (*first)=temp->next;
  
  temp=(*first);
  
  free (temp1);
  }
 else              //head modify hoto
 {
  for(i=1;i<=k-2  &&  temp->next!=NULL;i++)
  {
   temp=temp->next;
  }
  
  temp1=temp->next;     //temp1=NULL
  
  if(temp1!=NULL)
  { 
  temp->next=temp1->next;
 
  free (temp1);
  }
  if(temp1==NULL)
  {
   temp=NULL;
  }
  else
  { 
  temp=temp->next;
  } 
 }
}


}

int main()
{
 PNODE head=NULL;
 int k=0;
 
 Insertlast(&head,1);
 Insertlast(&head,2);
 Insertlast(&head,3);
 Insertlast(&head,4);
 Insertlast(&head,5);
 Insertlast(&head,6);
 Insertlast(&head,7);
 Insertlast(&head,8);

 printf("before deleting node:\n");
 Display(head);
 
 printf("enter which number node you want to delete\n");
 scanf("%d",&k);
 
 DeleteNode(&head,k);
 
 printf("after deleting node:\n");
 Display(head);
 
 return 0;
}


