#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
  int data;
  struct node*next;
}NODE,*PNODE,**PPNODE;

void Insertlast(PPNODE first,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
 
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:linked list empty");
  return;
 }
 else 
 {
  while(first!=NULL)
  {
   printf("%d\t",first->data);
   first=first->next;
  }
  printf("\n");
 }
}

int Count(PNODE first)
{
 int cnt=0;
 
 if(first==NULL)
 {
  return -1;
 }
 else
 {
  while(first!=NULL)
  {
   cnt++;
   first=first->next;
  }
 }
 return cnt;
}

void Intersection(PPNODE first,PPNODE second,PPNODE Third)
{
 if((*first)==NULL || (*second)==NULL)
 {
  return;
 }
 PNODE temp1=(*first);
 PNODE temp2=(*second);
 PNODE temp3=(*Third);
 
 int cnt1=Count(*first),cnt2=Count(*second),i=1,j=1;
 
 for(i=1;i<=cnt1;i++)
 {
  temp2=(*second);
  for(j=1;j<=cnt2;j++)
  {
   if(temp1->data==temp2->data)
   {
    PNODE newn=(PNODE)malloc(sizeof(NODE));
    newn->next=NULL;
    
    if((*Third)==NULL)
    {
     (*Third)=newn;
     newn->data=temp1->data;
    }
    else
    {
     temp3=(*Third);
     
     while(temp3->next!=NULL)
     {
      temp3=temp3->next;
     }
     temp3->next=newn;
     temp3->next->data=temp1->data;
    }
   }
   temp2=temp2->next;
  }
  
  temp1=temp1->next;
  
 }
}

void Union(PPNODE first,PPNODE second,PPNODE third)   //no duplicates allowed and list should br sorted 
{
 if((*first)==NULL || (*second)==NULL)
 {
  return;
 }
 
 int cnt1=Count((*first));
 int cnt2=Count((*second));
 int i=0;
 
 PNODE temp1=(*first),temp2=(*second),temp3=NULL;
 PNODE newn1=NULL;
 PNODE newn2=NULL;
 newn1->next=NULL;
 newn2->next=NULL;
 
 if(cnt1>cnt2)
 {
  for(i=1;i<cnt2;i++)
  {
   if((*third)==NULL)
   {
    newn1=(PNODE)malloc(sizeof(NODE));
    (*third)=newn1;
    newn1->data=temp1->data;
    
    if(temp2->data!=temp1->data)
    {
     newn2=(PNODE)malloc(sizeof(NODE));
     (*third)->next=newn2;
     newn2->data=temp2->data;
    }
   }
   
   temp1=temp1->next;
   temp2=temp2->next;
   
   temp3=(*third);
   
   while(temp3->next!=NULL)
   {
    newn1=(PNODE)malloc(sizeof(NODE));
    temp3->next=newn1;
    temp2->data=temp1->data;
    
    if(temp1->data!=temp2->data)
    {
     newn2=(PNODE)malloc(sizeof(NODE));
     temp3->next->next=newn2;
     temp3->data=temp1->data;
    }
   } 
  }
  temp3=(*third);
  for(;i<=cnt1;i++)
  {
   while(temp3->next!=NULL)
   {
    temp3=temp3->next;
   }
   newn1=(PNODE)malloc(sizeof(NODE));
   newn2=(PNODE)malloc(sizeof(NODE));
   
   temp3->next=newn1;
   temp3->next->next=newn2;
  }
     
  }
 
 else if(cnt2>cnt1)
 {
 
 }
 
}
int main()
{
 PNODE head1=NULL;
 PNODE head2=NULL;
 PNODE head3=NULL;
 PNODE head4=NULL;
 
 int k=0;
 
 Insertlast(&head1,10);
 Insertlast(&head1,15);
 Insertlast(&head1,4);
 Insertlast(&head1,20);
 Insertlast(&head1,11);
 Insertlast(&head1,51);
 
 printf("first list\n");
 Display(head1);
 
 Insertlast(&head2,8);
 Insertlast(&head2,4);
 Insertlast(&head2,2);
 Insertlast(&head2,10);

 printf("second list\n");
 Display(head2);
 
 Intersection(&head1,&head2,&head3);
 printf("intersection list is:\n");
 Display(head3);
 
 Union(&head1,&head2,&head4);
 printf("union list is:\n");
 Display(head3);
 
 return 0;
}


