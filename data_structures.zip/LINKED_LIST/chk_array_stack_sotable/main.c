#include<stdio.h>
#include<stdlib.h>
typedef int BOOL;
#define TRUE 1
#define FALSE 0
#define INVALID -1

typedef struct node
{
 int data;
 struct node *next;
}NODE,*PNODE;


BOOL ChkSorted(int *arr,int size)
{
 if(arr==NULL)
 {
  return INVALID;
 }
 int *brr=NULL;
 int i=0,j=0,cnt=0;
 PNODE head=NULL;
 BOOL flag=FALSE;
 
 for(i=0;i<size;i++)
 {
  PNODE newn=(PNODE)malloc(sizeof(NODE));
  newn->data=arr[i];
  newn->next=NULL;
  
  if(head==NULL)
  {
   head=newn;
  }
  else
  {
   newn->next=head;
   head=newn;
  }  
 }
 PNODE temp=head;
 
 while(temp!=NULL)
 {
  brr=realloc(brr,cnt);
  brr[j]=temp->data;
  temp=temp->next;
  cnt++;
  j++;
 }
 
 for(i=0;i<j-1;i++)
 {
  if(brr[i]>brr[i+1])
  {
   flag=TRUE;
   break;
  }
 }
 
 PNODE temp1=head;
 
 while(head!=NULL)
 {
  temp1=head;
  head=head->next;
  free (temp1);
 }

 
 if(flag==TRUE)
 {
  return FALSE;
 }
 else
 {
  return TRUE;
 }
  
 
}


int main()
{
 BOOL bret=FALSE;
 int size=0;
 
 printf("enter size:\n");
 scanf("%d",&size);
 
 int *arr=(int*)malloc(sizeof(int));
 
 printf("enter elements:\n");
 
 for(int i=0;i<size;i++)
 {
  scanf("%d",&arr[i]);
 }
 
 bret=ChkSorted(arr,size);
 
 if(bret==TRUE)
 {
  printf("YES\n");
 }
 else if(bret==INVALID)
 {
  printf("Error:invalid input\n");
 }
 else
 {
  printf("NO\n");
 }
  
 return 0;
}
