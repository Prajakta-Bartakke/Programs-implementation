#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
 int data;
 struct node *next;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
}

void Display(PNODE first)
{
 if(first==NULL)
 {
  return;
 }
 while(first!=NULL)
 {
  printf("%d\t",first->data);
  first=first->next;
 }
 printf("\n");
}

void DeleteNodes(PPNODE first)
{
 if((*first)==NULL  ||   (*first)->next==NULL)   //linked list empty kiva ekach node asel tar right la kahi nasel so return
 {
  return;
 }
 PNODE temp=(*first);
 PNODE tempprev=NULL;
 PNODE temp1=NULL;
 while(temp->next!=NULL)
 {
  if(temp==(*first) && temp->next->data>temp->data)
  {
   temp1=temp;
   (*first)=temp->next;
   free (temp1);
   temp=(*first);
   tempprev=temp;		//mhnje jar node pahili dlt zali tar parat pahilyapasun start
  }
  else if(temp->next->data>temp->data)   //temp=200 tempprev=200
   {
    temp1=temp;
    tempprev->next=temp->next;
    free (temp1);
    temp=tempprev=tempprev->next;
    
   }
  
  else
  {
   if(temp->next->data<temp->data)
   {
    tempprev=temp;
   }
   temp=temp->next;
  }

 }
}
int main()
{
 PNODE head=NULL;
 
 InsertLast(&head,12);
 InsertLast(&head,15);
 InsertLast(&head,10);
 InsertLast(&head,11);
 InsertLast(&head,5);
 InsertLast(&head,6);
 InsertLast(&head,2);
 InsertLast(&head,3);
 
 /*InsertLast(&head,12);
 InsertLast(&head,15);
 InsertLast(&head,16);
 InsertLast(&head,11);
 InsertLast(&head,15);
 InsertLast(&head,14);
 InsertLast(&head,2);
 InsertLast(&head,3);*/
 
 
 
 printf("before deleting the nodes:\n");
 Display(head);
 DeleteNodes(&head);
 printf("after deleting nodes:\n");
 Display(head);

 return 0;
}
