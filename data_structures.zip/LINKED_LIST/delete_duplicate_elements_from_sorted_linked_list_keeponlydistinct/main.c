#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node*next;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,PPNODE last,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL && (*last)==NULL)
 {
  (*first)=newn;
  (*last)=newn;
 } 
 else 
 {
  (*last)->next=newn;
  (*last)=newn;
 }
}

void Display(PNODE head)
{
 if(head==NULL)
 {
  printf("Error:linked list empty\n");
  return;
 }
 while(head!=NULL)
 {
  printf("%d\n",head->data);
  head=head->next;
 }

}

PNODE copycontents(PNODE first)
{
 if(first==NULL)
 {
  return NULL;
 }
 PNODE head=NULL;
 PNODE newn=NULL;
 while(first!=NULL)
 {
  newn=(PNODE)malloc(sizeof(NODE));
  newn->next=NULL;
  if(head==NULL)
  {
   head=newn;
   head->data=first->data;
  }
  else    
  {
   PNODE temp=head;
   while(temp->next!=NULL)
   {
    temp=temp->next;
   }
   temp->next=newn;
   newn->data=first->data;
  }
  
 first=first->next;
 }
 return head;
}

int count(PNODE first)
{
 if(first==NULL)
 {
  return -1;
 }
 int cnt=0;
 
 while(first!=NULL)
 {
  cnt++;
  first=first->next;
 }
 return cnt;
}

int countfreq(PNODE head,int no)
{
 if(head==NULL)
 {
  return -1;
 }
 int cnt=0;
 
 while(head!=NULL)
 {
  if(head->data==no)
  {
   cnt++;
  }
  head=head->next;
 }
 return cnt;
}

PNODE deleteDuplicates(PNODE first)    //darwelli head nhi pathvaycha nvin address pathvayvha,to count ani total number of nodes same astil tar break.. 
{
 if(first==NULL)
 {
  return NULL;
 }
 
 PNODE newll=NULL;
 newll=copycontents(first);       //whole linked list copied
 int cnt=count(first);
 
 PNODE temp=newll;
 PNODE tempprev=NULL,dlt=NULL;
 int no=0,i=0;
 
 while(temp!=NULL)
 {
  
  no=countfreq(newll,temp->data);
  
  if(no>1)    //loop laun delete
  {
   //jar asa element asel ki jo head wala asle 
   if(temp==newll)
   {
    //if(no==cnt)     //sagle elements duplicate
    //{
     for(i=0;i<no;i++)
     {
      dlt=temp;
      temp=temp->next;
      free (dlt);
     }
     if(temp==NULL)
     {
      newll=NULL;
      break;
     }
     else
     {
      newll=temp;
     }
     
     //newll=NULL;
     //break;
    //}
    //else            //kahi elements from head dupliacte ahe..not equal to the total elements
    //{
     //consider for case 11 11 11 4 4 4 tya no paryant loop firvun delete karun head la initialize kara..ithe break karana wriong ae  
     
     
     
    //}
   
   }
   
   else
   {
   for(i=0;i<no;i++)
   {
    dlt=temp;
    tempprev->next=temp->next;
    temp=temp->next;
    free (dlt);
   }
  }
  }
  else
  {
  tempprev=temp;
  temp=temp->next;
  }
 }
 return newll;
}

int main()
{
 PNODE head=NULL;
 PNODE tail=NULL;
 
 /*InsertLast(&head,&tail,1);
 InsertLast(&head,&tail,2);
 InsertLast(&head,&tail,3);
 InsertLast(&head,&tail,3);
 InsertLast(&head,&tail,4);
 InsertLast(&head,&tail,4);
 InsertLast(&head,&tail,5);*/
 
 /*InsertLast(&head,&tail,11);
 InsertLast(&head,&tail,11);
 InsertLast(&head,&tail,11);
 InsertLast(&head,&tail,11);
 InsertLast(&head,&tail,4);
 InsertLast(&head,&tail,4);
 InsertLast(&head,&tail,5);
 InsertLast(&head,&tail,7);
 InsertLast(&head,&tail,7);
 InsertLast(&head,&tail,9);*/
 
 InsertLast(&head,&tail,1);
 InsertLast(&head,&tail,1);
 InsertLast(&head,&tail,1);
 InsertLast(&head,&tail,2);
 InsertLast(&head,&tail,3);
 
 /*Display(head);*/
 
 PNODE head1=deleteDuplicates(head);
 Display(head1);
 return 0;
}
