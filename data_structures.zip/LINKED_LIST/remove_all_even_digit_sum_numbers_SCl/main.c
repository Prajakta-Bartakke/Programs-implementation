#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node *next;
}NODE,*PNODE,**PPNODE;

void Insert(PPNODE first,PPNODE second,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL && (*second)==NULL)
 {
  (*first)=newn;
  (*second)=newn;
 }
 else if((*first)->next==NULL)
 {
  (*first)->next=newn;
  (*second)=newn;
 }
 else
 {
  (*second)->next=newn;
  (*second)=newn;
 }
 (*second)->next=(*first);

}
void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:invalid input\n");
  return;
 }
 else
 {
  PNODE temp=first;
  do
  {
   printf("%d\t",first->data);
   first=first->next;
  }while(first!=temp);
  printf("\n"); 
 }

}

void Delete(PPNODE first,PPNODE last)
{
 if((*first)==NULL)
 {
  return;
 }
 PNODE temp=(*first),temp1=NULL,tempprev=NULL;
 int sum=0,no=0;
 
 do
 {
  sum=0,no=temp->data;
  
  while(no!=0)
  {
   sum=sum+(no%10);
   no=no/10;
  }
  
  if((sum%2)==0)
  {
   if(temp==(*first) && temp->next==(*last))         //one node present
   {
    free (*last);
    (*last)=NULL;
    (*first)=NULL;
   }
   else if(temp==(*first) && temp->next->next==(*first))  //2 node astil tar tail pan update karavi lagel
   {
    temp1=temp;
    (*first)=temp->next;
    (*last)=(*first);
    temp=temp->next;
    free (temp1);
   }
   else               //madhli konti tari node
   {
    printf("inside else\n");
    temp1=temp;
    tempprev->next=temp->next;
    temp=temp->next;
    free (temp1);
    
   }
  }  //end of sum chi condition
  else
  {
   tempprev=temp;
   temp=temp->next;
  }
 
 }while(temp!=(*first));

}

int Count(PNODE first,PNODE last)
{
 if((first)==NULL)
 {
  return -1;
 }
 int cnt=0;
 
 do
 {
  cnt++;
  first=first->next;
 }while(first!=last->next); 
 

}

void DeleteNodes(PPNODE first,PPNODE last)
{
 int cnt=Count((*first),(*last));
 if(*first==NULL  ||  cnt==-1)
 {
  return;
 }
 PNODE temp=(*first);
 for(int i=0;i<cnt;i++)
 {
  temp=(*first);
  (*first)=(*first)->next;
  free (temp);
 }

}
int main()
{
 PNODE head=NULL;
 PNODE tail=NULL;
 
 /*Insert(&head,&tail,9);
 Insert(&head,&tail,11);
 Insert(&head,&tail,34);
 Insert(&head,&tail,6);
 Insert(&head,&tail,13);
 Insert(&head,&tail,21);*/
 
 Insert(&head,&tail,5);
 Insert(&head,&tail,11);
 Insert(&head,&tail,16);
 Insert(&head,&tail,21);
 Insert(&head,&tail,17);
 Insert(&head,&tail,10);
 
 
 printf("before deleting elements:\n");
 Display(head);
 
 Delete(&head,&tail);
 printf("after deleting elements:\n");
 Display(head);
  
 DeleteNodes(&head,&tail);
 printf("address of head is :%p\n",head);
 return 0;
}


