#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
 int data;
 struct node *next;
}NODE,*PNODE,**PPNODE;

void InsertLast(PPNODE first,int no)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=no;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }

}

void Display(PNODE first)
{
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
}

void RemoveDuplicate(PPNODE first)
{
 if((*first)==NULL)
 {
  printf("Error:linked list already empty\n");
  return;
 }
 else
 {
  PNODE temp=*first;
  
  while(temp->next!=NULL)
  {
   if(temp->data==temp->next->data)
   {
    if(temp==(*first))
    {
     (*first)=temp->next;
     free (temp);
     temp=(*first);
    }
   
    
    else if(temp!=(*first))
    {
     PNODE temp1=temp->next;
     temp->next=temp->next->next;
     temp=temp->next;
     free (temp1);
    }
    }
    
    else
    {
     temp=temp->next;
    }
    
   }
  // temp=temp->next;
  }
 }
 



int main()
{
 PNODE head=NULL;
 
 InsertLast(&head,11);
 InsertLast(&head,11);
 InsertLast(&head,11);
 InsertLast(&head,21);
 InsertLast(&head,43);
 InsertLast(&head,43);
 InsertLast(&head,60);
 InsertLast(&head,60);
 InsertLast(&head,60);
 printf("before removing duplicates:\n");
 Display(head);
 
 
 RemoveDuplicate(&head);
 
 printf("after removing duplicates:\n");
 Display(head);

 return 0;
}
