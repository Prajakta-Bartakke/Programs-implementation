/*

problem statement:return the sum of all elements in linked list

*/

#include<stdio.h>
#include<stdlib.h>
#define EMPTY -1

typedef struct Node
{ 
 int data;
 struct Node *next;
}NODE,*PNODE,**PPNODE;

////////////////////////////////////////////////////
//
//Function name:	InsertLast
//input:		pointer cha address ani integer
//return val:		none
//description:		used to insert node at last pos
//
////////////////////////////////////////////////////


void InsertLast(PPNODE first,int iNo)
{
 if(first==NULL)
 {
  return;
 }
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 PNODE temp=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  temp=(*first);
  while(temp->next!=NULL)
  {
   temp=temp->next;
  }
  temp->next=newn;
 }
}

////////////////////////////////////////////////////
//
//Function name:	Addition
//input:		pointer 
//return val:		int
//description:		used to return sum of all elemnts
//
////////////////////////////////////////////////////

int Addition(PNODE first)
{
 if(first==NULL)
 {
  return EMPTY;
 }
 int iSum=0;
 
 while(first!=NULL)
 {
  iSum=iSum+(first->data);
  first=first->next;
 }
 
 return iSum;
}

void Display(PNODE first)
{
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
}



int main()
{
 PNODE head=NULL;
 int iSum=0;
 iSum=Addition(head);
 InsertLast(&head,10);
 InsertLast(&head,20);
 InsertLast(&head,30);
 InsertLast(&head,40);
 Display(head);
 
 //iSum=Addition(head);
 
 if(iSum==EMPTY)
 {
  printf("Error:Linked List empty\n");
 }
 
 else
 {
 printf("sum of all elements : %d\n",iSum);
 }
 
 
 return 0;
}
