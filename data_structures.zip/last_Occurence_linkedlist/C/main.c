/*

problem statement:accept number from user and return its last occurence

*/

#include<stdio.h>
#include<stdlib.h>
#define EMPTY -1

typedef struct Node
{
 int data;
 struct Node*next;
}NODE,*PNODE,**PPNODE;

/////////////////////////////////////////////////////////////
//
//Function name:	InsertFirst
//input value:		pointer cha address and integer
//return value:	none
//description:		used to insert element at first position of linked list
//
////////////////////////////////////////////////////////////

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}

/////////////////////////////////////////////////////////////
//
//Function name:	Display
//input value:		pointer 
//return value:	none
//description:		used to display elements of linked list
//
////////////////////////////////////////////////////////////


void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:Linked List is empty\n");
  return;
 }
 while(first!=NULL)
 {
  printf("|%d|->",first->data);
  first=first->next;
 }
}
 
/////////////////////////////////////////////////////////////
//
//Function name:	SearchLastOcc
//input value:		pointer and integer
//return value:	int
//description:		used to return last occurence of number
//
////////////////////////////////////////////////////////////

int SearchLastOcc(PNODE first,int iNo)
{
 if(first==NULL)
 {
  return EMPTY;
 }
 int iLast=0,iCnt=0;
 while(first!=NULL)
 {
  iCnt++;
  if(first->data==iNo)
  {
   iLast=iCnt;
  }
  first=first->next;
 }
 return iLast;
}
  
int main()
{
 PNODE head=NULL;
 int iNo=0;
 int iRet=0;
 
 InsertFirst(&head,30);
 InsertFirst(&head,50);
 InsertFirst(&head,30);
 InsertFirst(&head,40);
 InsertFirst(&head,30);
 InsertFirst(&head,20);
 InsertFirst(&head,10);
 
 Display(head);
 printf("\n");
 printf("enter number whose last occurence is to find:\n");
 scanf("%d",&iNo);
 
 iRet=SearchLastOcc(head,iNo);
 
 if(iRet==0)
 {
  printf("element not present\n");
 }
 else if(iRet==EMPTY)
 {
  printf("Error:linked list is empty\n");
 }
 else
 {
  printf("last occurence of element is:%d\n",iRet);
 }
 
 
 return 0;
}
