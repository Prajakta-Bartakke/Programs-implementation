/*

problem statement: display perfect numbers 

*/
#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
 int data;
 struct Node*next;
}NODE,*PNODE,**PPNODE;

/////////////////////////////////////////
//
//Function name:	InsertFirst
//input parameter:	pointer cha address and integer
//return value:	none
//description:		used to add node at first position
//
///////////////////////////////////////////

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}


/////////////////////////////////////////
//
//Function name:	DisplayPerfect......atmanirbhar
//input parameter:	pointer 
//return value:	none
//description:		used to display perfect number from linked list
//
///////////////////////////////////////////

/*


perfect number:   jya number cha factors chi sum tya number itki yete tyala perfect mhntat


example:	6   ->  1+2+3


*/


void DisplayPerfect(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:Linked list empty!!\n");
  return;
 }
 
 int i=0,iSum=0;
 
 while(first!=NULL)
 {
  for(i=1;i<=((first->data)/2);i++)
  {
   if(((first->data)%i)==0)
   {
    iSum=iSum+i;
   }
  }
  
  if(iSum==(first->data))
  {
   printf("%d\t",(first->data));
  }
  iSum=0;
  first=first->next;
 }
}
   

void Display(PNODE first)
{
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
}

int main()
{
 PNODE Head=NULL;
 int iNo=0;
 int iRet=0;
 
 InsertFirst(&Head,89);
 InsertFirst(&Head,6);
 InsertFirst(&Head,41);
 InsertFirst(&Head,17);
 InsertFirst(&Head,28);
 InsertFirst(&Head,11);
 
 
 printf("content of linked list are:\n");
 Display(Head);
 
 //printf("\n");
 
 printf("perferct numbers from list are:\n");
 DisplayPerfect(Head);
 
 printf("\n");			
 
 
 
 
 return 0;
}

















