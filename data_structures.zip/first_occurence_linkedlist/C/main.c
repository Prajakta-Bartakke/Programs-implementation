/*

problem statement: accept number from user and return the first occurence of that number

*/
#include<stdio.h>
#include<stdlib.h>
#define ABSENT -1
#define ABSELE -2

typedef struct Node
{
 int data;
 struct Node*next;
}NODE,*PNODE,**PPNODE;

/////////////////////////////////////////
//
//Function name:	InsertFirst
//input parameter:	pointer cha address and integer
//return value:	none
//description:		used to add node at first position
//
///////////////////////////////////////////

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}


/////////////////////////////////////////
//
//Function name:	SearchFirstOcc
//input parameter:	pointer and integer
//return value:	int
//description:		used to find first occurenc of the data
//
///////////////////////////////////////////

int SearchFirstOcc(PNODE first,int iNo)
{
 if(first==NULL)
 {
  return ABSENT;
 }
 int iCnt=0;
 
 while(first!=NULL)
 { 
  iCnt++;
  if(first->data==iNo)
  {
   break;
  }
  first=first->next;
 }
 if((first!=NULL))
 {
  return iCnt;
 }
 else if(first==NULL)
 {
  return ABSELE;
 }
}

void Display(PNODE first)
{
 while(first!=NULL)
 {
  first=first->next;
 }
}

int main()
{
 PNODE Head=NULL;
 int iNo=0;
 int iRet=0;
 
 InsertFirst(&Head,70);
 InsertFirst(&Head,30);
 InsertFirst(&Head,50);
 InsertFirst(&Head,40);
 InsertFirst(&Head,30);
 InsertFirst(&Head,20);
 InsertFirst(&Head,10);
 
 Display(Head);
 
 printf("enter Number whose first occurenece is to find:\n");
 scanf("%d",&iNo);
 
 iRet=SearchFirstOcc(Head,iNo);
 
 if(iRet==ABSENT)
 {
  printf("Error:linked list empty\n");
 }
 else if(iRet==ABSELE)
 {
  printf("Error:element not present\n");
 }
 else
 {
 printf("first occurence of %d is %d\n",iNo,iRet);
 }
 return 0;
}

















