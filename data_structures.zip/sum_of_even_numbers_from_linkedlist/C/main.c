/*

problem statement: return the addition of even numbers from linked list

*/
#include<stdio.h>
#include<stdlib.h>
#define EMPTY -1

typedef struct node 
{
 int data;
 struct node* next;
}NODE,*PNODE,**PPNODE;

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}

void Display(PNODE first)
{
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
}
 
int AddEven(PNODE first)
{
 int iSum=0;
 
 if(first==NULL)
 {
  return EMPTY;
 }
 
 while(first!=NULL)
 {
  if((first->data)%2==0)
  {
   iSum=iSum+(first->data);
  }
  first=first->next;
 }
 return iSum;
}

int main()
{

 PNODE Head=NULL;
 int iSum=0;
 
 InsertFirst(&Head,41);
 InsertFirst(&Head,32);
 InsertFirst(&Head,20);
 InsertFirst(&Head,11);
 
 printf("the contents of linked list are:\n");
 Display(Head);
 
 iSum=AddEven(Head);
 
 if(iSum==EMPTY)
 {
  printf("Error:linked list is empty\n");
 }
 else
 {
  printf("sum of even numbers is:%d\n",iSum);
 }

 return 0;
}
