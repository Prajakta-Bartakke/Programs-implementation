/*
problem statemnt: return the largest element from the linked list
*/

#include<stdio.h>
#include<stdlib.h>
#define EMPTY -2

typedef struct Node
{
 int data;
 struct Node*next;
}NODE,*PNODE,**PPNODE;

/////////////////////////////////////////
//
//Function name:	InsertFirst
//input parameter:	pointer cha address and integer
//return value:	none
//description:		used to add node at first position
//
///////////////////////////////////////////

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}

/////////////////////////////////////////
//
//Function name:	Largest
//input parameter:	pointer
//return value:	integer
//description:		used to return the largest elemnt from linked list
//
///////////////////////////////////////////

int Largest(PNODE first)
{
 int iMax=0;
 
 if(first==NULL)
 {
  return EMPTY;
 }

 iMax=(first->data);
 
 while(first!=NULL)
 {
  if((first->data)>iMax)
  {
   iMax=(first->data);
  }
  first=first->next;
 }
 return iMax;

}

////////////////////////////////////////////////////
//
//function name:	Display
//input:		pointer
//return:		none
//description:		used to display the contents
//
///////////////////////////////////////////////////

void Display(PNODE first)
{
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
 }





int main()
{
 PNODE Head=NULL;
 int iNo=0;
 int iRet=0;
 
 InsertFirst(&Head,70);
 InsertFirst(&Head,30);
 InsertFirst(&Head,50);
 InsertFirst(&Head,40);
 InsertFirst(&Head,30);
 InsertFirst(&Head,20);
 InsertFirst(&Head,10);
 
 Display(Head);
 
 iRet=Largest(Head);
 
 if(iRet==EMPTY)
 {
  printf("Error:linked list is empty\n");
 }
 else
 {
  printf("largest element is:%d\n",iRet);
 }
 

 return 0;
}





























