
#include<stdio.h>
#include<stdlib.h>

typedef int BOOL;
#define TRUE 1
#define FALSE 0
#define EMPTY -1

typedef struct node
{
 int data;
 struct node *next;
}NODE,*PNODE,**PPNODE;

/////////////////////////////////////////////////
//
//function name:	InsertFirst
//input:		head cha address and integer
//return value:	none
//description:		used to insert element in singly circular ll at first position
//author:		Prajakta Aditya Bartakke
//date:		12 sep 2020
//
//////////////////////////////////////////////////

void InsertFirst(PPNODE first,int iNo)      
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 PNODE temp1=(*first);
 
 if((*first)==NULL)
 {
  (*first)=newn;
  newn->next=(*first);
 }
 
 else
 {
  newn->next=(*first);
  (*first)=newn;
  
  PNODE temp=(*first)->next;
  
  while(temp->next!=temp1)
  {
   temp=temp->next;
  }
  temp->next=newn;
  
 }
}

/////////////////////////////////////////////////
//
//function name:	InsertLast
//input:		head cha address and integer
//return value:	none
//description:		used to insert element in singly circular ll at last position
//author:		Prajakta Aditya Bartakke
//date:		12 sep 2020
//
//////////////////////////////////////////////////

void InsertLast(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
  newn->next=(*first);
 }
 
 else
 {
  PNODE temp=(*first);
  
  while(temp->next!=(*first))
  {
   temp=temp->next;
  }
  temp->next=newn;
  newn->next=(*first);
  }
}

/////////////////////////////////////////////////
//
//function name:	DeleteFirst
//input:		head cha address
//return value:	none
//description:		used to delete element in singly circular ll at first position
//author:		Prajakta Aditya Bartakke
//date:		12 sep 2020
//
//////////////////////////////////////////////////

void DeleteFirst(PPNODE first)
{
 if((*first)==NULL)
 {
  return;
 }
 
 if((*first)->next==(*first))
 {
  free (*first);
  (*first)=NULL;
 }
 
 else
 {
  PNODE temp=(*first)->next;
  
  PNODE temp1=(*first);PNODE temp2=(*first);
  
  while(temp1->next!=(*first))
  {
   temp1=temp1->next;
   
  }
  
  temp1->next=temp;
  
  (*first)=(*first)->next;
  
  free (temp2);
 }
 
}

/////////////////////////////////////////////////
//
//function name:	DeleteLast
//input:		head cha address
//return value:	none
//description:		used to delete element in singly circular ll at last position
//author:		Prajakta Aditya Bartakke
//date:		12 sep 2020
//
//////////////////////////////////////////////////

void DeleteLast(PPNODE first)
{
 if((*first)==NULL)
 {
  return;
 }
 
 if((*first)->next==(*first))
 {
  free (*first);
  (*first)=NULL;
 }
 
 else
 {
  PNODE temp=(*first);
  
  while(temp->next->next!=(*first))
  {
   temp=temp->next;
  } 
  
  PNODE temp1=temp->next;
  
  temp->next=(*first);
  
  free (temp1);
 
 }

} 

/////////////////////////////////////////////////
//
//function name:	Display
//input:		head 
//return value:	none
//description:		used to display elements in SLL
//author:		Prajakta Aditya Bartakke
//date:		12 sep 2020
//
//////////////////////////////////////////////////

 
void Display(PNODE first)
{
 if(first==NULL)
 {
  printf("Error:Trying to display elements from empty linked list\n");
  return;
 }
 else
 {
  PNODE temp=first;
  do
  {
   //printf("while in display\n");
   printf("%d\n",temp->data);
   temp=temp->next;
   if(temp==NULL)                                      //display singly linear
   {
    break;
   }
  }while(temp!=first);
 }
 
} 

/////////////////////////////////////////////////
//
//function name:	Count
//input:		head 
//return value:	int
//description:		used to count elements in SLL
//author:		Prajakta Aditya Bartakke
//date:		12 sep 2020
//
//////////////////////////////////////////////////

 
int Count(PNODE first)
{
 int iCnt=0;
 
 if(first==NULL)
 {
  printf("Error:Trying to count elements from empty linked list\n");
  return EMPTY;
 }
 else
 {
  PNODE temp=first;
  do
  {
   //printf("while in display\n");
   //printf("%d\n",temp->data);
   iCnt++;
   temp=temp->next;
   /*if(temp==NULL)                                      //display singly linear
   {
    break;
   }*/
  }while(temp!=first);
 }
 return iCnt; 
} 


/////////////////////////////////////////////////
//
//function name:	ChkCircular
//input:		head 
//return value:	boolean
//description:		used to check linked list is circular or not
//author:		Prajakta Aditya Bartakke
//date:		12 sep 2020
//
//////////////////////////////////////////////////


BOOL ChkCircular(PNODE head)
{
 if(head==NULL)
 {
  return EMPTY;
 }
 else 
 {
  PNODE temp=head;
  
  while(1)
  {
   temp=temp->next;
   
   if(temp==head)
   {
    break;
   }
   
   else if(temp==NULL)
   {
    break;
   }
  }
  
  if(temp==head)
  {
   return TRUE;
  }
  
  else
  {
   return FALSE;
  }
 }
 }
   
/*void InsertFirstN(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 PNODE temp1=(*first);
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}*/

/////////////////////////////////////////////////
//
//function name:	InsertAtPos
//input:		head cha address and integer and position number
//return value:	none
//description:		used to insert element in singly circular ll at any position
//author:		Prajakta Aditya Bartakke
//date:		12 sep 2020
//
//////////////////////////////////////////////////

void InsertAtPos(PPNODE first,int iPos,int iNo)
{
 int iSize=Count((*first));
 
 if(iPos<1 || iPos>iSize+1)
 {
  return;
 }
 else if(iPos==1)
 {
  InsertFirst(first,iNo);
 }
 else if(iPos==iSize+1)
 {
  InsertLast(first,iNo);
 }
 else
 {
  PNODE newn=(PNODE)malloc(sizeof(NODE));
  newn->data=iNo;
  newn->next=NULL;
  
  int i=0;
  PNODE temp=(*first);
  
  for(i=1;i<iPos-1;i++)
  {
   temp=temp->next;
  }
  
  newn->next=temp->next;
  temp->next=newn;
 }
}
 
void DeleteAtPos(PPNODE first,int iPos)
{
 
 int iSize=Count((*first));
 if((*first)==NULL)
 {
  return;
 }
 
 else if(iPos<1 || iPos>iSize)
 {
  return;
 }
 
 else if(iPos==1)
 {
  DeleteFirst(first);
 }
 
 else if(iPos==iSize)
 {
  DeleteLast(first);
 }
 
 else
 {
  PNODE temp=(*first);
  
  int i=0;
  
  for(i=1;i<iPos-1;i++)
  {
   temp=temp->next;
  }
  PNODE temp1=temp->next;
  
  temp->next=temp1->next;
  
  free (temp1);
 }
}


int main()
{
 PNODE head=NULL;
 BOOL bRet=FALSE;
 
 InsertFirst(&head,11);
 InsertFirst(&head,21);
 InsertFirst(&head,51);
 InsertFirst(&head,101);
 InsertLast(&head,111);
 InsertLast(&head,151);
 InsertLast(&head,121);
 InsertAtPos(&head,3,12511);
 Display(head);
 
 bRet=ChkCircular(head);
 
 if(bRet==EMPTY)
 {
  printf("Error:Linked list is empty\n");
 }
 else if(bRet==TRUE)
 {
  printf("Linked list is circular\n");
 }
 else
 {
  printf("Linked list is not circular\n");
 }
 
 printf("---------------------------------------------\n");
 
 
 DeleteFirst(&head);
 Display(head);
 
 bRet=ChkCircular(head);
 
 if(bRet==EMPTY)
 {
  printf("Error:Linked list is empty\n");
 }
 else if(bRet==TRUE)
 {
  printf("Linked list is circular\n");
 }
 else
 {
  printf("Linked list is not circular\n");
 }
 
 printf("---------------------------------------------\n");
 
 
 DeleteLast(&head);
 Display(head);
 
 bRet=ChkCircular(head);
 
 if(bRet==EMPTY)
 {
  printf("Error:Linked list is empty\n");
 }
 else if(bRet==TRUE)
 {
  printf("Linked list is circular\n");
 }
 else
 {
  printf("Linked list is not circular\n");
 }
 
 printf("---------------------------------------------\n");
 
 
 DeleteAtPos(&head,3);
 
 Display(head);
 
 bRet=ChkCircular(head);
 
 if(bRet==EMPTY)
 {
  printf("Error:Linked list is empty\n");
 }
 else if(bRet==TRUE)
 {
  printf("Linked list is circular\n");
 }
 else
 {
  printf("Linked list is not circular\n");
 }
 

 
 printf("---------------------------------------------\n");
 
 
 
  
 
 return 0;
}
