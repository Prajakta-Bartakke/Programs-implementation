/*

problem statement: display prime numbers 

*/
#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
 int data;
 struct Node*next;
}NODE,*PNODE,**PPNODE;

/////////////////////////////////////////
//
//Function name:	InsertFirst
//input parameter:	pointer cha address and integer
//return value:	none
//description:		used to add node at first position
//
///////////////////////////////////////////

void InsertFirst(PPNODE first,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->next=NULL;
 
 if((*first)==NULL)
 {
  (*first)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)=newn;
 }
}


/////////////////////////////////////////
//
//Function name:	DisplayPrime......atmanirbhar
//input parameter:	pointer 
//return value:	none
//description:		used to display prime number from linked list
//
///////////////////////////////////////////

/*

prime number:  jya number la fakt 1 ne complete bhag jato

*/

void DisplayPrime(PNODE first)
{
 int iCnt=0;
 int i=2;
 
 while(first!=NULL)
 {
  for(i=2;i<=((first->data)/2);i++)
  {  
   if(((first->data)%i)==0)
   { 
    iCnt++;
   }
  }
  if(iCnt==0)
  {
   printf("%d\n",(first->data));
  }
  iCnt=0;
  
  first=first->next;
 }
}
 

void Display(PNODE first)
{
 while(first!=NULL)
 {
  printf("%d\n",first->data);
  first=first->next;
 }
}

int main()
{
 PNODE Head=NULL;
 int iNo=0;
 int iRet=0;
 
 InsertFirst(&Head,89);
 InsertFirst(&Head,6);
 InsertFirst(&Head,41);
 InsertFirst(&Head,17);
 InsertFirst(&Head,28);
 InsertFirst(&Head,11);
 
 
 printf("content of linked list are:\n");
 Display(Head);
 
 printf("prime numbers are:\n");
 DisplayPrime(Head);
 
 printf("\n");
 
 return 0;
}

















