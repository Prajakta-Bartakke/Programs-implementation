
#include<stdio.h>
#include<stdlib.h>

typedef int BOOL;
#define TRUE 1
#define FALSE 0
#define EMPTY -4
typedef struct node
{
 int data;
 struct node *next;
 struct node *prev;
}NODE,*PNODE,**PPNODE;

//////////////////////////////////////////////////////
//
//function name:	InsertFirst
//input:		head cha address , tail cha address ani integer
//return value:	none
//description:		used to insert node at first position
//author:		Prajakta Aditya Bartakke
//date :		12 sep 2020
//
////////////////////////////////////////////////////

void InsertFirst(PPNODE first,PPNODE last,int iNo)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->next=NULL;
 newn->data=iNo;
 newn->prev=NULL;
 
 if((*first)==NULL  &&  (*last)==NULL)
 {
  (*first)=newn;
  (*last)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)->prev=newn;
  
  (*first)=newn;
 }
 (*last)->next=(*first);
 (*first)->prev=(*last);
}

//////////////////////////////////////////////////////
//
//function name:	Display
//input:		head 
//return value:	BOOL
//description:		used to nodes in linked list
//author:		Prajakta Aditya Bartakke
//date :		12 sep 2020
//
////////////////////////////////////////////////////

BOOL Display(PNODE first)
{
 if(first==NULL)
 {
  return FALSE;
 }
 else
 {
  
  PNODE temp=first;
  
  do
  {
   printf("%d\t",temp->data);
   temp=temp->next;
  }while(temp!=first);
  printf("\n");
 return TRUE;
 }
 }

//////////////////////////////////////////////////////
//
//function name:	Count
//input:		head 
//return value:	int
//description:		used to count nodes in linked list
//author:		Prajakta Aditya Bartakke
//date :		13 sep 2020
//
////////////////////////////////////////////////////

int Count(PNODE first)
{
 if(first==NULL)
 {
  return EMPTY;
 }
 else
 {
  int iCnt=0;
  PNODE temp=first;
  
  do
  {
   temp=temp->next;
  }while(temp!=first);
 return iCnt;
 }
 }


//////////////////////////////////////////////////////
//
//function name:	DeleteFirst
//input:		head cha address , tail cha address
//return value:	BOOL
//description:		used to delete node at first position
//author:		Prajakta Aditya Bartakke
//date :		12 sep 2020
//
////////////////////////////////////////////////////

BOOL DeleteFirst(PPNODE first,PPNODE last)
{
 if((*first)==NULL && (*last)==NULL)
 {
  return FALSE;
 }
 else if((*first)==(*last))
 {
  free (*first);
  (*first)=NULL;
  (*last)=NULL;
  return TRUE;
 }
 else
 {
  (*first)=(*last)->next->next;
  
  (*first)->prev=(*last);
  
   free ((*last)->next);
   
   (*last)->next=(*first);
   
   return TRUE;
 }
}

//////////////////////////////////////////////////////
//
//function name:	DeleteLast
//input:		head cha address , tail cha address
//return value:	boolean
//description:		used to delete node at last position
//author:		Prajakta Aditya Bartakke
//date :		12 sep 2020
//
////////////////////////////////////////////////////

BOOL DeleteLast(PPNODE first,PPNODE last)
{
 if((*first)==NULL && (*last)==NULL)
 {
  return FALSE;
 }
 else if((*first)==(*last))
 {
  free (*first);
  (*first)=NULL;
  (*last)=NULL;
  
  return TRUE;

 }
 else
 {
  (*last)=(*last)->prev;
  
  free ((*last)->next);
  
  (*last)->next=(*first);
  
  (*first)->prev=(*last);
  
  return TRUE;
  
 }
}

//////////////////////////////////////////////////////
//
//function name:	InsertLast
//input:		head cha address , tail cha address ani integer
//return value:	none
//description:		used to insert node at last position
//author:		Prajakta Aditya Bartakke
//date :		12 sep 2020
//
////////////////////////////////////////////////////

void InsertLast(PPNODE first,PPNODE last,int iNo)
{

 PNODE newn=(PNODE)malloc(sizeof(NODE));
 newn->data=iNo;
 newn->prev=NULL;
 newn->next=NULL;
 
 if((*first)==NULL && (*last)==NULL)
 {
  (*first)=newn;
  (*last)=newn;
 }
 else
 {
  (*last)->next=newn;
  newn->prev=(*last);
  (*last)=newn;
 }
 
 (*last)->next=(*first);
 (*first)->prev=(*last);
}

//////////////////////////////////////////////////////
//
//function name:	DeleteAtPos
//input:		head cha address , tail cha address
//return value:	none
//description:		used to delete node at any position
//author:		Prajakta Aditya Bartakke
//date :		13 sep 2020
//
////////////////////////////////////////////////////

void DeletetAtPos(PPNODE first,PPNODE last,int iPos)
{
 int iSize=Count((*first));
 
 if(iPos<1 || iPos>iSize+1)
 {
  return;
 }
 else if(iPos==1)
 {
  DeleteFirst(first,last);
 }
 else if(iPos==iSize+1)
 {
  DeleteLast(first,last);
 }
 else
 {
  int i=0;
  
  PNODE temp=(*first);
  
  for(i=1;i<iPos;i++)
  {
   temp=temp->next;
  }
  
  temp->prev->next=temp->next;
  
  temp->next->prev=temp->prev;
  
  free (temp);
 }
}

//////////////////////////////////////////////////////
//
//function name:	InsertAtPos
//input:		head cha address , tail cha address ani number
//return value:	none
//description:		used to insert node at any position
//author:		Prajakta Aditya Bartakke
//date :		13 sep 2020
//
////////////////////////////////////////////////////

void InsertAtPos(PPNODE first,PPNODE last,int iPos,int iNo)
{
 int iSize=Count((*first));
 
 if(iPos<1 || iPos>iSize+1)
 {
  return;
 }
 
 else if(iPos==1)
 {
  InsertFirst(first,last,iNo);
 }
 
 else if(iPos==iSize+1)
 {
  InsertLast(first,last,iNo);
 }
 
 else
 {
  PNODE newn=(PNODE)malloc(sizeof(NODE));
  newn->prev=NULL;
  newn->data=iNo;
  newn->next=NULL;
  
  int i=0;
  PNODE temp=(*first);
  
  for(i=1;i<iPos;i++)
  {
   temp=temp->next;
  }
  
  newn->next=temp;
  
  temp->prev->next=newn;
  
  newn->prev=temp->prev;
  
  temp->prev=newn;
 }
 }
  
  
  





int main()
{
 PNODE head=NULL;
 PNODE tail=NULL;
 BOOL bRet=FALSE;
 
 InsertFirst(&head,&tail,11);
 InsertFirst(&head,&tail,21);
 InsertFirst(&head,&tail,51);
 InsertFirst(&head,&tail,101);
 
 InsertLast(&head,&tail,121);
 InsertLast(&head,&tail,111);
 InsertLast(&head,&tail,151);
 InsertLast(&head,&tail,171);
 
 InsertAtPos(&head,&tail,3,1789654);
 InsertAtPos(&head,&tail,4,1456321);
 InsertAtPos(&head,&tail,5,17878788);
 InsertLast(&head,&tail,171);
 
 bRet=Display(head);
 
 if(bRet==FALSE)
 {
  printf("Error:linked list is empty\n");
 }
 
 bRet=DeleteFirst(&head,&tail);
 
 if(bRet==FALSE)
 {
  printf("Error:linked list is empty\n");
 }
 else 
 {
  printf("first element is deleted successfully!!\n");
 }
 
 printf("\n");
 
 bRet=Display(head);
 
 if(bRet==FALSE)
 {
  printf("Error:linked list is empty\n");
 }
 
 bRet=DeleteLast(&head,&tail);
 
 if(bRet==FALSE)
 {
  printf("Error:linked list is empty\n");
 }
 else if(bRet==TRUE)
 {
  printf("last element deleted succesfully!!\n");
 }
 
 bRet=Display(head);
 
 if(bRet==FALSE)
 {
  printf("Error:linked list is empty\n");
 }
 
 return 0;
}
