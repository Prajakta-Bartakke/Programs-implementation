
#include<stdio.h>
#include<stdlib.h>

typedef int BOOL;

#define TRUE 1

typedef struct node
{
 int iEid;
 //char name[30];
 int age;
 int salary;
 struct node *next;
 struct node *prev;
}NODE,*PNODE,**PPNODE;

///////////////////////////////////////////////////
//
//function name:	InsertLast
//input:		address of head pointer ,address of tail pointer,
//			name,age,salary,employee id of employee
//return value:	none
//description:		used to add information of employee
//author:		Prajakta Aditya Bartakke
//date:		15 sept 2020
//
////////////////////////////////////////////////////

void InsertLast(PPNODE first,PPNODE last,int id,int age,int salary)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 
 newn->iEid=id;
 newn->age=age;
 newn->salary=salary;
 newn->next=NULL;
 newn->prev=NULL;

 if((*first)==NULL  &&  (*last)==NULL)
 {
  (*first)=newn;
  (*last)=newn;
  
 }
 else
 {
  (*last)->next=newn;
  newn->prev=(*last);
  (*last)=newn;
 }
 
 (*last)->next=(*first);
 (*first)->prev=(*last);
}

///////////////////////////////////////////////////
//
//function name:	Display
//input:		head
//return value:	none
//description:		used to display information of employee
//author:		Prajakta Aditya Bartakke
//date:		15 sept 2020
//
////////////////////////////////////////////////////

void Display(PNODE first,PNODE last)
{
 if(first==NULL)
 {
  return;
 }
 do
 {
  printf("Employee Id:%d\n",first->iEid);
  printf("Employee age:%d\n",first->age);
  printf("Employee salary:%d\n",first->salary);
  printf("------------------------------------\n");
  first=first->next;
 }while(first!=(last->next));
}

///////////////////////////////////////////////////
//
//function name:	Count
//input:		head
//return value:	int
//description:		used to count number of employee
//author:		Prajakta Aditya Bartakke
//date:		15 sept 2020
//
////////////////////////////////////////////////////

int Count(PNODE first,PNODE last)
{
 int iCnt=0;
 if(first==NULL)
 {
  return 0;
 }
 do
 {
  iCnt++;
  first=first->next;
 }while(first!=(last->next));
 return iCnt;
}

///////////////////////////////////////////////////
//
//function name:	InsertFirst
//input:		address of head pointer ,address of tail pointer,
//			name,age,salary,employee id of employee
//return value:	none
//description:		used to add information of employee
//author:		Prajakta Aditya Bartakke
//date:		15 sept 2020
//
////////////////////////////////////////////////////

void InsertFirst(PPNODE first,PPNODE last,int id,int age,int salary)
{
 PNODE newn=(PNODE)malloc(sizeof(NODE));
 
 newn->iEid=id;
 newn->age=age;
 newn->salary=salary;
 newn->next=NULL;
 newn->prev=NULL;

 if((*first)==NULL && (*last)==NULL)
 {
  (*first)=newn;
  (*last)=newn;
 }
 else
 {
  newn->next=(*first);
  (*first)->prev=newn;
  (*first)=newn;
 }
 
 (*first)->prev=(*last);
 (*last)->next=(*first);
}

///////////////////////////////////////////////////
//
//function name:	InsertAtPos
//input:		address of head pointer ,address of tail pointer,
//			name,age,salary,employee id of employee,position
//return value:	none
//description:		used to add information of employee
//author:		Prajakta Aditya Bartakke
//date:		15 sept 2020
//
////////////////////////////////////////////////////

void InsertAtPos(PPNODE first,PPNODE last,int iEid,int age,int salary,int iPos)
{
 int iCnt=Count((*first),(*last));
 int i=0;
 
 if((*first)==NULL && (*last)==NULL && iPos!=1)
 {
  printf("there is no entries of employees present at this momemt and you have entered wrong position\n");
  return;
 }
 
 else if(iPos<1 || iPos>iCnt+1)
 {
  printf("invalid input\n");
  return;
 }
 

 else if(iPos==1)
 {  
  InsertFirst(first,last,iEid,age,salary);
 }
 else if(iPos==iCnt+1)
 {
  InsertLast(first,last,iEid,age,salary);
 }
 else
 {
  PNODE newn=(PNODE)malloc(sizeof(NODE));
  newn->iEid=iEid;
  newn->age=age;
  newn->salary=salary;
  newn->prev=NULL;
  newn->next=NULL;
  
  if(iPos<=(iCnt/2))
  {
    PNODE temp=(*first);
    
    for(i=1;i<iPos;i++)
    {
     temp=temp->next;
    }
    
    newn->next=temp;
    temp->prev->next=newn;
    newn->prev=temp->prev;
    temp->prev=newn;
   }
   
   else if(iPos>(iCnt/2))
   { 
    PNODE temp=(*last);
    
    for(i=iCnt;i>iPos;i--)                                                             //last pasun ghetoy mhnje loop ulta firwaycha from maxlen to iPos
    {
     temp=temp->prev;
    }
    newn->next=temp;
    temp->prev->next=newn;
    newn->prev=temp->prev;
    temp->prev=newn;
   }
  
 }
 
}

///////////////////////////////////////////////////
//
//function name:	Search_Employee_By_Id
//input:		address of head pointer ,id ,tail pointr
//return value:	none
//description:		used to search employee
//author:		Prajakta Aditya Bartakke
//date:		15 sept 2020
//
////////////////////////////////////////////////////

void Search_Employee_By_Id(PPNODE first,PPNODE last,int key)
{
 if((*first)==NULL && (*last)==NULL)
 {
  printf("------------------------------------\n");
  printf("Error:no employee information present at this moment\n");
  return;
 }
 PNODE temp=(*first);
 
 do
 {
  printf("%d\n",temp->iEid);
  printf("%d\n",key);
  if(temp->iEid==key)
  {
   printf("------------------------------------\n");
   printf("the information of the %d eid is as follows\n",key);
   printf("age:%d\n",temp->age);
   printf("salary:%d\n",temp->salary);
   break;
  }
  temp=temp->next;
 }while(temp!=(*last)->next);
 
 if(temp==(*first)  &&  temp->iEid!=key)
 {
  printf("------------------------------------\n");
  printf("Error:corresponding ID not found\n");
 }
}

///////////////////////////////////////////////////
//
//function name:	DeleteFirst
//input:		address of head pointer ,address of tail pointer
//return value:	none
//description:		used to delete information of employee
//author:		Prajakta Aditya Bartakke
//date:		16 sept 2020
//
////////////////////////////////////////////////////

void DeleteFirst(PPNODE first,PPNODE last)
{
 if((*first)==NULL  &&  (*last)==NULL)
 {
  printf("no employee information present so could not delete any data\n");
  return;
 }
 
 if((*first)==(*last))
 {
  free (*first);
  (*first)=NULL;
  (*last)=NULL;
 }
 else
 {
  (*first)=(*last)->next->next;
  free ((*last)->next);
  (*first)->prev=(*last);
  (*last)->next=(*first);
 }
}

///////////////////////////////////////////////////
//
//function name:	DeleteLast
//input:		address of head pointer ,address of tail pointer
//return value:	none
//description:		used to delete information of employee
//author:		Prajakta Aditya Bartakke
//date:		16 sept 2020
//
////////////////////////////////////////////////////

void DeleteLast(PPNODE first,PPNODE last)
{
 if((*first)==NULL  &&  (*last)==NULL)
 {
  printf("no employee information present so could not delete any data\n");
  return;
 }
 
 if((*first)==(*last))
 {
  free (*first);
  (*first)=NULL;
  (*last)=NULL;
 }
 else
 {
  (*last)=(*last)->prev;
  free ((*first)->prev);
  (*last)->next=(*first);
  (*first)->prev=(*last);
 }
}

///////////////////////////////////////////////////
//
//function name:	DeleteId
//input:		address of head pointer ,id
//return value:	none
//description:		used to delete the information of employee having certain ID
//author:		Prajakta Aditya Bartakke
//date:		16 sept 2020
//
////////////////////////////////////////////////////

void DeleteId(PPNODE first,PPNODE last,int id)
{
 if((*first)==NULL)
 {
  printf("employee information is empty\n");
  return;
 }
 
 if(((*first)->iEid)==id)
 {
  DeleteFirst(first,last);
 }
 
 else if(((*last)->iEid)==id)
 {
  DeleteLast(first,last);
 }
 
 else
 {
  PNODE temp=(*first)->next;                 //200
  
  do                                           
  {
   if(temp->iEid==id)                       
   {
    temp->prev->next=temp->next;
    temp->next->prev=temp->prev;
    
    free (temp);
    break;
   }
  }while(temp!=(*last)->prev);
  
  if(temp->iEid!=id)
  {
   printf("Error:ID not found\n");
  }
  
 }
}
 
void Search_Max_Salary(PNODE first,PNODE last)
{
 if(first==NULL)
 {
  printf("Error:no information of employees present at this moment\n");
  return;
 }
 else
 {
  PNODE iMax=(PNODE)malloc(sizeof(NODE));
  
  iMax->prev=NULL;
  iMax->next=NULL;
  iMax->age=0;
  iMax->salary=first->salary;
  iMax->iEid=0;
  
  do
  {
   if(first->salary>iMax->salary)
   {
    iMax->salary=first->salary;
    iMax->iEid=first->iEid;
    iMax->age=first->age;
    
   }
   first=first->next;
  }while(first!=last->next);
  
  printf("ID:%d\n",iMax->iEid);
  printf("age:%d\n",iMax->age);
  printf("salary:%d\n",iMax->salary);
  
 }
}

void Update_Salary(PNODE first,PNODE last,int salary,int id)
{
 if(first==NULL)
 {
  printf("no employee present at this moment\n");
  return;
 }
 do
 {
  if(first->iEid==id)
  {
   first->salary=salary;
   break;
  }
  first=first->next;
 }while(first!=last->next);
}






 
int main()
{
 PNODE head=NULL;
 PNODE tail=NULL;
 int id=0,age=0,salary=0;
 char name[30]={'\0'};
 int iCnt=0;
 int iPos=0;
 int key=0;
 int delID=0;
 int newsal=0;
 int newid=0;
 int choice=0;
 printf("\n**********EMPLOYEE INFORMATION**********\n");
 while(1)
 {
   printf("------------------------------------\n");
   printf("Enter choice:\n");
   printf("1.insert information of new employee\n");
   printf("2.delete the information of employee\n");
   printf("3.display the information of employees\n");
   printf("4.count the total number of employee working\n");
   printf("5.Add the details of employee at any position\n");
   printf("6.search an employee by entering his ID\n");
   printf("7.to delete the information of employee with particular ID\n");
   printf("8.to display the information of such employee whose salary is maximum\n");
   printf("9.update the salary of employee of given ID\n");
   printf("0.to exit the application\n");
   printf("------------------------------------\n");
   scanf("%d",&choice);
   
   if(choice==0)
   {
    printf("thanks for using the application\n");
    break;
   }
   
   switch(choice)
   {
    case 1:
    		/*printf("enter the name of employee:\n");
    		scanf("%[^\n]s",name);*/
    		
    		printf("enter the id of employee:\n");
    		scanf("%d",&id);
    		
    		printf("enter the age of employee:\n");
    		scanf("%d",&age);
    		
    		printf("enter the salary of employee:\n");
    		scanf("%d",&salary);
    		
    		InsertFirst(&head,&tail,id,age,salary);
    break;
    
    case 3:
    		Display(head,tail);
    break;
    
    case 4:
    		iCnt=Count(head,tail);
    		printf("there are total %d employees working\n",iCnt);
    break;
    
    case 5:
    		printf("at which position the employee details to be inserted\n");
    		scanf("%d",&iPos);
    		
    		printf("enter the id of employee:\n");
    		scanf("%d",&id);
    		
    		printf("enter the age of employee:\n");
    		scanf("%d",&age);
    		
    		printf("enter the salary of employee:\n");
    		scanf("%d",&salary);
    		InsertAtPos(&head,&tail,id,age,salary,iPos);
    		
    break;
    
    case 6:
    		printf("enter element by ID\n");
    		scanf("%d",&key);
    		Search_Employee_By_Id(&head,&tail,key);
    		
    break;
    
    case 7:
    		printf("enter ID number of employee whose information is to be delted\n");
    		scanf("%d",&delID);
    		DeleteId(&head,&tail,delID);
    break;
    
    case 8:
    		Search_Max_Salary(head,tail);
    break;
    
    case 9:
    		printf("how much salary is to be given to which ID\n");
    		scanf("%d%d",&newsal,&newid);
    		Update_Salary(head,tail,newsal,newid);
    		
    break;
    		 
   } 
  }
 }
    		
    		
   
   
   
   
   
   
   
   
   
   
   
   
   
