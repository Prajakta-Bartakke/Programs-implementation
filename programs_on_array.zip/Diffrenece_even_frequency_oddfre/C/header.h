#include<stdio.h>

#include<stdlib.h>

int CountDiff(int*,int);
