#include"header.h"

//////////////////////////////////////////////
//
//function name:	CountDiff
//input:		array cha address and integer
//return value:	integer
//description:		used to return the difference between the fre of even and odd numbers 
//author:		Prajakta Aditya Bartakke
//date:		18 august 2020
////////////////////////////////////////////////

/*int CountDiff(int arr[],int iNo)
{
 int iCnt=0,iEvenCnt=0,iOddCnt=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  if((arr[iCnt]%2)==0)
  {
   iEvenCnt++;
  }
  else
  { 
   iOddCnt++;
  }
 }
 return (iEvenCnt-iOddCnt);
}*/

int CountDiff(int arr[],int iNo)
{
 int iCntf=0,iCntb=0,iEvenCnt=0;
 
 for(iCntf=0,iCntb=(iNo-1) ;  (iCntb-iCntf>=0) ; iCntf++,iCntb--)
 {
  if(iCntf==iCntb)
  {
   if((*(arr+iCntf))%2==0)
   {
    iEvenCnt++;
   }
  }
  else
  {
   if((*(arr+iCntf))%2==0)
   {
    iEvenCnt++;
   }
   if((*(arr+iCntb))%2==0)
   {
    iEvenCnt++;
   }
  }
  }
  return (iEvenCnt-(iNo-iEvenCnt));  
}

