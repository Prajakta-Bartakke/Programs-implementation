#include<stdio.h>

#include<stdlib.h>

int Frequency(int*,int);
