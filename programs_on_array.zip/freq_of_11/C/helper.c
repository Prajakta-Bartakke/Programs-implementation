#include"header.h"

//////////////////////////////////////////////
//
//function name:	Frequency
//input:		array cha address and integer
//return value:	integer
//description:		used to count the freequency of 11 
//author:		Prajakta Aditya Bartakke
//date:		18 august 2020
////////////////////////////////////////////////

/*int Frequency(int arr[],int iNo)
{
 int iCnt=0,iFrequency=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  if(arr[iCnt]==11)
  {  
   iFrequency++;
  }
 }

 return iFrequency;
}*/

int Frequency(int arr[],int iNo)
{
 int iCntf=0,iCntb=0,iFrequency=0;
 
 for(iCntf=0,iCntb=(iNo-1)  ;  (iCntb-iCntf>=0)  ; iCntf++,iCntb--)
 {
  if(iCntf==iCntb)
  {
   if(arr[iCntf]==11)
   { 
    iFrequency++;
   }
  }
  
  else
  {
   if(arr[iCntf]==11)
   { 
    iFrequency++;
   }
   if(arr[iCntb]==11)
   { 
    iFrequency++;
   }
  }
  
}
return iFrequency;
}
