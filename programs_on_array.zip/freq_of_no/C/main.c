/* problem statement:	accept n numbers from user and return the frequency of the required number
*/
#include"header.h"
int main()
{
 int iVal=0;
 int iRet=0;
 int iNumber=0;
 
 printf("how many numbers you want:\n");
 scanf("%d",&iVal);
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 printf("enter %d numbers:\n",iVal);
 
 for(int i=0;i<iVal;i++)
 {
  scanf("%d",(ptr+i));
 }
 
 printf("enter number whose frequnecy has to find:\n");
 scanf("%d",&iNumber);
 
 iRet=Frequency(ptr,iVal,iNumber);
 
 printf("frequency %d is %d\n",iNumber,iRet);
 
 free(ptr);
 
 return 0;
}
 
 
