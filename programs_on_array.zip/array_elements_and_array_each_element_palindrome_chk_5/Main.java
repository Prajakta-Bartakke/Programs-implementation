import java.util.Scanner;

class arrays
{
 boolean chkpalindrome(int[] arr)
 {
  int half=0;
  
  if((arr.length%2)!=0)
  {
   half=((arr.length)/2)+1;
  }
  else
  {
   half=arr.length/2;
  }
  
  int cnt1=0;
  
  int start=0;int end=arr.length-1;
  
  for(int i=start,j=end;j-i>=0;i++,j--)
  {
   if(arr[i]==arr[j])
   {
    cnt1++;
   }
  }
  
  start=0;end=arr.length-1;
  int i=0,j=0;
  int cnt2=0;
  
  if(cnt1==half)
  {
  for(i=start,j=end;j-i>=0;i++,j--)
  {
   int val1=arr[i];
   
   int rev=0;
   
   while(val1!=0)
   {
    rev=rev*10+(val1%10);
    
    val1=val1/10;
   }
   
   if((rev==arr[i])  &&  (arr[j]==rev))
   {
    cnt2++;
   }
   else
   {
    break;
   }
 
  }
  }
  
  System.out.println(cnt1);
  System.out.println(cnt2);
  
  if(cnt1==cnt2)
  {
   return true;
  }
  else
  {
   return false;
  }
  
   
 }

}

class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("for array how many elements you want:");
  int no=sobj.nextInt();
  int arr[]=new int[no];
 
  System.out.println("enter elements for array");
  for(int i=0;i<no;i++)
  {
   arr[i]=sobj.nextInt();
  }
  
  arrays obj=new arrays();
  
  boolean bret=obj.chkpalindrome(arr);
  
  if(bret==false)
  {
   System.out.println("FALSE");
  }
  
  else if(bret==true)
  {
   System.out.println("TRUE");
  }
  
  

 }
}
