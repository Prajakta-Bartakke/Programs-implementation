#include"header.h"

//////////////////////////////////////////////////
//
//function name:	Display
//input:		array cha address and integer
//return value:	none
//description:		used to display the numbers which are multiple of 11
//author:		Prajakta Aditya Bartakke
//date:		18 august 2020
///////////////////////////////////////////////////

/*void Display(int arr[],int iNo)
{
 int iCnt=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  if((arr[iCnt]%11)==0)
  {  
   printf("%d\t",arr[iCnt]);
  }
 }
}*/
void Display(int *arr,int iNo)
{
 int iCntf=0,iCntb=0;
 
 for(iCntf=0,iCntb=(iNo-1) ;  (iCntb-iCntf>=0)  ;  iCntf++,iCntb--)
 {  
  if(iCntf==iCntb)
  {
   if(((*(arr+iCntf))%11==0))
   {
    printf("%d\t",(*(arr+iCntf)));
   }
   break;                                                                                 //break or if else mdhe handle otherwise tinhi if mdhe jail loop when iCntf==iCntb
  }
  //else
  //{
   if(((*(arr+iCntf))%11==0))
   {
    printf("%d\t",(*(arr+iCntf)));
   }
   if(((*(arr+iCntb))%11==0))
   {
    printf("%d\t",(*(arr+iCntb)));
   }
  //}

}
}
