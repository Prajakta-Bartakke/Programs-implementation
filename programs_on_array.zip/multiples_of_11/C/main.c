/* 
problem statement: accept n numbers from user and display such numbers which are multiple of 11
*/

#include"header.h"
int main()
{
 int iVal=0;
 
 printf("enter how many numbers you want:\n");
 scanf("%d",&iVal);
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 for(int i=0;i<iVal;i++)
 { 
  scanf("%d",(ptr+i));
 }
 
 Display(ptr,iVal);
 
 printf("\n");
 
 free(ptr);
 
 return 0;
}
