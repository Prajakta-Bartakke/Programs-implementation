#include"header.h"

//////////////////////////////////////////////
//
//function name:	CountEven
//input:		array cha address and integer
//return value:	integer
//description:		used to count the even numbers 
//author:		Prajakta Aditya Bartakke
//date:		18 august 2020
////////////////////////////////////////////////

/*int CountEven(int arr[],int iNo)
{
 int iCnt=0,iCountEven=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  if((arr[iCnt]%2)==0)
  {  
   iCountEven++;
  }
 }

 return iCountEven;
}*/

int CountEven(int arr[],int iNo)
{
 int iCntf=0,iCntb=0,iCountEven=0;
 
 for(iCntf=0,iCntb=(iNo-1)  ;  (iCntb-iCntf>=0)  ; iCntf++,iCntb--)
 {
  if(iCntf==iCntb)
  {
   if((arr[iCntf]%2)==0)
   { 
    iCountEven++;
   }
  }
  
  else
  {
   if((arr[iCntf]%2)==0)
   { 
    iCountEven++;
   }
   if((arr[iCntb]%2)==0)
   { 
    iCountEven++;
   }
  }
  
}
return iCountEven;
}
