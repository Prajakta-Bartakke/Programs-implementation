/*
 problem statement: accept n numbers from user and find the maximum from it
*/

#include<stdio.h>
#include<stdlib.h>

#define ERRORMEMORY -1
#define ERRORSIZE -2

///////////////////////////////////////
//
//function name:	Maximum
//input:		array cha address and integer
//return value:	integer
//description:		used to find the maximum number
//author:		Prajakta Aditya Bartakke
//date:		18 august 2020
///////////////////////////////////////

int Maximum(int arr[],int iNo)
{

 if(arr==NULL)
 {
  return ERRORMEMORY;
 }
 
 if(iNo<=0)
 {
  return ERRORSIZE;
 }

 int iCnt=0,iMax=0;
 
 iMax=arr[0];
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  if(arr[iCnt]>iMax)
  {
   iMax=arr[iCnt];
  }
 }
 
 return iMax;
}
 
int main()
{
 int iVal=0;
 int iRet=0;
 
 printf("how many numners you want\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid input\n");
  return -1;
 }
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("Errot:unable to allocate memory\n");
  return -1;
 }
 
 for(int iCnt=0;iCnt<iVal;iCnt++)
 {
  scanf("%d",&ptr[iCnt]);
 }
 
 iRet=Maximum(ptr,iVal);
  
 if(iRet==ERRORMEMORY)
 {
  printf("Error:memory problem\n");
 }
 else if(iRet==ERRORSIZE)
 {
  printf("Error:invalid size\n");
 }
 
 else
 {
 printf("maximum number is:%d\n",iRet);
 }
 return 0;
}
