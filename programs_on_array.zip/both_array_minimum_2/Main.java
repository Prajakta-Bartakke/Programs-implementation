import java.util.Scanner;

class arrays
{
 void Display(int[] arr,int[] brr)
 {
  int sum=0;
  int min=arr[0];
  for(int i=0;i<arr.length;i++)
  {
   if(arr[i]<min)
   {
    min=arr[i];
   }
  }
  System.out.println("minimum of firts array is :"+min);
  
  min=brr[0];
  
  for(int i=0;i<brr.length;i++)
  {
   if(brr[i]<min)
   {
    min=brr[i];
   }
  }
  System.out.println("minimum of second array is :"+min);
 }
}

class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("for first array how many elements you want:");
  int no1=sobj.nextInt();
  int arr[]=new int[no1];
  
  System.out.println("for second array how many elements you want:");
  int no2=sobj.nextInt();
  int brr[]=new int[no2];
  
  System.out.println("enter elements for first array");
  for(int i=0;i<no1;i++)
  {
   arr[i]=sobj.nextInt();
  }
  
  System.out.println("enter elements for second array");
  for(int i=0;i<no2;i++)
  {
   brr[i]=sobj.nextInt();
  }
  
  arrays obj=new arrays();
  
  obj.Display(arr,brr);

 }
}
