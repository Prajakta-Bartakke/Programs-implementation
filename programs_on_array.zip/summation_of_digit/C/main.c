/*
problem statement:	accept n numbers from user and return summation of digits of each numbers
*/

#include<stdio.h>
#include<stdlib.h>

#define ERRORMEMORY -1
#define ERRORSIZE -2

int AddDigits(int iNo)
{
 int iSum=0;
 int iDigit=0;
 
 if(iNo<0)
 {
  iNo=-iNo;
 }
 
 while(iNo!=0)
 {
  iDigit=iNo%10;
  
  iSum=iSum+iDigit;
  
  iNo=iNo/10;
 }
 
 return iSum;
}

int SumDigits(int arr[],int iSize)
{
 if(arr==NULL)
 {
  return ERRORMEMORY;
 }
 if(iSize<=0)
 {
  return ERRORSIZE;
 }
 int iCnt=0;
 int iAdd=0;
 
 for(iCnt=0;iCnt<iSize;iCnt++)
 {
  iAdd=0;
  iAdd=AddDigits(arr[iCnt]);
  printf("%d\t",iAdd);
 }
 
}
int main()
{
 int iVal=0;
 int iCnt=0;
 int iRet=0;
 
 printf("how many numbers do you want\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid input\n");
  return -1;
 }
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("Error:unable to alloacte memory\n");
  return -1;
 }
 
 for(iCnt=0;iCnt<iVal;iCnt++)
 {
  scanf("%d",&ptr[iCnt]);
 }
 
 iRet=SumDigits(ptr,iVal);
 
 if(iRet==ERRORMEMORY)
 {
  printf("Error:memory problem\n");
 }
 else if(iRet==ERRORSIZE)
 {
  printf("Error:invalid size\n");
 }
 
 
 free(ptr);
 return 0;
}
