/*
problem statement: accept n numbers from user and also accept another number from user and check whether that number is present in our number list or not

*/

#include<stdio.h>
#include<stdlib.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0
#define ERRORMEMORY -1
#define ERRORSIZE -2

//////////////////////////////////////////////////////
//
//function name:	Check
//input:		array cha address,size of array,the number to be checked
//return value:	boolean
//description:		check kara ki particular value present ahe ka
//author:		Prajakta Aditya Bartakke
//date:		19 august 2020
///////////////////////////////////////////////////////

BOOL Check(int arr[],int iSize,int iValue)               
{
 if(arr==NULL)
 {
  return ERRORMEMORY;
 }
 if(iSize<=0)
 {
  return ERRORSIZE;
 }
 int iMatch=0;
 int iCnt=0;
 
 for(iCnt=0;iCnt<iSize;iCnt++)
 {
  if(arr[iCnt]==iValue)                
  {
   iMatch=iValue;
   break;
  }
 }
 if(iMatch==iValue)
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
}

/*BOOL Check(int arr[],int iSize,int iValue)               
{
 if(arr==NULL)
 {
  return ERRORMEMORY;
 }
 if(iSize<=0)
 {
  return ERRORSIZE;
 }
 int iMatch=0;
 int iCnt=0;
 
 for(iCnt=0;iCnt<iSize;iCnt++)
 {
  if(arr[iCnt]==iValue)                
  {
   iMatch++;
  }
 }
 if(iMatch>0)
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
}*/

int main()
{
 int iVal=0;
 int iCheck=0;
 BOOL bRet=FALSE;
 int i=0;
 
 printf("how many numbers you want:\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid input\n");
  return -1;
 }
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("Error:unable to allocate memory\n");
  return -1;
 }
 
 for(i=0;i<iVal;i++)
 {
  scanf("%d",&ptr[i]);
 }
 
 printf("enter which number you have to check\n");
 scanf("%d",&iCheck);
 
 bRet=Check(ptr,iVal,iCheck);
 
 if(bRet==TRUE)
 {
  printf("TRUE\n");
 }
 else if(bRet==FALSE)
 {
  printf("FLASE\n");
 }
 else if(bRet==ERRORMEMORY)
 {
  printf("Error:memory problem\n");
 }
 else if(bRet==ERRORSIZE)
 {
  printf("Error:invalid size\n");
 }
 
 free(ptr);
 
 return 0;
}
 
 
