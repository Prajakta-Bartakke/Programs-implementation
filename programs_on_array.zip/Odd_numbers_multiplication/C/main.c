/*problem statement:  accept n numbers from user and return multiplication of odd numbers in it
*/
#include<stdio.h>
#include<stdlib.h>

#define ERRORMEMORY -1
#define ERRORSIZE -2



int OddMulti(int arr[],int iSize)
{
 if(arr==NULL)
 {
  return ERRORMEMORY;
 }
 if(iSize<=0)
 {
  return ERRORSIZE;
 }
 int iCntf=0,iCntb=0,iMult=1;
 
 for(iCntf=0,iCntb=(iSize-1) ; (iCntb-iCntf>=0) ; iCntf++,iCntb--)
 {
  if((arr[iCntf]%2)!=0)
  {
   iMult=iMult*arr[iCntf];
  }
  if((arr[iCntb]%2)!=0)
  {
   iMult=iMult*arr[iCntb];
  }
 }
 if(iMult>1)
 return iMult;
 
 else
 return 0;
}

int main()
{
 int iVal=0;
 int iCnt=0;
 int iRet=0;
 
 printf("how many numbers you want:\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid input\n");
  return -1;
 }
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("Error:unable to allocate memory\n");
 }
 
 for(iCnt=0;iCnt<iVal;iCnt++)
 { 
  scanf("%d",&ptr[iCnt]);
 }
 
 iRet=OddMulti(ptr,iVal);
 
 if(iRet==ERRORMEMORY)
 {
  printf("Error:memory problme\n");
 }
 else if(iRet==ERRORSIZE)
 {
  printf("Error:size invalid\n");
 }
 else
 {
  printf("multiplication is %d\n",iRet);
 }
 
 
 free(ptr);
 
 return 0;
}
