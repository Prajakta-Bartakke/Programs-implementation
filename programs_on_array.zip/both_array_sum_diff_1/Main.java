import java.util.Scanner;

class arrays
{
 int Difference(int[] arr,int[] brr)
 {
  int sum1=0;
  int sum2=0;
  
  for(int i=0;i<arr.length;i++)
  {
   sum1=sum1+arr[i];
  }

  for(int i=0;i<brr.length;i++)
  {
   sum2=sum2+brr[i];
  }
 return sum1-sum2;
 }
}

class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("for first array how many elements you want:");
  int no1=sobj.nextInt();
  int arr[]=new int[no1];
  
  System.out.println("for second array how many elements you want:");
  int no2=sobj.nextInt();
  int brr[]=new int[no2];
  
  System.out.println("enter elements for first array");
  for(int i=0;i<no1;i++)
  {
   arr[i]=sobj.nextInt();
  }
  
  System.out.println("enter elements for second array");
  for(int i=0;i<no2;i++)
  {
   brr[i]=sobj.nextInt();
  }
  
  arrays obj=new arrays();
  
  int diff=obj.Difference(arr,brr);
  
  System.out.println("diffrenec in sum of both arrays:"+diff);

 }
}
