#include<stdio.h>
#include<stdlib.h>

void Display(int*,int);
