/* problem statement:  accept n numbers from user and also accept another number and return its first occurence
*/

#include<stdio.h>
#include<stdlib.h>

#define ERRORMEMORY -1
#define ERRORSIZE -2
#define ABSENT -3


//////////////////////////////////////////////////
//
//function name:	Check
//input:		array cha address ,array cha size,integer
//return value:	int
//description:		used to find the first occurence of a particular number
//author:		Prajakta Aditya Bartakke
//date:		19 august 2020
///////////////////////////////////////////////////

int Check(int *arr,int iSize,int iVal)
{
 if(arr==NULL)
 {
  return ERRORMEMORY;
 }
 if(iSize<=0)
 {
  return iSize;
 }
 
 int iIndex=-1,iCnt=0;
 
 for(iCnt=0;iCnt<iSize;iCnt++)     //looop don goshtinmule stop hoto..tya donhi cases handles
 {
  if(arr[iCnt]==iVal)
  {
   iIndex=iCnt;
   break;
  }
 }
 if(iIndex>=0)
 {
  return iIndex;
 }
 else
 {
  return ABSENT;
 }
}

int main()
{
 int iVal=0;
 int iCnt=0;
 int iCheck=0;
 int iRet=0;
 
 printf("how many numbers you want:\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid size\n");
 }
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("Error:unable to allocate memory\n");
 }
 
 for(iCnt=0;iCnt<iVal;iCnt++)
 {
  scanf("%d",&ptr[iCnt]);
 }
 
 printf("which number's first occurenec you want to find:\n");
 scanf("%d",&iCheck);
 
 iRet=Check(ptr,iVal,iCheck);
 
 if(iRet==ERRORMEMORY)
 {
  printf("Error:memory pblm\n");
 }
 else if(iRet==ERRORSIZE)
 {
  printf("Error:invalid size\n");
 }
 else if(iRet==ABSENT)
 {
  printf("Error:there is no such number present\n");
 }
 else
 {
  printf("first occurence of %d is %d\n",iCheck,iRet);
 }
 

 free(ptr);
 return 0;
}

