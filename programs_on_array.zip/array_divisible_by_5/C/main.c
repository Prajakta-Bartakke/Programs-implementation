/*
problem statement: accept n numbers from user and display those numbers which are divisible by 5
*/

#include"header.h"
int main()
{
 int iVal=0;
 
 printf("enter how many numbers you want:\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid input\n");
  return -1;
 }
 
 int *ptr=(int*)malloc(sizeof(iVal)*iVal);
 
 if(ptr==NULL)
 {
  printf("unable to allocate memory\n");
  return -1;
 }
 
 for(int i=0;i<iVal;i++)
 {
  scanf("%d",(ptr+i));
 }
 
 Display(ptr,iVal);
 
 printf("\n");
 
 free(ptr);
 
 return 0;
}
