#include"header.h"

///////////////////////////////////////////////
//
//function name:	Display
//input:		integer array cha address and intger
//return value:	none
//description:		used to display numbers divisible by 5
//author:		Prajakta Aditya Bartakke
//date:		18 august 2020
/////////////////////////////////////////////////

/*void Display(int *arr,int iNo)
{

 if(arr==NULL)
 {
  return;
 }
 if(iNo<=0)
 {
  return;
 }
 int iCnt=0,iCount=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  if((*(arr+iCnt))%5==0)
  {
   printf("%d\t",(*(arr+iCnt)));
  }
 }
}*/
//////////////////////////////////
//
//time complexity:O(N)
//
//////////////////////////////////

void Display(int *arr,int iNo)
{
 if(arr==NULL)
 {
  return;
 }
 if(iNo<=0)
 {
  return;
 }
 int iCntf=0,iCntb=0;
 
 for(iCntf=0,iCntb=(iNo-1)  ;  (iCntb-iCntf>=0)  ; iCntf++,iCntb--)
 {  
  if(iCntf==iCntb)
  {
   if((arr[iCntf]%5)==0)
   {
    printf("%d\t",arr[iCntb]);
   }
  }
  else
  {
  if((arr[iCntf])%5==0)
  {
   printf("%d\t",arr[iCntf]);
  }
  if((arr[iCntb])%5==0)
  {
   printf("%d\t",arr[iCntb]);
  }
  }
  
  }
}
//////////////////////////////////
//
//time complexity:O(N/2)
//
//////////////////////////////////








