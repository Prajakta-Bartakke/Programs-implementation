/*
problem statement: accept n numbers from user and return the difference between largest and smallest number
*/

#include<stdio.h>
#include<stdlib.h>

#define ERRORMEMORY -1
#define ERRORSIZE -2

//istri ani dryclean ekach

//////////////////////////////////////////////
// 
//function name:	Difference
//input:		array cha address and integer
//return value:	integer
//description:		used to return the difference between largest and smallest number
//author:		Prajakta Aditya Bartakke
//date:		19 aug 2020
////////////////////////////////////////////////

int Difference(int arr[],int iSize)
{
 if(arr==NULL)
 {
  return ERRORMEMORY;
 }
 if(iSize<=0)
 {
  return ERRORSIZE;
 }
 
 int iCnt=0,iMax=0,iMin=0;
 
 iMax=arr[0];
 iMin=arr[0];
 
 for(iCnt=0;iCnt<iSize;iCnt++)
 {
  if(arr[iCnt]>iMax)
  {
   iMax=arr[iCnt];
  }
  else if(arr[iCnt]<iMin)
  {
   iMin=arr[iCnt];
  }
 }
 
 return (iMax-iMin);
}

int main()
{
 int iVal=0;
 int iCnt=0;
 int iDiff=0;
 
 printf("how many numbers you want:\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid input\n");
  return -1;
 }
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("Error:unable to allocate memory\n");
  return -1;
 }
 
 for(iCnt=0;iCnt<iVal;iCnt++)
 {
  scanf("%d",&ptr[iCnt]);
 }
 
 iDiff=Difference(ptr,iVal);
 
 if(iDiff==ERRORMEMORY)
 {
  printf("Error:memeory problem\n");
  return -1;
 }
 
 else if(iDiff==ERRORSIZE)
 {
  printf("Error:invallid input\n");
 }
 
 else
 {
  printf("difference is %d",iDiff);
 } 
 printf("\n");
 free(ptr);
 return 0;
}
