import java.util.Scanner;

class arrays
{
 int[] Display(int[] arr,int[] brr)
 {
  int j=arr.length+brr.length;        //5+6=11
  
  int crr[]=new int[j];
  
  int k=0;
  
  for(int i=0;i<arr.length && k<j;i++,k++)    
  {
   crr[k]=arr[i];
  }
  
  for(int i=0;i<brr.length && k<j;i++,k++) 
  {
   crr[k]=brr[i];
  } 
  
  return crr; 
 
 }
}

class Main
{
 public static void main(String arg[])
 {
  Scanner sobj=new Scanner(System.in);
  
  System.out.println("for first array how many elements you want:");
  int no1=sobj.nextInt();
  int arr[]=new int[no1];
  
  System.out.println("for second array how many elements you want:");
  int no2=sobj.nextInt();
  int brr[]=new int[no2];
  
  System.out.println("enter elements for first array");
  for(int i=0;i<no1;i++)
  {
   arr[i]=sobj.nextInt();
  }
  
  System.out.println("enter elements for second array");
  for(int i=0;i<no2;i++)
  {
   brr[i]=sobj.nextInt();
  }
  
  arrays obj=new arrays();
  
  int crr[]=obj.Display(arr,brr);
  
  System.out.println("third array contents are:");
  
  for(int i=0;i<crr.length;i++)
  {
   System.out.println(crr[i]+"\t");
  }

 }
}
