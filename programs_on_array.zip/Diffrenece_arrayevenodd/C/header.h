#include<stdio.h>

#include<stdlib.h>

#define ERRORMEMORY -1
#define ERRORSIZE -2

int DifferenceEvenOdd(int *,int);
