#include"header.h"


//////////////////////////////////////////////////////
//
//function name:	DifferenceEvenOdd
//input arguments:	array cha address and ineteger
//return value:	integer
//description:		used to return the differenece between the summation of even numbers and sum of odd nos
//author:		Prajakta Aditya Bartakke
//date:		18 august 2020
///////////////////////////////////////////////////////

/*int DifferenceEvenOdd(int arr[],int iNo)                //int arr[]       same as   int *arr     karan array internally pointer sarkha work hota  mhnje arr mdhe base address store hota
{
 if(arr==NULL)
 {
  return ERRORMEMORY;
 }
 if(iNo<=0)
 {
  return ERRORSIZE;
 }
 int iEvenSum=0,iOddSum=0,iCnt=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  if((arr[iCnt]%2)==0)
  {   
   iEvenSum=iEvenSum+arr[iCnt];
  }
  else
  {
   iOddSum=iOddSum+arr[iCnt];
  }
  }
 return (iEvenSum-iOddSum);
}*/


/*int DifferenceEvenOdd(int *arr,int iNo)                
{
 int iDiff=0,iCnt=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  if(((*(arr+iCnt))%2)==0)
  {   
   iDiff=iDiff+(*(arr+iCnt));
  }
  else
  {
   iDiff=iDiff-(*(arr+iCnt));
  }
  }
 return iDiff;
}*/
///////////////////////////////////////////////////
//
//time complexity:O(N)
//
//////////////////////////////////////////////////



int DifferenceEvenOdd(int *arr,int iNo)                
{
 int iCntf=0,iCntb=(iNo-1),iDiff=0;
 
 for(iCntf=0,iCntb=(iNo-1)  ;  (iCntb-iCntf>=0)  ;  iCntf++,iCntb--)
 {
  if(iCntf==iCntb)                                                      //ya condition la separately handle kelyane break chi garaj nahi..SS
  {
   if((*(arr+iCntf))%2==0)
   {
    iDiff=iDiff+arr[iCntf];
   }
   else
   {
    iDiff=iDiff-arr[iCntf];
   }
  }
  else
  {
    if((arr[iCntf]%2)==0)
    {
     iDiff=iDiff+arr[iCntf];
    }
    if((arr[iCntb]%2)==0)
    {
     iDiff=iDiff+arr[iCntb];
    }
    if((arr[iCntf]%2)!=0)
    {
     iDiff=iDiff-arr[iCntf];
    }
    if((arr[iCntb]%2)!=0)
    {
     iDiff=iDiff-arr[iCntb];
    }
   }
   }
   return iDiff;
  
}

///////////////////////////////////////////////////////////
//
//time complexity:O(N/2)
//
//////////////////////////////////////////////////////////




















