/*
 problem statement:  aacept n numbers from user which returns the difference between summation of elements of even numbers and summation of odd numbers
*/

#include"header.h"
int main()
{
 int iVal=0;
 int iDiff=0;
 
 printf("enter how many elements do you want:\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:inavlid input\n");
 }
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("not able to allocate memory\n");
  return -1;
 }

 for(int i=0;i<iVal;i++)
 {
  scanf("%d",(ptr+i));
 }
 
 iDiff=DifferenceEvenOdd(ptr,iVal);
 
 if(iDiff==ERRORMEMORY)
 {
  printf("Error:memory problem\n");
 }
 
 else if(iDiff==ERRORSIZE)
 {
  printf("Error:invalid input\n");
 }
 
 else
 {
 printf("the differenece is : %d\n",iDiff);
 }
 
 free(ptr);
 
 return 0;
} 
 
