/*
 problem statement: accept n numbers from user and find the minimum from it
*/

#include<stdio.h>
#include<stdlib.h>

#define ERRORMEMORY -1
#define ERRORSIZE -2

///////////////////////////////////////
//
//function name:	Minimum
//input:		array cha address and integer
//return value:	integer
//description:		used to find the minimum number
//author:		Prajakta Aditya Bartakke
//date:		18 august 2020
///////////////////////////////////////

int Minimum(int arr[],int iNo)
{

 if(arr==NULL)
 {
  return ERRORMEMORY;
 }
 
 if(iNo<=0)
 {
  return ERRORSIZE;
 }

 int iCnt=0,iMin=0;
 
 iMin=arr[0];
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  if(arr[iCnt]<iMin)
  {
   iMin=arr[iCnt];
  }
 }
 
 return iMin;
}
 
int main()
{
 int iVal=0;
 int iRet=0;
 
 printf("how many numners you want\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid input\n");
  return -1;
 }
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("Errot:unable to allocate memory\n");
  return -1;
 }
 
 for(int iCnt=0;iCnt<iVal;iCnt++)
 {
  scanf("%d",&ptr[iCnt]);
 }
 
 iRet=Minimum(ptr,iVal);
  
 if(iRet==ERRORMEMORY)
 {
  printf("Error:memory problem\n");
 }
 else if(iRet==ERRORSIZE)
 {
  printf("Error:invalid size\n");
 }
 
 else
 {
 printf("minimum number is:%d\n",iRet);
 }
 return 0;
}
