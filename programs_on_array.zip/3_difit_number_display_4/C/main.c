/*
problem statement:  accept n numbers from user and display such numbers which do have 3 digits in it
*/

#include<stdio.h>
#include<stdlib.h>


/*int CountDigits(int iNo)
{
 int iDigit=0;
 
 while(iNo!=0)
 {
  iNo=iNo/10;
  iDigit++;
 }
 
 return iDigit;
}*/

/*void Display(int arr[],int iSize)
{
 int iCnt=0;
 int iCountDigit=0;
 
 if(arr==NULL)
 {
  printf("Error:memory problem\n");
  return;
 }
 if(iSize<=0)
 {
  printf("Error:invalid input\n");
  return;
 }
 
 for(iCnt=0;iCnt<iSize;iCnt++)
 {
   iCountDigit=CountDigits(arr[iCnt]);
   
   if(iCountDigit==3)
   {
    printf("%d\t",arr[iCnt]);
   }
  }
 }*/


/*void Display(int arr[],int iSize)
{
 int iCnt=0;
 int iCountDigit=0;
 
 if(arr==NULL)
 {
  printf("Error:memory problem\n");
  return;
 }
 if(iSize<=0)
 {
  printf("Error:invalid input\n");
  return;
 }
 
 for(iCnt=0;iCnt<iSize;iCnt++)
 {
   int iValue=arr[iCnt];
   iCountDigit=0;
   
   while(arr[iCnt]!=0)
   {
    iCountDigit++;
    arr[iCnt]=(arr[iCnt])/10;
  }
  if(iCountDigit==3)
  {
   printf("%d\t",iValue);
  }

 }
}*/

void Display(int arr[],int iSize)
{
 int iCnt=0;
 int iCountDigit=0;
 
 if(arr==NULL)
 {
  printf("Error:memory problem\n");
  return;
 }
 if(iSize<=0)
 {
  printf("Error:invalid input\n");
  return;
 }
 printf("3 digits numbers are:\n");
 for(iCnt=0;iCnt<iSize;iCnt++)
 {
   int iValue=arr[iCnt];
   iCountDigit=0;
   
   while(iValue!=0)
   {
    iCountDigit++;
    iValue=iValue/10;
  }
  if(iCountDigit==3)
  {
   printf("%d\t",arr[iCnt]);
  }

 }
}





int main()
{
 int iVal=0;
 int iCnt=0;
 
 printf("how many numbers you want:\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid input\n");
  return -1;
 }
 
 int *ptr=malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("Error:unable to alloacte memory\n");
  return -1;
 }
 
 for(iCnt=0;iCnt<iVal;iCnt++)
 {
  scanf("%d",&ptr[iCnt]);
 }
 
 Display(ptr,iVal);
 
 printf("\n");

 free(ptr);
 return 0;
}
 
 
