/* problem statement:
  			Accept n numbers from user and alseo accept one more number and find its last occurence
 */
 
#include<stdio.h> 
#include<stdlib.h>
 
#define ERRORMEMORY -1
#define ERRORSIZE -2 
#define ABSENT -3
 
int LastOccurence(int arr[],int iSize,int iVal)
{ 
 if(arr==NULL)
 {
  return ERRORMEMORY;
 } 
 if(iSize<=0)
 {
  return ERRORSIZE;
 }
 int iCnt=0,iIndex=-1;
 
 for(iCnt=0;iCnt<iSize;iCnt++)
 {
  if(arr[iCnt]==iVal)
  {
   iIndex=iCnt;
  }
 }
 
 if(iIndex>=0)
 {
  return iIndex;
 }
 else
 {
  return ABSENT;
 }
 
}

int main()
{
 int iVal=0,iCnt=0,iCheck=0,iRet=0;
 
 printf("how many numbers you want:\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid input\n");
  return -1;
 }
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("Error:unable to allocate momory\n");
  return -1;
 }
 
 for(iCnt=0;iCnt<iVal;iCnt++)
 {
  scanf("%d",&ptr[iCnt]);
 }
 
 printf("enter number whose last occurenec is to be find\n");
 scanf("%d",&iCheck);
 
 iRet=LastOccurence(ptr,iVal,iCheck);
 
 if(iRet==ERRORMEMORY)
 {
  printf("Error:memory problem\n");
 }
 else if(iRet==ERRORSIZE)
 {
  printf("Error:invalid size\n");
 }
 else if(iRet==ABSENT)
 {
  printf("Error:there is no such number present \n");
 }
 else
 {
  printf("last occurenec of %d is %d\n",iCheck,iRet);
 }
 free(ptr);
 return 0;
}
