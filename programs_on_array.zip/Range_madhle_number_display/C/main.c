/* 
problem statement:	accept n numbers from user also accept starting and ending point (range) and displya numbers from your array coming in that range
*/
#include<stdio.h>
#include<stdlib.h>

void Display(int arr[],int iSize,int iStart,int iEnd)
{
 if(arr==NULL)
 {
  printf("Error:memory problem\n");
 }
 if(iSize<=0)
 {
  printf("Error:invalid input\n");
 }
 else if((iStart==0  &&   iEnd==0)  ||  (iStart>iEnd))
 {
  printf("Error:invalid input\n");
 }
 int iCnt=0;
 
 printf("output is:\n");
 
 for(iCnt=0;iCnt<iSize;iCnt++)
 {
  if((arr[iCnt]>iStart) && (arr[iCnt]<iEnd))
  {
   printf("%d\t",arr[iCnt]);
  }
 }
}

int main()
{
 int iVal=0;
 int iCnt=0;
 int iStart=0,iEnd=0;
 printf("how many numbers you want\n");
 scanf("%d",&iVal);
 
 if(iVal==0)
 {
  printf("Error:invalid input\n");
  return -1;
 }
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 if(ptr==NULL)
 {
  printf("Error:unable to allocate memory\n");
  return -1;
 }
 
 for(iCnt=0;iCnt<iVal;iCnt++)
 {
  scanf("%d",&ptr[iCnt]);
 }
 
 printf("enter starting point:\n");
 scanf("%d",&iStart);
 
 printf("enter ending point:\n");
 scanf("%d",&iEnd);
 
 Display(ptr,iVal,iStart,iEnd);
 printf("\n");
 free(ptr);
 return 0;
}
 
