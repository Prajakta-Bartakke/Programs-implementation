#include"header.h"

//////////////////////////////////////////////
//
//function name:	Check
//input:		array cha address and integer
//return value:	boolean
//description:		used to check 11 is present
//author:		Prajakta Aditya Bartakke
//date:		18 august 2020
////////////////////////////////////////////////

BOOL Check(int arr[],int iNo)
{
 int iCnt=0;
 int iCount=0;
 
 for(iCnt=0;iCnt<iNo;iCnt++)
 {
  if(arr[iCnt]==11)
  {
   iCount++;
  }
 }
 if(iCount>0)
 {
  return TRUE;
 }
 else
 {
  return FALSE;
 }
}


