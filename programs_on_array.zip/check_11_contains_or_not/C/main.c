/* problem statement:	accept n numbers from user and check whether it contains 11 in it or not
*/
#include"header.h"
int main()
{
 int iVal=0;
 BOOL bRet=FALSE;
 
 printf("how many numbers you want:\n");
 scanf("%d",&iVal);
 
 int *ptr=(int*)malloc(sizeof(int)*iVal);
 
 for(int i=0;i<iVal;i++)
 {
  scanf("%d",(ptr+i));
 }
 
 bRet=Check(ptr,iVal);
 
 if(bRet==TRUE)
 {
  printf("11 is present\n");
 }
 else
 {
  printf("11 not present\n");
 }
 
 free(ptr);
 
 return 0;
}
 
 
